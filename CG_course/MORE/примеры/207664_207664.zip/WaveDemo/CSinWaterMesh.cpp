//-------------------------------------------------------------------------------------
//
// Copyright 2004 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations a bout the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software not any
// responsibility to update it.
//
//-------------------------------------------------------------------------------------

#include "CSinWaterMesh.h"

#define M_PI 3.1415

//#define DAVID_OUTPUT_NORMALS
#define DAVID_OUTPUT_FILENUM 180

#define DAVID_THREADSAFE
#define DAVID_THREADSAFE_CRITICALSECTION

CSinWaterMesh::CSinWaterMesh( IDirect3DDevice9* pDevice, int iNumRows, int iNumCols )
{
	Initialize( pDevice, iNumRows, iNumCols );
}


CSinWaterMesh::CSinWaterMesh( IDirect3DDevice9* pDevice, 
							  int iNumRows, 
							  int iNumCols,
							  long lThreadLaunched,
							  bool bUseWaveDerivative,
							  bool bUseFastNormalLookup,
							  bool *bSumWave
							)
{
	DXUTOutputDebugString( L"iNumRows:  %d\n", iNumRows);
	DXUTOutputDebugString( L"iNumCols:  %d\n", iNumCols);
	Initialize( pDevice, iNumRows, iNumCols, lThreadLaunched, bUseWaveDerivative, bUseFastNormalLookup, bSumWave );
}



void CSinWaterMesh::Initialize( IDirect3DDevice9 *pDevice, int iNumRows, int iNumCols )
{
	// Thread stuff
	InitializeCriticalSection( &m_csCriticalSection );
	m_vlThreadLaunched = false;
	m_bUseWaveDerivative = false;
	m_bUseFastNormalLookup = true;
	m_vlStepDone = false;
	m_vlExitThread = false;
	m_bSumWave[0] = true;
	m_bSumWave[1] = true;
	m_bSumWave[2] = true;
	m_bSumWave[3] = true;

	m_iNumRows = iNumRows;
	m_iNumCols = iNumCols;
	m_pIB = NULL;
	m_pVB = NULL;

	m_pNormalLookupTable = NULL;
	m_pNeighborList = NULL;
	m_pFaceNormals = NULL;

	m_pIBD3D = NULL;
	m_pVBD3D = NULL;
	m_pDevice = pDevice;

	m_iFileNum = DAVID_OUTPUT_FILENUM;
	m_bFirstDerivativeThru = false;
	m_bFirstNormalLookupThru = false;

	GridGen();

#ifndef DAVID_THREADSAFE
	DXUTOutputDebugString( L"NOT Thread safe\n" );
#else
	#ifdef DAVID_THREADSAFE_CRITICALSECTION
	DXUTOutputDebugString( L"Using critical section\n" );
	#else
	DXUTOutputDebugString( L"Using LOCK\n" );
	#endif
#endif
}

void CSinWaterMesh::Initialize( IDirect3DDevice9 *pDevice, 
							    int iNumRows, 
							    int iNumCols,
							    long lThreadLaunched,
							    bool bUseWaveDerivative,
							    bool bUseFastNormalLookup,
							    bool *bSumWave
							   )
{
	// Thread stuff
	InitializeCriticalSection( &m_csCriticalSection );
	m_vlThreadLaunched = lThreadLaunched;
	m_bUseWaveDerivative = bUseWaveDerivative;
	m_bUseFastNormalLookup = bUseFastNormalLookup;
	m_vlStepDone = false;
	m_vlExitThread = false;

	for( int i=0; i < NUM_WAVES; i++ )
	{
		m_bSumWave[i] = bSumWave[i];
	}
	
	m_iNumRows = iNumRows;
	m_iNumCols = iNumCols;
	m_pIB = NULL;
	m_pVB = NULL;

	m_pNormalLookupTable = NULL;

	m_pNeighborList = NULL;
	m_pFaceNormals = NULL;

	m_pIBD3D = NULL;
	m_pVBD3D = NULL;
	m_pDevice = pDevice;

	m_iFileNum = DAVID_OUTPUT_FILENUM;
	m_bFirstDerivativeThru = false;
	m_bFirstNormalLookupThru = false;

	GridGen();
}


void CSinWaterMesh::InitializeWave( int index, float wavelength, float amplitude, float speed, CVector3 *direction, float kexp )
{
	m_wavelength[index] = wavelength;
	m_amplitude[index] = amplitude;
	m_speed[index] = speed;
	m_kexp[index] = kexp;
	m_direction[index].x = direction->x;
	m_direction[index].y = direction->y;
	m_direction[index].z = direction->z;
}

void CSinWaterMesh::ComputeBoundingSphere( CVector3 *ctr, float *radius )
{
	//walk the vertex buffer, determine the farthest point from the origin
	//distance from origin = v2-v1 blah blah
	//determine the origin, the average of all of teh points
	CVector3 center;
	ComputeOrigin( &center );

	//calculate the distance from each point to the center of the mesh
	//keep track of the furthest distance
	int curFurthestPtIndex = -1;
	float curFurthestDistance = -1.0f;
	float tempDist = -1.0f;
	CVector3 temp;

	for( int i=0; i<m_iNumRows*m_iNumCols; i++ )
	{
		temp.x = m_pVB[i].x - center.x;
		temp.y = m_pVB[i].y - center.y;
		temp.z = m_pVB[i].z - center.z;
		tempDist = sqrt( temp.DotSelf() );
		if( tempDist > curFurthestDistance )
		{
			//new furthest distance
			curFurthestDistance = tempDist;
			curFurthestPtIndex = i;
		}
	}
	*radius = curFurthestDistance;
	ctr->Init( temp.x, temp.y, temp.z );
}

void CSinWaterMesh::ComputeBoundingBox( CVector3 *bb )
{

}

void CSinWaterMesh::ComputeOrigin( CVector3 *ctr )
{
	CVector3 sum;
	sum.Init( 0.0f, 0.0f, 0.0f );
	//walk all of the vertices
	for( int i=0; i<(m_iNumRows)*(m_iNumCols); i++ )
	{
		sum.x += m_pVB[i].x;
		sum.y += m_pVB[i].y;
		sum.z += m_pVB[i].z;
	}
	sum.DivConst( (float)i );
	ctr->Init( sum.x, sum.y, sum.z );
}

LPDIRECT3DVERTEXBUFFER9 CSinWaterMesh::GetD3DVB()
{
	return m_pVBD3D;
}

LPDIRECT3DINDEXBUFFER9 CSinWaterMesh::GetD3DIB()
{
	return m_pIBD3D;
}

void CSinWaterMesh::InitNeighborList() 
{
	if( m_pNeighborList == NULL )
	{
		m_pNeighborList = (int *)malloc( sizeof(int) * m_iNumRows * m_iNumCols * 6 );
	}

	for( int i=0; i<m_iNumRows*m_iNumCols; i++ )
	{
		for( int j=0; j<6; j++ )
		{
			m_pNeighborList[i*6+j] = -1;
		}
	}

	PrintNeighborList();
}

void CSinWaterMesh::PrintNeighborList()
{
	for( int i=0; i<m_iNumRows*m_iNumCols; i++ )
	{
		printf( "m_pNeighborList[%d] = [%d %d %d %d %d %d]\n", i, m_pNeighborList[i*6+0], m_pNeighborList[i*6+1],
														m_pNeighborList[i*6+2], m_pNeighborList[i*6+3],
														m_pNeighborList[i*6+4], m_pNeighborList[i*6+5] );
	}
}

void CSinWaterMesh::AddToNeighborList( int me, int neighbor )
{
	for( int i=0; i<6; i++ )
	{
		if( m_pNeighborList[me*6+i] == neighbor )
		{ //already in list
			return;
		}
		if( m_pNeighborList[me*6+i] == -1 )
		{
			m_pNeighborList[me*6+i] = neighbor;
			return;
		}
	}
}

int CSinWaterMesh::IsNeighborOf( int a, int b )
{
	for( int i=0; i<6; i++ )
	{
		if( m_pNeighborList[a*6+i] == -1 )
		{
			return FALSE;
		}
		else if( m_pNeighborList[a*6+i] == b )
		{
			return TRUE;
		}
	}
	//no neighbor found
	return FALSE;
}

void CSinWaterMesh::GridGen()
{
	InitNeighborList();
	InitFaceNormals();

	GenVB();
	GenIB();
	GenNormalLookupTable();
	CreateFaceNormals();

	//DAR:  Don't have to worry about the derivative method, because the technique which sums the wave derivatives
	//      doesn't use the face normals at all.
	if( m_bUseFastNormalLookup )
	{
        CalcPerVertexNormalsFastLookup();
	}
	else
	{
        CalcPerVertexNormals();
	}

	LoadD3D_VB();
	LoadD3D_IB();
}

void CSinWaterMesh::PrintVertNormals()
{
	for( int i=0; i<m_iNumRows*m_iNumCols; i++ )
	{
		printf( "m_pVB[%d].normal = %.2f %.2f %.2f\n",i, m_pVB[i].nx, m_pVB[i].ny, m_pVB[i].nz );
	}
}

void CSinWaterMesh::InitFaceNormals()
{
	m_pFaceNormals = new CVector3[(m_iNumRows-1)*(m_iNumCols-1)*2];
	
	for( int i=0; i<(m_iNumRows-1)*(m_iNumCols-1)*2; i++ )
	{
		m_pFaceNormals[i].Init( 0.0f, 0.0f, 0.0f );
	}
}

void CSinWaterMesh::CreateFaceNormals()
{
	//loop over how many faces there are
	int j=0;
	for( int i=0; i<(m_iNumRows-1)*(m_iNumCols-1)*6; i+=3 )
	{
		//create vector v-a, v-b
		CVector3 v2minusv0;
		CVector3 v1minusv0;
		v1minusv0.Init( m_pVB[m_pIB[i+1]].x - m_pVB[m_pIB[i]].x, m_pVB[m_pIB[i+1]].y - m_pVB[m_pIB[i]].y, m_pVB[m_pIB[i+1]].z - m_pVB[m_pIB[i]].z );
		v2minusv0.Init( m_pVB[m_pIB[i+2]].x - m_pVB[m_pIB[i]].x, m_pVB[m_pIB[i+2]].y - m_pVB[m_pIB[i]].y, m_pVB[m_pIB[i+2]].z - m_pVB[m_pIB[i]].z );
		v1minusv0.Cross( &v2minusv0, &m_pFaceNormals[j] );
		m_pFaceNormals[j].Normalize();
		j++;
	}
	//PrintFaceNormals();
}

void CSinWaterMesh::PrintFaceNormals()
{
	for(int i=0;i<(m_iNumRows-1)*(m_iNumCols-1)*2;i++)
	{
		printf("%d: %f %f %f\n", i, m_pFaceNormals[i].x, m_pFaceNormals[i].y, m_pFaceNormals[i].z);
	}
}

void CSinWaterMesh::GenVB()
{
	float fStepSizeAcrossRow = 1.0f / float( m_iNumCols-1 );
	float fStepSizeDownCol = 1.0f / float( m_iNumRows-1 );

	float fCurColVal = 0.0f;
	float fCurRowVal = 0.0f;

	if( m_pVB != NULL )
	{
		free( m_pVB );
		m_pVB = NULL;
	}
	m_pVB = ( CUSTOM_VERT_POS_NORMAL_TEXTURE0 *)malloc(m_iNumCols*m_iNumRows*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0) );

	for( int iCurRow = 0;iCurRow < m_iNumRows; iCurRow++ )
	{
		for( int iCurCol = 0;iCurCol < m_iNumCols; iCurCol++ )
		{
			//just flip these if you want row major
			m_pVB[iCurRow*m_iNumCols+iCurCol].x = fCurColVal;
			m_pVB[iCurRow*m_iNumCols+iCurCol].y = fCurRowVal;
			m_pVB[iCurRow*m_iNumCols+iCurCol].z = 0.0f;
			//texture coords
			m_pVB[iCurRow*m_iNumCols+iCurCol].tu = fCurColVal;
			m_pVB[iCurRow*m_iNumCols+iCurCol].tv = fCurRowVal;
			fCurColVal += fStepSizeAcrossRow;
		}
		fCurColVal = 0.0f;
		fCurRowVal += fStepSizeDownCol;
	}
}

//TODO: yes, d3d specific code should be removed
void CSinWaterMesh::LoadD3D_VB()
{
	int iResult = -1;
	
	iResult = m_pDevice->CreateVertexBuffer( m_iNumRows*m_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0), 
											 D3DUSAGE_WRITEONLY, 
											 D3D_FVF_CUSTOMVERTEX_POS_NORMAL_TEXTURE0, 
											 D3DPOOL_DEFAULT, 
											 &m_pVBD3D, 
											 NULL );
	if( iResult != D3D_OK )
	{
		printf( "Create VB Failed\n" );
	}

	//now fill VB
	VOID *pVerts = NULL;
	iResult = m_pVBD3D->Lock( 0, m_iNumRows*m_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0), (void **)&pVerts, 0 );
	if( iResult != D3D_OK )
	{
		printf( "Fill VB fail\n" );
	}
	memcpy( pVerts, m_pVB, m_iNumRows*m_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0) );
	m_pVBD3D->Unlock();
}

void CSinWaterMesh::ReloadVB()
{
	int iResult;
	//now fill VB
	VOID *pVerts = NULL;
	iResult = m_pVBD3D->Lock( 0, m_iNumRows*m_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0), (void **)&pVerts, 0 );
	if(iResult != D3D_OK)
	{
		printf( "Fill VB fail\n" );
	}
	memcpy( pVerts, m_pVB, m_iNumRows*m_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0) );
	m_pVBD3D->Unlock();
}

void CSinWaterMesh::LoadD3D_IB()
{
	int iResult = -1;
	int iBufSize = sizeof( short int ) * ( (m_iNumRows-1) * (m_iNumCols-1) * 6 );

	iResult = m_pDevice->CreateIndexBuffer( iBufSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &m_pIBD3D, NULL );

	if( iResult != D3D_OK )
	{
		printf( "Create IB failed\n" );
	}
	//now fill IB
	VOID *pIndices = NULL;
	iResult = m_pIBD3D->Lock( 0, iBufSize, (void **)&pIndices, 0 );
	if( iResult != D3D_OK )
	{
		printf( "Create IB failed\n" );
	}
	memcpy( pIndices, m_pIB, iBufSize );
	m_pIBD3D->Unlock();
}

void CSinWaterMesh::GenNormalLookupTable()
{
	// We're going to create a table that lists, for each vertex, the
	// triangles which that vertex is a part of.
	
	if( m_pNormalLookupTable != NULL )
	{
		free( m_pNormalLookupTable );
		m_pNormalLookupTable = NULL;
	}

	// Each vertex may be a part of up to 6 triangles in the grid, so 
	// create a buffer to hold a pointer to the normal of each neighbor.
	int buffersize = m_iNumRows*m_iNumCols*6;
	
	m_pNormalLookupTable = (int *)malloc( sizeof(void *) * buffersize );
	for( int i=0; i<buffersize; i++ )
		m_pNormalLookupTable[i] = -1;

	// Now that the table is initialized, populate it with the triangle data.

	// For each triangle
	//   For each vertex in that triangle
	//     Append the triangle number to lookuptable[vertex]
	for( int i=0; i < 2*(m_iNumRows-1)*(m_iNumCols-1); i++ )
	{
		for( int j=0; j<3; j++ )
		{
			// Find the next empty slot in the vertex's lookup table "slot"
			for( int k=0; k<6; k++ )
			{
				int vertex = m_pIB[i*3+j];
				if( m_pNormalLookupTable[vertex*6+k] == -1 )
				{
					//DXUTOutputDebugString(L"Vertex %d is part of tri %d\n",vertex,i );
					m_pNormalLookupTable[vertex*6+k] = i;
					break;
				}
			}
		}  // For each vertex that is part of the current triangle
	} // For each triangle
}

void CSinWaterMesh::GenIB()
{
	int i=0;

	if( m_pIB != NULL )
	{
		free( m_pIB );
		m_pIB = NULL;
	}

	m_pIB = (short int *)malloc( sizeof(short int) * (m_iNumRows-1) * (m_iNumCols-1) * 6 );

	i = 0;
	int iCurIndex = 0;
	for( int iCurRow = 0; iCurRow < m_iNumRows-1; iCurRow++ )
	{
		for( int iCurCol = 0; iCurCol < m_iNumCols-1; iCurCol++ )
		{
			int tri = ( iCurRow*m_iNumCols ) + iCurCol;
			iCurIndex = i;
			m_pIB[iCurIndex++] = tri;
			m_pIB[iCurIndex++] = tri+m_iNumCols+1;
			m_pIB[iCurIndex++] = tri+m_iNumCols;
			m_pIB[iCurIndex++] = tri;
			m_pIB[iCurIndex++] = tri+1;
			m_pIB[iCurIndex++] = tri+m_iNumCols+1;
			
			//add the indices to the neighborlist
			//this was calculated by looking at a grid and the neighbors
			//of a particular triangle
			AddToNeighborList( m_pIB[i+0], m_pIB[i+1] );
			AddToNeighborList( m_pIB[i+0], m_pIB[i+2] );
			AddToNeighborList( m_pIB[i+0], m_pIB[i+4] );

			AddToNeighborList( m_pIB[i+4], m_pIB[i+0] );
			AddToNeighborList( m_pIB[i+4], m_pIB[i+1] );
			
			AddToNeighborList( m_pIB[i+1], m_pIB[i+2] );
			AddToNeighborList( m_pIB[i+1], m_pIB[i+4] );
			AddToNeighborList( m_pIB[i+1], m_pIB[i] );

			AddToNeighborList( m_pIB[i+2], m_pIB[i+0] );
			AddToNeighborList( m_pIB[i+2], m_pIB[i+1] );
			
			i+=6;
		}
	}
}

void CSinWaterMesh::PrintVB()
{
	for( int i=0; i<m_iNumCols*m_iNumRows; i++ )
	{
		fprintf( stderr, "[%d], %.2f %.2f %.2f normal: %.2f, %.2f, %.2f\n", i, m_pVB[i].x, m_pVB[i].y, m_pVB[i].z, m_pVB[i].nx, m_pVB[i].ny, m_pVB[i].nz );
	}
}

void CSinWaterMesh::PrintIB()
{
	int tri=0;
	char buf[80];
	
	for( int i=0; i<((m_iNumRows-1)*(m_iNumCols-1)*6); i+=3 )
	{
		sprintf( buf, "Tri[%d] = %d %d %d\n", tri, m_pIB[i], m_pIB[i+1], m_pIB[i+2] );
		tri++;
		OutputDebugString( (LPWSTR)(buf) );
	}			
}

void CSinWaterMesh::CalcPerVertexNormalsFastLookup()
{
	// First, calculate the face normals for each triangle.
	CreateFaceNormals();

	// For each vertex, sum the normals indexed by the normal lookup table.
	for( int i=0; i < (m_iNumCols * m_iNumRows); i++ )
	{
		CVector3 avgNormal;
		avgNormal.Init( 0.0f, 0.0f, 0.0f );

		// Find all the triangles that this vertex is a part of.
		for( int j=0; j<6; j++ )
		{
			int triIndex;
			triIndex = m_pNormalLookupTable[i*6+j];
			
			// If the triangle index is valid, get the normal and average it in.
			if( triIndex != -1 )
			{
				CVector3 normal;
				LookupNormal( triIndex, &normal );
				avgNormal.AddVec3( &normal );
			}
			else
				break;
		}

		// Complete the averaging step by dividing & normalizing.
        avgNormal.DivConst( (float)(j) );
		avgNormal.Normalize();

		// Set the vertex normal to this new normal.
		m_pVB[i].nx = avgNormal.x;
		m_pVB[i].ny = avgNormal.y;
		m_pVB[i].nz = avgNormal.z;

	}  // For each vertex

#ifdef DAVID_OUTPUT_NORMALS
	if( m_bFirstNormalLookupThru )
	{
		DumpNormals( m_iFileNum, 0 );
		m_iFileNum++;
		m_bFirstNormalLookupThru = false;
	}
#endif
}

void CSinWaterMesh::CalcPerVertexNormals()
{
	//doubly nested loop: start at top of NeighborList (nx6 array)
	//if v != -1, get value, called a
	//for each value after that, get the next one, call it b (we'll go through all of them due to for loop in later iterations)
	//go to a neighbor list, if b in a's neighbor list, calculate a normal doing: 
	//store in temp vector = b-v cross a-v
	//go to next vertex (will be b)

	CreateFaceNormals();

	int v = -1;
	for( int i=0; i<m_iNumCols*m_iNumRows; i++ )
	{
		CVector3 avgNormal;
		avgNormal.Init( 0.0f, 0.0f, 0.0f );
	
		int iNormalCount = 0;
		v = i;
		float divisor = 1.0f;
		for( int j=0; j<6; j++ )
		{
			if( m_pNeighborList[i*6+j] != -1 )
			{
				int a = m_pNeighborList[i*6+j];
				//only need to go from j, everythign before been checked!
				for( int k=j+1; k<6; k++ )
				{
					if( m_pNeighborList[i*6+k] != -1 )
					{
						int b = m_pNeighborList[i*6+k];
						//check to see if its a neighbor of a
						int result = IsNeighborOf( a, b );
						//if they are neighbors compute the normal
						if( result == TRUE )
						{
							//lookup triangle index
							int triIndex = LookupTriIndex( v, a, b );
							
							//get its normal
							CVector3 normal;
							LookupNormal( triIndex,&normal );
							//already normalized, just compute avg.
							avgNormal.AddVec3( &normal );
							divisor += 1.0f;
						}
					}
					else
					{ //end of list
						break;
					}
				} //for loop over the rest of the neighbor list (k=j)
			}
		}  // for loop over neighbors (j)


		//average the normals
        avgNormal.DivConst( divisor );
		avgNormal.Normalize();
		//set the vertex normal to this new normal
		m_pVB[i].nx = avgNormal.x;
		m_pVB[i].ny = avgNormal.y;
		m_pVB[i].nz = avgNormal.z;

	} //for loop over the verts (i)
}

int CSinWaterMesh::LookupTriIndex( int v1, int v2, int v3 )
{
	int index = 0;
	for( int i=0; i<(m_iNumRows-1)*(m_iNumCols-1)*6; i+=3 )
	{
		if( m_pIB[i] == v1 || m_pIB[i+1] == v1 || m_pIB[i+2] == v1 )
			if( m_pIB[i] == v2 || m_pIB[i+1] == v2 || m_pIB[i+2] == v2 )
				if( m_pIB[i] == v3 || m_pIB[i+1] == v3 || m_pIB[i+2] == v3 )
					return index;
		index++;
	}
	return -1;
}

void CSinWaterMesh::LookupNormal( int v1, CVector3 *res )
{
	res->x = m_pFaceNormals[v1].x;
	res->y = m_pFaceNormals[v1].y;
	res->z = m_pFaceNormals[v1].z;
}

void CSinWaterMesh::CreateWaveAtEdge( float size )
{
	//walk along a particular edge and adjust the z values by size
	//were going to walk along the 0 edge

	for( int i=0; i<m_iNumRows; i++ )
	{
		m_pVB[i*m_iNumCols+1].z = .05f;
	}
}

void CSinWaterMesh::CreateWaveAtVertex( int x, int y, float size )
{
	m_pVB[x*m_iNumCols+y].z = size;
}

void CSinWaterMesh::TakeStepSumOfWavesWithExp( float t, int numOfWavesToSum )
{
	for( int i=0; i<m_iNumRows; i++ )
	{
		for( int j=0; j<m_iNumCols; j++ )
		{
			for( int k=0; k<numOfWavesToSum; k++ )
			{
				CVector3 posVect;
				float dotresult = 0.0f;
				float phase_constant = 0.0f;
				float final = 0.0f;

				posVect.Init( m_pVB[i*m_iNumCols+j].x, m_pVB[i*m_iNumCols+j].y, 0.0f );

				if( m_bSumWave[k] )
				{
					dotresult = m_direction[k].Dot( &posVect );
					dotresult *= ( 2*(float)MYPI ) / m_wavelength[k];
					phase_constant = t*( (m_speed[k]*2*(float)MYPI) / m_wavelength[k] );
					final = ( dotresult + phase_constant );
					final = ( sin(final) + 1.0f ) / 2.0f;
					final = m_amplitude[k] * pow( final, m_kexp[k] );
				}

				if( k!=0 ) 
				{
					m_pVB[i*m_iNumCols+j].z += final;
				}
				else
				{
					// The first wave calculated will overwrite the summation from the last frame.
					m_pVB[i*m_iNumCols+j].z = final;
				}
			}
		}
	}

	// There are several ways to calculate the normals:
	//   Calculate the d/dx and d/dy of the waves and sum them.
	//   Look up the adjacent face normals and sum them.
	//   Scan the mesh for triangles containing this vertex and sum the face normals. (REALLY SLOW).
	if( m_bUseWaveDerivative )
	{
		CalcPerVertexNormalsWaveDerivative( t );
	}
	else if( m_bUseFastNormalLookup )
	{
	    CalcPerVertexNormalsFastLookup();
	}
	else
	{
		CalcPerVertexNormals();
	}
}

CSinWaterMesh::~CSinWaterMesh()
{
	DeleteWater();
}

void CSinWaterMesh::DeleteWater()
{
	//TODO: check for NULL pointers before delete!
	if( m_pNormalLookupTable )
	{
		free( m_pNormalLookupTable );
		m_pNormalLookupTable = NULL;
	}
	if( m_pIB )
	{
		free( m_pIB );
		m_pIB = NULL;
	}
	if( m_pVB )
	{
		free( m_pVB );
		m_pVB = NULL;
	}

	if( m_pIBD3D != NULL )
	{
		m_pIBD3D->Release();
		m_pIBD3D = NULL;
	}
	if( m_pVBD3D != NULL )
	{
		m_pVBD3D->Release();
		m_pVBD3D = NULL;
	}
	if( m_pVBD3D != NULL )
	{
		m_pVBD3D->Release();
		m_pVBD3D = NULL;
	}
	if( m_pNeighborList != NULL )
	{
		free( m_pNeighborList );
		m_pNeighborList = NULL;
	}
	if( m_pFaceNormals != NULL )
	{
		delete m_pFaceNormals;
		m_pFaceNormals = NULL;
	}
	
	m_iNumRows = -1;
	m_iNumCols = -1;

	DeleteCriticalSection( &m_csCriticalSection );
}

void CSinWaterMesh::OnLostDevice()
{
	DeleteWater();
}

void CSinWaterMesh::OnResetDevice(IDirect3DDevice9 *pDevice, int iNumRows, int iNumCols )
{
	Initialize( pDevice,iNumRows, iNumCols );
}

void CSinWaterMesh::SetWaveLength(float val, int index)
{
	m_wavelength[index] = val;
}

void CSinWaterMesh::SetAmplitude(float val, int index)
{
	m_amplitude[index] = val;
}

void CSinWaterMesh::SetSpeed(float val, int index)
{
	m_speed[index] = val;
}

void CSinWaterMesh::SetKExp(float val, int index)
{
	m_kexp[index] = val;
}

// since the slider deals in integers, it's easier to have the slider supply the angle 
// in degrees, and then convert to radians.
void CSinWaterMesh::SetDirection(float val, int index)
{
	float angle;

	// convert deg to radians
	angle = (float)(( val / 360.0f ) * 2.0f * MYPI);
	
	CVector3 unitvector;
    unitvector.Init( 1, 0, 0 );

	m_direction[index].x = ( unitvector.x * cos(angle) ) - ( unitvector.y * sin(angle) );
	m_direction[index].y = ( unitvector.y * cos(angle) ) + ( unitvector.x * sin(angle) );
}

void CSinWaterMesh::SetSumWave(bool val, int index)
{
	m_bSumWave[index] = val;
}

float CSinWaterMesh::GetWaveLength(int index)
{
	return m_wavelength[index];
}

float CSinWaterMesh::GetAmplitude(int index)
{
	return m_amplitude[index];
}

float CSinWaterMesh::GetSpeed(int index)
{
	return m_speed[index];
}

float CSinWaterMesh::GetKExp(int index)
{
	return m_kexp[index];
}

//TODO:  convert direction vector to a float ranging from 0 to 1.
float CSinWaterMesh::GetDirection(int index)
{
	float angle;

	CVector3 unitvector;
	unitvector.Init( 1, 0, 0);

	angle = acos( m_direction[index].Dot(&unitvector) );
	angle = (float)(( angle / (2.0f * MYPI) ) * 360.0f);
	
	// Need to 
	if( m_direction[index].y < 0 )
	{
		angle += 2 * (180 - angle);
	}

	return angle;
}
bool CSinWaterMesh::GetSumWave(int index)
{
	return m_bSumWave[index];
}

void CSinWaterMesh::TakeStepThread( float* pTime )
{
	// Until told to exit
	//     Update the global VB
	//     Indicate that update is finished
	//     Wait for VB to be consumed  (stop waiting if told to exit!)
	while( !m_vlExitThread )
	{
		TakeStepSumOfWavesWithExp( *pTime, NUM_WAVES );
		//TODO:  See if I can remove this explicit signaling, and just put this thread to sleep when done.
		//       Can parent determine that child has suspended itself?
		*pTime += .08f;
		m_vlStepDone = true;
		while( m_vlStepDone && !m_vlExitThread )
		{
			// Wait until the current grid has been consumed before computing another
			Sleep(0);
		}		
	}

#ifndef DAVID_THREADSAFE
	m_vlStepDOne = true;
	m_vlExitThread = false;
	m_vlThreadLaunched = false;
#else 
	#ifdef DAVID_THREADSAFE_CRITICAL_SECTION
	EnterCriticalSection( &m_csCriticalSection );
	m_vlStepDOne = true;
	m_vlExitThread = false;
	m_vlThreadLaunched = false;
	LeaveCriticalSection( &m_csCriticalSection );
	#else
	InterlockedIncrement( &m_vlStepDone );
	InterlockedDecrement( &m_vlExitThread );
	InterlockedDecrement( &m_vlThreadLaunched );
	#endif
#endif
}

void CSinWaterMesh::ResetStepDone()
{
#ifndef DAVID_THREADSAFE
	m_vlStepDone = false;
#else 
	#ifdef DAVID_THREADSAFE_CRITICAL_SECTION
	EnterCriticalSection( &m_csCriticalSection );
	m_vlStepDone = false;
	LeaveCriticalSection( &m_csCriticalSection );
	#else
	InterlockedDecrement( &m_vlStepDone );
	#endif
#endif
}

void CSinWaterMesh::SetExitThread()
{
#ifndef DAVID_THREADSAFE
	m_vlExitThread = true;
#else 
	#ifdef DAVID_THREADSAFE_CRITICAL_SECTION
	EnterCriticalSection( &m_csCriticalSection );
	m_vlExitThread = true;
	LeaveCriticalSection( &m_csCriticalSection );
	#else
	InterlockedIncrement( &m_vlExitThread );
	#endif
#endif
}

void CSinWaterMesh::SetTakeStepThreaded()
{
#ifndef DAVID_THREADSAFE
	m_vlThreadLaunched = true;
#else 
	#ifdef DAVID_THREADSAFE_CRITICAL_SECTION
	EnterCriticalSection( &m_csCriticalSection );
	m_vlThreadLaunched = true;
	LeaveCriticalSection( &m_csCriticalSection );
	#else
	InterlockedIncrement( &m_vlThreadLaunched );
	#endif
#endif
}

void CSinWaterMesh::CopyVBToRenderVB( void )
{
	ReloadVB();
}

void CSinWaterMesh::CalcPerVertexNormalsWaveDerivative( float time )
{
	for( int i=0; i<m_iNumCols*m_iNumRows; i++ )
	{
		float numactivewaves = 0.0f;
		CVector3 avgNormal;
		avgNormal.Init( 0.0f,0.0f,0.0f );
	
		// Calculate the normal by taking the partial derivative of
		// each wave with respect to x and y at that vertex, and use
		// those values for the x and y of the vertex normal.
		for( int j=0; j<NUM_WAVES; j++ )
		{
			CVector3 normal;
			if( m_bSumWave[j] )
			{
				numactivewaves += 1.0f;
				normal.x = -1.0f * PartialDerivativeX( i,j,time );
				normal.y = -1.0f * PartialDerivativeY( i,j,time );

				avgNormal.AddVec3( &normal );
			}
		}

		avgNormal.z = 1.0f;
		avgNormal.Normalize();

		m_pVB[i].nx = avgNormal.x;
        m_pVB[i].ny = avgNormal.y;
		m_pVB[i].nz = avgNormal.z;
	}

#ifdef DAVID_OUTPUT_NORMALS
	if( m_bFirstDerivativeThru )
	{
		DumpNormals( m_iFileNum, 1 );
		m_iFileNum++;
		m_bFirstDerivativeThru = false;
	}
#endif
}

float CSinWaterMesh::PartialDerivativeX( int vertex, int wave, float time )
{
	CVector3 posVect;
	float dotresult;
	float derivative;
	float costerm;
	float phase_constant;
	float sinterm;

	// First, do the simple math
	derivative = 0.5f;
	derivative *= m_kexp[wave];
	derivative *= m_direction[wave].x;
	derivative *= ( 2*(float)MYPI / m_wavelength[wave] );
	derivative *= m_amplitude[wave];

	// Now compute the term with the cos
	posVect.Init(m_pVB[vertex].x, m_pVB[vertex].y, 0.0f);
	dotresult = m_direction[wave].Dot(&posVect);
	dotresult *= ( 2*(float)MYPI / m_wavelength[wave] );
	phase_constant = time * ( (m_speed[wave]*2*(float)MYPI)/m_wavelength[wave] );
	costerm = cos( dotresult+phase_constant );
	
	// Put the costerm into the equation
	derivative *= costerm;

	// If there is an exponent, there is more math to do.
	if( m_kexp[wave] != 1 )
	{
		//  Compute the term with the sin
		sinterm = sin( dotresult+phase_constant );
		sinterm = pow( (sinterm+1.0f)/2.0f, m_kexp[wave]-1 );

		// Put the sinterm into the equation
		derivative *= sinterm;
	}

	return derivative;
}

float CSinWaterMesh::PartialDerivativeY( int vertex, int wave, float time )
{
	CVector3 posVect;
	float dotresult;
	float derivative;
	float costerm;
	float phase_constant;
	float sinterm;

	// First, do the simple math
	derivative = 0.5f;
	derivative *= m_kexp[wave];
	derivative *= m_direction[wave].y;
	derivative *= ( 2*(float)MYPI / m_wavelength[wave] );
	derivative *= m_amplitude[wave];

	// Now compute the term with the cos
	posVect.Init(m_pVB[vertex].x, m_pVB[vertex].y, 0.0f);
	dotresult = m_direction[wave].Dot(&posVect);
	dotresult *= ( 2*(float)MYPI / m_wavelength[wave] );
	phase_constant = time * ( (m_speed[wave]*2*(float)MYPI)/m_wavelength[wave] );
	costerm = cos( dotresult+phase_constant );
	
	// Put the costerm into the equation
	derivative *= costerm;

	// If there is an exponent, there is more math to do.
	if( m_kexp[wave] != 1 )
	{
		//  Compute the term with the sin
		sinterm = sin( dotresult+phase_constant );
		sinterm = pow( (sinterm+1.0f)/2.0f, m_kexp[wave]-1 );

		// Put the sinterm into the equation
		derivative *= sinterm;
	}

	return derivative;
}

void CSinWaterMesh::DumpNormals(int filenum, int method)
{
	char filename[256];
	sprintf(filename, "normal_dump_file_%d.csv", filenum); filename[255] = '\0';

	FILE* fp = fopen(filename, "w+");

	fprintf(fp, "\tGrid Size %dx%d\n", m_iNumRows, m_iNumCols);

	if(method == 0)
		fprintf(fp, "\tFast Lookup\n");
	else if(method == 1)
		fprintf(fp, "\tDerivatives\n");

	fprintf(fp, "Vertex, Normal.x, Normal.y, Normal.z\n");

	for( int i = 0; i < (m_iNumCols * m_iNumRows); i++ )
	{
		fprintf(fp, "%d, %f, %f, %f\n", i, m_pVB[i].nx, m_pVB[i].ny, m_pVB[i].nz);
	}

	fclose(fp);

	sprintf(filename, "position_dump_file_%d.csv", filenum); filename[255]='\0';

	fp = fopen(filename, "w+");

	fprintf(fp, "Vertex, X, Y, Z\n");

	for( int j=0; j < (m_iNumCols * m_iNumRows); j++ )
	{
		fprintf(fp, "%d, %f, %f, % f\n", j, m_pVB[j].x, m_pVB[j].y, m_pVB[j].z);
	}

	fclose(fp);
}