//-------------------------------------------------------------------------------------
//
// Copyright � 2004 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations a bout the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software not any
// responsibility to update it.
//
//-------------------------------------------------------------------------------------

#ifndef CSINWATERMESH_H
#define CSINWATERMESH_H

//class to generate a CGrid

#include "CUtil.h"
#include <stdlib.h>

#include <d3d9.h>

//NOTE:  Must be compiled with multithreaded MSVC++ libraries!
#include <process.h>

#include "d3ddatatypes.h"

#define TRUE 1
#define FALSE 0

#define MYPI 3.141592653589793

#define NUM_WAVES 4

#define WAVE_0_WAVELEN_DEFAULT		1.000f
#define WAVE_0_AMPLITUDE_DEFAULT	0.08f
#define WAVE_0_VELOCITY_DEFAULT		0.05f
#define WAVE_0_DIRECTION_DEFAULT	355.0f
#define WAVE_0_K_EXP_DEFAULT		10.0f

#define WAVE_1_WAVELEN_DEFAULT		0.620f
#define WAVE_1_AMPLITUDE_DEFAULT	0.07f
#define WAVE_1_VELOCITY_DEFAULT		0.06f
#define WAVE_1_DIRECTION_DEFAULT	155.0f
#define WAVE_1_K_EXP_DEFAULT		2.0f

#define WAVE_2_WAVELEN_DEFAULT		0.280f
#define WAVE_2_AMPLITUDE_DEFAULT	0.06f
#define WAVE_2_VELOCITY_DEFAULT		0.04f
#define WAVE_2_DIRECTION_DEFAULT	200.0f
#define WAVE_2_K_EXP_DEFAULT		1.0f

#define WAVE_3_WAVELEN_DEFAULT		0.500f
#define WAVE_3_AMPLITUDE_DEFAULT	0.08f
#define WAVE_3_VELOCITY_DEFAULT		0.05f
#define WAVE_3_DIRECTION_DEFAULT	5.0f
#define WAVE_3_K_EXP_DEFAULT		3.0f

class CSinWaterMesh {
public:
	CSinWaterMesh(IDirect3DDevice9 *pDevice, int iNumRows, int iNumCols);
	CSinWaterMesh(IDirect3DDevice9* pDevice, int iNumRows, int iNumCols, long lThreadLaunched, bool bUseWaveDerivative, bool bUseFastNormalLookup, bool *bSumWave);
	~CSinWaterMesh();
	
    void Initialize(IDirect3DDevice9 *pDevice, int iNumRows, int iNumCols);
	void Initialize(IDirect3DDevice9* pDevice, int iNumRows, int iNumCols, long lThreadLaunched, bool bUseWaveDerivative, bool bUseFastNormalLookup, bool *bSumWave);
	void InitializeWave(int index, float wavelength, float amplitude, float speed, CVector3 *direction, float kexp);
	void  GridGen();

	void PrintVB();
	void PrintIB();
	void PrintFaceNormals();
	void PrintVertNormals();
	
	int LookupTriIndex(int v1, int v2, int v3);
	void PrintNeighborList();	
	void InitFaceNormals();
	void CreateFaceNormals();
	void CalcPerVertexNormals();
	void CalcPerVertexNormalsFastLookup();
	void CalcPerVertexNormalsWaveDerivative( float time );

	void LookupNormal(int v1, CVector3 *res);
	void ComputeBoundingSphere(CVector3 *ctr, float *radius);
	void ComputeBoundingBox(CVector3 *bb);
	void ComputeOrigin(CVector3 *ctr);

	//water related functions
	void CreateWaveAtEdge(float size);
	void CreateWaveAtVertex(int x, int y, float size);
	void TakeStepSumOfWavesWithExp(float dt, int numWavesToSum);

	float PartialDerivativeX( int vertex, int wave, float time );
	float PartialDerivativeY( int vertex, int wave, float time );

	void SetWaveLength(float val, int index);
	void SetAmplitude(float val, int index);
	void SetSpeed(float val, int index);
	void SetKExp(float val, int index);
	void SetDirection(float val, int index);
	void SetSumWave(bool val, int index);

	// Retrieve waveform settings
	float GetWaveLength(int index);
	float GetAmplitude(int index);
	float GetSpeed(int index);
	float GetKExp(int index);
	float GetDirection(int index);
	bool  GetSumWave(int index);

	void OnLostDevice();
	void OnResetDevice(IDirect3DDevice9 *pDevice, int iNumRows, int iNumCols);

	LPDIRECT3DVERTEXBUFFER9 GetD3DVB();
	LPDIRECT3DINDEXBUFFER9 GetD3DIB();
	
	long IsTakeStepThreaded( void ) { return m_vlThreadLaunched; } //Is TakeStepX() being run as a separate thread?
	long IsStepDone( void )         { return m_vlStepDone; }	   //Is VB ready?
	void ResetStepDone( void );                                    //VB has been consumed, compute another
	void SetTakeStepThreaded( void );                              //Parent responsible for setting this, to avoid race cond.
	void SetExitThread( void );                                    //Stop computing VBs, end thread

	bool UsingWaveDerivative( void )	{ return m_bUseWaveDerivative; }	//Using derivative of wave function to compute vertex normals?
	void SetUseWaveDerivative( void )	{ m_bUseWaveDerivative = true; }
	void ResetUseWaveDerivative( void )	{ m_bUseWaveDerivative = false; }

	bool UsingFastLookup( void )		{ return m_bUseFastNormalLookup; }	//Using a lookup table to average adjacent triangle face normals?
	void SetUseFastLookup( void )		{ m_bUseFastNormalLookup = true; }
	void ResetUseFastLookup( void )		{ m_bUseFastNormalLookup = false; }

    void TakeStepThread( float* );
	void CopyVBToRenderVB( void );

	int  GetCurrentNumRows( void )		{ return m_iNumRows; }
	int  GetCurrentNumCols( void )		{ return m_iNumCols; }
	
	void SetFirstTime(void) { m_bFirstDerivativeThru = true; m_bFirstNormalLookupThru = true; }

private:
	void GenVB();
	void GenIB();
	void GenNormalLookupTable();
	void GenVertexNeighborList();
	void InitNeighborList();
	void InitVertexNeighborList();
	void CreateNeighborList();
	void AddToNeighborList(int me, int myNeighbor);
	int IsNeighborOf(int a, int b);
	void LoadD3D_VB();
	void LoadD3D_IB();
	void PrintD3D_VB();
	void PrintD3D_IB();
	void ReloadVB();
	void DeleteWater();
	
	void DumpNormals(int filenum, int method);
	
	int m_iFileNum;
	bool m_bFirstDerivativeThru;
	bool m_bFirstNormalLookupThru;
	
	//number of verts in a row == iNumCols
	int m_iNumCols;
	//number of verts in a col == iNumRows
	int m_iNumRows;

	short int *m_pIB;

	//lookup table for the normals which will be averaged for each vertex
	int *m_pNormalLookupTable;

	CUSTOM_VERT_POS_NORMAL_TEXTURE0 *m_pVB;
	int *m_pNeighborList;
	CVector3 *m_pFaceNormals;

	CRITICAL_SECTION m_csCriticalSection;
	volatile long m_vlThreadLaunched;
    volatile long m_vlStepDone;	       //allows parent to consume VB when true, child recomputes VB when false
	volatile long m_vlExitThread;	   //parent sets this true to tell child to terminate (OnReset, for example)

	//controls how vertex normals are calculated
	bool m_bUseWaveDerivative;
	bool m_bUseFastNormalLookup;

	LPDIRECT3DVERTEXBUFFER9 m_pVBD3D;
	LPDIRECT3DINDEXBUFFER9 m_pIBD3D;
	IDirect3DDevice9 *m_pDevice;

	//wave parameters
	float m_wavelength[NUM_WAVES];		//crest to crest distance in world space, frequency = (2*pi)/wavelength
	float m_amplitude[NUM_WAVES];		//height from water plane to wave crest
	float m_speed[NUM_WAVES];			//distance crest moves forward per second
	float m_kexp[NUM_WAVES];			//exponent to create choppy waves
	
	CVector3 m_direction[NUM_WAVES];	//horizontal vectdor perpendicular to wave front along which crest travels
	
	bool m_bSumWave[NUM_WAVES];			//whether to include this wave in the wave equation
};

#endif