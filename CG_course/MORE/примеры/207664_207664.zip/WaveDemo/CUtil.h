//-------------------------------------------------------------------------------------
//
// Copyright � 2004 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations a bout the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software not any
// responsibility to update it.
//
//-------------------------------------------------------------------------------------

#ifndef CUTIL_H
#define CUTIL_H

#include <math.h>
#include <stdio.h>

class CColor3 {
public:
	float r;
	float g;
	float b;

public:
	void Negate()			{ r = -1.0f*r; g = -1.0f*g; b = -1.0f*b; }
	void MultConst(float f)	{ r = f*r;g=f*g;b=f*b; }
	void AddConst(float f)	{ r = f+r;g=f+g;b=f+b; } 
	void DivConst(float f)	{ r = r/f;g=g/f;b=b/f; }
	void SubConst(float f)	{ r = r-f;g=g-f;b=b-f; } 
	
	void MultColor(CColor3* c)	{ r=r*c->r;g=g*c->g;b=b*c->b; }
	void AddColor(CColor3 c)	{ r=r+c.r;g=g+c.g;b=b+c.b; }
	void DivColor(CColor3 c)	{ r=r/c.r;g=g/c.g;b=b/c.b; }
	void SubColor(CColor3 c)	{ r=r-c.r;g=g-c.g;b=b-c.b; }

	CColor3 *GetColorPtr()	{return this;}
};

class CVector2 {
public:
	void Negate()			{ x = -1.0f*x; y = -1.0f*y; }
	void MultConst(float f)	{ x = f*x;y=f*y; }
	void AddConst(float f)	{ x = f+x;y=f+y; } 
	void DivConst(float f)	{ x = x/f;y=y/f; }
	void SubConst(float f)	{ x = x-f;y=y-f; } 
	
	void MultVec2(CVector2 c)	{ x=x*c.x;y=y*c.y; }
	void AddVec2(CVector2 c)	{ x=x+c.x;y=y+c.y; }
	void DivVec2(CVector2 c)	{ x=x/c.x;y=y/c.y; }
	void SubVec2(CVector2 c)	{ x=x-c.x;y=y-c.y; }
	
	CVector2 *GetVector2Ptr()	{return this;}

	float x;
	float y;
};

class CVector3 {
public:
	void Init		( float xin, float yin, float zin) {x = xin;y = yin;z = zin; }
	void Negate()	{ x =-1.0f*x; y=-1.0f*y; z=-1.0f*z; }
	void Normalize() 
	{ 
		float f = (float)sqrt((x*x)+(y*y)+(z*z));
		x = x/f;y=y/f;z=z/f;
	}; 
	//does not effect 'this' vector, just returns a normalized version of it
	void GetNormalized(CVector3 *v) 
	{
		float f = (float)sqrt((x*x)+(y*y)+(z*z));
		v->x = x/f;v->y=y/f;v->z=z/f;
	};
	void MultConst(float f)	{ x = f*x;y=f*y;z=f*z; }
	void AddConst(float f)	{ x = f+x;y=f+y;z=z+z; } 
	void DivConst(float f)	{ x = x/f;y=y/f;z=z/f; }
	void SubConst(float f)	{ x = x-f;y=y-f;z=z-f; } 
	
	void MultVec3(CVector3* c)	{ x=x*c->x;y=y*c->y;z=z*c->z; }
	void AddVec3(CVector3* c)	{ x=x+c->x;y=y+c->y;z=z+c->z; }
	void DivVec3(CVector3* c)	{ x=x/c->x;y=y/c->y;z=z/c->z; }
	void SubVec3(CVector3* c)	{ x=x-c->x;y=y-c->y;z=z-c->z; }
	void SubVec3(CVector3* c, CVector3 *res) { res->x=x-c->x;res->y=y-c->y;res->z=z-c->z; }
	
	float Dot(CVector3 *v)	{ return v->x*x + v->y*y + v->z*z; }
	float DotSelf()			{ return (x*x + y*y + z*z); }
	void Cross(CVector3 *v, CVector3 *res)	{ res->x = y*v->z-z*v->y;res->y=z*v->x-x*v->z;res->z=x*v->y-y*v->x; }

	
	void ReflectVectorAboutNormal(CVector3 *vin, CVector3 *normal, CVector3 *vout)
	{
		float d_dot_n  = normal->Dot(vin);
		float nsquared = normal->DotSelf();
		float scalar   = 2*(d_dot_n / nsquared);

		vout->x = vin->x - (scalar * normal->x);
		vout->y = vin->y - (scalar * normal->y);
		vout->z = vin->z - (scalar * normal->z);
	}

	CVector3 *GetVector3Ptr()	{return this;}

	float x;
	float y;
	float z;
};

class CRay3 {
public:
	CVector3 o; //origin
	CVector3 d; //direction

	void Init(CVector3 *oin, CVector3 *din)
	{
		o.x = oin->x;o.y = oin->y;o.z = oin->z;
		d.x = din->x;d.y = din->y;d.z = din->z;
	}
	
	void PointAtParameter(float t, CVector3 *result) {
		result->x = o.x+t*d.x;
		result->y = o.y+t*d.y;
		result->z = o.z+t*d.z;
	}

	void PrintRay()
	{
		printf("O:%.2f %.2f %.2f\n",o.x,o.y,o.z);
		printf("D:%.2f %.2f %.2f\n",d.x,d.y,d.z);
	}
};

class CInterval{
public:
	float min;
	float max;

	bool IsWithin(float t) 
	{
		if (t>=min && t<=max) return true;
		else return false;
	};

	bool IntervalsOverlap(CInterval *interval) {
		if(interval->min > min && interval->min < max) return true;
		if(interval->max > min && interval->max < max) return true;
		else return false;
	};

	CInterval *ComputeOverlap(CInterval *interval, CInterval *result) {
			if(interval->min > min) 
				result->min = interval->min;
			else result->min = min;
			if(interval->max > max) 
				result->max = interval->max;
			else result->max = max;
	};
};

//orthonormal basis utility class
/*
u=a/norma
w=axb/normaxb
v=wxu
*/
class ONB
{
public:
	CVector3 u,v,w;

	void fromUV(CVector3 *a, CVector3 *b)
	{
		//u
		a->GetNormalized(&u);
		//w
		b->Cross(a,&w);
		w.Normalize();
		//v
		w.Cross(&u,&v);

	}
	void fromVU(CVector3 *a, CVector3 *b)
	{
		//TBD
	}
	void fromVW(CVector3 *a, CVector3 *b)
	{
		//TBD
	}
	void fromWV(CVector3 *a, CVector3 *b)
	{
		//TBD
	}
	void fromUW(CVector3 *g, CVector3 *vup)
	{
		//w
		g->GetNormalized(&w);
		w.x = -w.x;w.y = -w.y; w.z = -w.z;
		//u
		vup->Cross(&w, &u);
		u.Normalize();
		//v
		w.Cross(&u, &v);

	}
	
	//makes w parallel to a
	void fromW(CVector3 *a)
	{
		a->GetNormalized(&w);
		if((fabs(w.x) < fabs(w.y)) && (fabs(w.x) < fabs(w.z)))
		{
			v.x = 0.0f;
			v.y = w.z;
			v.z = -w.y;
			v.Normalize();
		}
		else if(fabs(w.y) < fabs(w.z))
		{
			v.x = w.z;
			v.y = 0.0f;
			v.z = -w.x;
			v.Normalize();
		}
		else
		{
			v.x = w.y;
			v.y = -w.x;
			v.z = 0.0f;
			v.Normalize();
		}
		//u = v x w
		v.Cross(&w, &u);

	}

	void PrintONB()
	{
		printf("%.2f %.2f %.2f\n",u.x,u.y,u.z);
		printf("%.2f %.2f %.2f\n",v.x,v.y,v.z);
		printf("%.2f %.2f %.2f\n",w.x,w.y,w.z);

	}
	
};

class CCamera
{
public:
	ONB onb; 
	CVector3 eye;
	CVector3 gaze;
	CVector3 vup;
	float s; //distance from e (eye) to the view rectangle
	float au, av, bu, bv; //uv coordinates of the rectangle corners of view rectangle
	int nx, ny;


	void SetDistanceToViewRectangle(float dist) { s = dist;}
	void SetViewWindowCoords(float auin, float avin, float buin, float bvin)
	{ au = auin; av = avin; bu = buin; bv = bvin;}
	//NOTE: remember to reverse gaze direction before passing in here
	//gaze goes from eye to view plane!!
	void SetGazeDir(CVector3 *gazedir)
	{
		gaze.x = gazedir->x;gaze.y = gazedir->y;gaze.z = gazedir->z;
		//gaze was reset, reset ONB
		onb.fromUW(gazedir, &vup);
	
	}
	void SetNumPixels(int nxin, int nyin) {nx = nxin;ny=nyin;}
	void SetEye(CVector3 *eyein) 
	{
		eye.x = eyein->x;eye.y = eyein->y;eye.z=eyein->z;
	}
	
	void SetUpVector(float x, float y, float z)
	{
		vup.x = x;vup.y=y;vup.z=z;
	}

	
	//NOTE: remember to reverse gaze direction before passing in here
	//gaze goes from eye to view plane!!
	void MakeONBFromWV(CVector3 *gazedir, CVector3 *vupin)
	{
		gaze.x = gazedir->x;gaze.y = gazedir->y;gaze.z = gazedir->z;
		vup.x = vupin->x;vup.y = vupin->y;vup.z = vupin->z;
		onb.fromUW(gazedir, vupin);

		
	}

	void MakeONB()
	{
		onb.fromUW(&gaze, &vup);
	}

	void xFormVectorToONB(CVector3 *in, int i, int j,CVector3 *out)
	{
		CVector3 *u = &onb.u;
		CVector3 *v = &onb.v;
		CVector3 *w = &onb.w;

		//scale it
		float scale_u = au + ((bu - au) * ((float)i/((float)(nx)-1.0f)));
		float scale_v = av + ((bv - av) * ((float)j/((float)(ny)-1.0f)));
		float scale_w = -s;
		u->MultConst(scale_u);
		v->MultConst(scale_v);
		w->MultConst(scale_w);

		//multiply each component of the vector by the ONB
		out->x = u->x * in->x + u->y * in->y + u->z * in->z;
		out->y = v->x * in->x + v->y * in->y + v->z * in->z;
		out->z = w->x * in->x + w->y * in->y + w->z * in->z;

		

	}
	void xFormPointToONB(CVector3 *pin, CVector3 *pout)
	{
		//just add the xlation component
		pout->x = pin->x + eye.x;
		pout->y = pin->y + eye.y;
		pout->z = pin->z + eye.z;
	}
	void xFormRayToONB(CRay3 *ray, CRay3 *result, int i, int j)
	{
		xFormVectorToONB(&(ray->d),i,j,&(ray->d));
		xFormPointToONB(&(ray->o),&(ray->o));
	}

	void PrintCam()
	{
		printf("Eye: %.2f %.2f %.2f\n",eye.x,eye.y,eye.z);
		printf("Gaze: %.2f %.2f %.2f\n",gaze.x,gaze.y,gaze.z);
		printf("Vup: %.2f %.2f %.2f\n",vup.x,vup.y,vup.z);
		onb.PrintONB();
		printf("Dist To Viewport: %.2f\n",s);
		printf("Pix: %d by %d\n", nx,ny);
		printf("UV Coords of Rectangle Corners: %f %f %f %f\n",au,av,bu,bv);
	}
	void GetRay(int i, int j, CRay3 *ray)
	{
		ray->o.x = eye.x;
		ray->o.y = eye.y;
		ray->o.z = eye.z;
		//scale it
		float scale_u = au + ((bu - au) * ((float)i/((float)(nx)-1.0f)));
		float scale_v = av + ((bv - av) * ((float)j/((float)(ny)-1.0f)));
		float scale_w = -s;

	//ray->PrintRay();

		ray->d.x = scale_u * onb.u.x; 
		ray->d.y = scale_u * onb.u.y ; 
		ray->d.z = scale_u * onb.u.z;

		ray->d.x += scale_v * onb.v.x; 
		ray->d.y += scale_v * onb.v.y ; 
		ray->d.z += scale_v * onb.v.z;
		
		ray->d.x += scale_w * onb.w.x; 
		ray->d.y += scale_w * onb.w.y ; 
		ray->d.z += scale_w * onb.w.z;

	//	ray->d.Normalize();  NO!!!
	//	printf("%.2f %.2f %.2f\n",ray->d.x, ray->d.y, ray->d.z);
	}

};

class Frame
{
public:
	ONB onb;
	CVector3 point;


};

class Matrix4x4
{
public:
	float m[4][4];
	float n[4][4];  //N = (M^-1)^T

	void xformLocation(CVector3 *o, CVector3 *res)
	{
		res->x = m[0][0]*o->x + m[0][1]*o->y + m[0][2] * o->z + m[0][3];
		res->y = m[1][0]*o->x + m[1][1]*o->y + m[1][2] * o->z + m[1][3];
		res->z = m[2][0]*o->x + m[2][1]*o->y + m[2][2] * o->z + m[2][3];
	}
	void xformOrigin(CVector3 *o, CVector3 *res)
	{
		res->x = m[0][0]*o->x + m[0][1]*o->y + m[0][2] * o->z;
		res->y = m[1][0]*o->x + m[1][1]*o->y + m[1][2] * o->z;
		res->z = m[2][0]*o->x + m[2][1]*o->y + m[2][2] * o->z;
		
	}
	void xformNormal(CVector3 *v, CVector3 *res)
	{

	}

	void Init()
	{
		createIdentity();
	}
	void createIdentity()
	{
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++)
			{
				m[i][j] = 0.0f;
				n[i][j] = 0.0f;
			}
		}
		m[0][0] = m[1][1] = m[2][2] = m[3][3] = 1.0f;
		n[0][0] = n[1][1] = n[2][2] = n[3][3] = 1.0f;

	}
	void translate(float t)
	{
		m[0][3] = m[0][3] + t;
		m[1][3] = m[1][3] + t;
		m[2][3] = m[2][3] + t;
		m[3][3] = 1.0f;

	}
	void scale(float x, float y, float z)
	{
		m[0][0] *= x;
		m[1][1] *= y;
		m[2][2] *= z;
		m[3][3] = 1.0f;
	}

};

class CLight3
{
public:
	CColor3 diffuse;
	CVector3 pos;
	CVector3 dir;
};

#endif