//--------------------------------------------------------------------------------------
// File: DxStdAfx.cpp
//
// Desc: Source file that includes just the standard includes for the 
//       DirectX SDK samples
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"



