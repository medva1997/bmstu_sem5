//-------------------------------------------------------------------------------------
//
// Copyright � 2004 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations a bout the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software not any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// File: WaveDemo.cpp
//
// Modified from:
//--------------------------------------------------------------------------------------
// File: BasicHLSL.cpp
//
// This sample shows a simple example of the Microsoft Direct3D's High-Level 
// Shader Language (HLSL) using the Effect interface. 
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#define DUMMY_WORKLOAD 0
//#define DUMMY_WORKLOAD .25	// Workload 1
//#define DUMMY_WORKLOAD .5		// Workload 2
//#define DUMMY_WORKLOAD 1.3	// Workload 3

//Uncomment to debug pixel/vertex shaders
//#define DEBUG_PS
//#define DEBUG_VS


#include "resource.h"

#include "d3ddatatypes.h"
#include "CSinWaterMesh.h"
#include <fstream>

using namespace std;

LPDIRECT3DVERTEXBUFFER9 g_pVB = NULL;
LPDIRECT3DINDEXBUFFER9 g_pIB = NULL;

void printIB();
void printVB();

//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
ID3DXFont*              g_pFont = NULL;         // Font for drawing text
ID3DXSprite*            g_pSprite = NULL;       // Sprite for batching draw text calls
bool                    g_bShowHelp = true;     // If true, it renders the UI control text
CModelViewerCamera      g_Camera;               // A model viewing camera
ID3DXEffect*            g_pEffect = NULL;       // D3DX effect interface
ID3DXEffect*			g_pAdamEffect = NULL;	// atl: adam effect
ID3DXMesh*              g_pMesh = NULL;         // Mesh object
ID3DXMesh*              g_pArrowMesh = NULL;    // Mesh object

CSinWaterMesh*			g_pGrid = NULL;			// m_pGrid


float					g_time;
float					g_kexp;
int						g_iNumRows = 80;				
int						g_iNumCols = 80;
IDirect3DTexture9*      g_pMeshTexture = NULL;  // Mesh texture
CDXUTDialog             g_HUD;                  // manages the 3D UI
CDXUTDialog             g_SampleUI;             // dialog for sample specific controls
CDXUTDialog				g_WaveSpecificUI;		// dialog for wave specific controls
bool                    g_bEnablePreshader;     // if TRUE, then D3DXSHADER_NO_PRESHADER is used when compiling the shader
D3DXMATRIXA16           g_mWorldFix;

#define MAX_LIGHTS 3
CDXUTDirectionWidget	g_LightControl[MAX_LIGHTS];
float					g_fLightScale;
int						g_nNumActiveLights;
int						g_nActiveLight;

long					lThreadLaunched;
bool					bUseWaveDerivative;
bool					bUseFastNormalLookup;
bool*					bSumWave;

// display waveform controls
bool					g_bWave0Enable = false;
bool					g_bWave1Enable = false;
bool					g_bWave2Enable = false;
bool					g_bWave3Enable = false;


//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN    1
#define IDC_VIEWWHITEPAPER      2
#define IDC_TOGGLEREF           3
#define IDC_CHANGEDEVICE        4
#define IDC_ENABLE_PRESHADER    5
#define IDC_NUM_LIGHTS          6
#define IDC_NUM_LIGHTS_STATIC   7
#define IDC_ACTIVE_LIGHT        8
#define IDC_LIGHT_SCALE         9
#define IDC_LIGHT_SCALE_STATIC  10


#define IDC_WAVE_0_AMPLITUDE		11
#define IDC_WAVE_0_AMPLITUDE_STATIC 12
#define IDC_WAVE_0_VELOCITY			13
#define IDC_WAVE_0_VELOCITY_STATIC	14
#define IDC_WAVE_0_DIRECTION		15
#define IDC_WAVE_0_DIRECTION_STATIC 16
#define IDC_WAVE_0_K_EXP			17
#define IDC_WAVE_0_K_EXP_STATIC		18

#define IDC_WAVE_1_AMPLITUDE		19
#define IDC_WAVE_1_AMPLITUDE_STATIC 20
#define IDC_WAVE_1_VELOCITY			21
#define IDC_WAVE_1_VELOCITY_STATIC	22
#define IDC_WAVE_1_DIRECTION		23
#define IDC_WAVE_1_DIRECTION_STATIC 24
#define IDC_WAVE_1_K_EXP			25
#define IDC_WAVE_1_K_EXP_STATIC		26

#define IDC_WAVE_2_AMPLITUDE		27
#define IDC_WAVE_2_AMPLITUDE_STATIC 28
#define IDC_WAVE_2_VELOCITY			29
#define IDC_WAVE_2_VELOCITY_STATIC	30
#define IDC_WAVE_2_DIRECTION		31
#define IDC_WAVE_2_DIRECTION_STATIC 32
#define IDC_WAVE_2_K_EXP			33
#define IDC_WAVE_2_K_EXP_STATIC		34

#define IDC_WAVE_3_AMPLITUDE		35
#define IDC_WAVE_3_AMPLITUDE_STATIC 36
#define IDC_WAVE_3_VELOCITY			37
#define IDC_WAVE_3_VELOCITY_STATIC	38
#define IDC_WAVE_3_DIRECTION		39
#define IDC_WAVE_3_DIRECTION_STATIC 40
#define IDC_WAVE_3_K_EXP			41
#define IDC_WAVE_3_K_EXP_STATIC		42

#define IDC_WAVE_0_ENABLE			43
#define IDC_WAVE_1_ENABLE			44
#define IDC_WAVE_2_ENABLE			45
#define IDC_WAVE_3_ENABLE			46

#define IDC_SAVEPREFS				47
#define IDC_LOADPREFS				48
#define IDC_CLEARPREFS				49

#define IDC_WAVE_0_WAVELEN          50
#define IDC_WAVE_0_WAVELEN_STATIC   51
#define IDC_WAVE_1_WAVELEN          52
#define IDC_WAVE_1_WAVELEN_STATIC   53
#define IDC_WAVE_2_WAVELEN          54
#define IDC_WAVE_2_WAVELEN_STATIC   55
#define IDC_WAVE_3_WAVELEN          56
#define IDC_WAVE_3_WAVELEN_STATIC   57

#define IDC_THREADING               58
#define IDC_USE_WAVE_DERIVATIVE		59	


#define IDC_NUMROWS					60
#define IDC_NUMCOLS					61
#define IDC_NUMROWS_STATIC			62
#define IDC_NUMCOLS_STATIC			63

#define IDC_USE_FAST_LOOKUP         64

#define IDC_WAVE_0_SUM				65
#define IDC_WAVE_1_SUM				66
#define IDC_WAVE_2_SUM				67
#define IDC_WAVE_3_SUM				68

//--------------------------------------------------------------------------------------
// UI coordinate offsets
//--------------------------------------------------------------------------------------
#define IDC_OFFSET_WAVELEN_STATIC   30
#define IDC_OFFSET_WAVELEN_SLIDER   45
#define IDC_OFFSET_AMPLITUDE_STATIC 65
#define IDC_OFFSET_AMPLITUDE_SLIDER	80
#define IDC_OFFSET_VELOCITY_STATIC	100
#define IDC_OFFSET_VELOCITY_SLIDER	115
#define IDC_OFFSET_DIRECTION_STATIC	135
#define IDC_OFFSET_DIRECTION_SLIDER 150
#define IDC_OFFSET_K_EXP_STATIC		170
#define IDC_OFFSET_K_EXP_SLIDER		185
#define IDC_OFFSET_CHECKBOX			215

//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
bool    CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, bool bWindowed );
void    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps );
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc );
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc );
void    CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime );
void    CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime );
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing );
void    CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown  );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl );
void    CALLBACK OnLostDevice();
void    CALLBACK OnDestroyDevice();

void    InitApp();
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh );
void    RenderText( double fTime );
HRESULT RenderLightArrow( D3DXVECTOR3 lightDir, D3DXCOLOR arrowColor );

void	SyncGUIToWaveform();

unsigned __stdcall LaunchTakeStepThread( void* );


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Set the callback functions. These functions allow the sample framework to notify
    // the application about device changes, user input, and windows messages.  The 
    // callbacks are optional so you need only set callbacks for events you're interested 
    // in. However, if you don't handle the device reset/lost callbacks then the sample 
    // framework won't be able to reset your device since the application must first 
    // release all device resources before resetting.  Likewise, if you don't handle the 
    // device created/destroyed callbacks then the sample framework won't be able to 
    // recreate your device resources.
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( KeyboardProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Show the cursor and clip it when in full screen
    DXUTSetCursorSettings( true, true );

    InitApp();

    // Initialize the sample framework and create the desired Win32 window and Direct3D 
    // device for the application. Calling each of these functions is optional, but they
    // allow you to set several options which control the behavior of the framework.
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTCreateWindow( L"Adams Basic Framework" );
    //DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 640, 480, IsDeviceAcceptable, ModifyDeviceSettings );
	DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 640, 480, NULL, ModifyDeviceSettings );

    // Pass control to the sample framework for handling the message pump and 
    // dispatching render calls. The sample framework will call your FrameMove 
    // and FrameRender callback when there is idle time between handling window messages.
    DXUTMainLoop();

    // Perform any application-level cleanup here. Direct3D device resources are released within the
    // appropriate callback functions and therefore don't require any cleanup code here.

    return DXUTGetExitCode();
}

//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    g_bEnablePreshader = true;

    for( int i=0; i<MAX_LIGHTS; i++ )
        g_LightControl[i].SetLightDirection( D3DXVECTOR3( sinf(D3DX_PI*2*i/MAX_LIGHTS-D3DX_PI/6), 0, -cosf(D3DX_PI*2*i/MAX_LIGHTS-D3DX_PI/6) ) );

    g_nActiveLight = 0;
    g_nNumActiveLights = 1;
    g_fLightScale = 1.0f;

    // Initialize dialogs
    g_HUD.SetCallback( OnGUIEvent ); int iY = 10; 

	g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
    g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device (F2)", 35, iY += 24, 125, 22 );

	g_HUD.AddButton( IDC_SAVEPREFS, L"Save Waveforms", 35, iY+=24, 125, 22 );
	g_HUD.AddButton( IDC_LOADPREFS, L"Load Waveforms", 35, iY+=24, 125, 22 );

	g_HUD.AddButton( IDC_THREADING, L"Threading: OFF", 35, iY+=24, 125, 22 );
	g_HUD.AddButton( IDC_USE_WAVE_DERIVATIVE, L"Derive Normals: OFF", 35, iY+=24, 125, 22 );
	g_HUD.AddButton( IDC_USE_FAST_LOOKUP, L"Fast Normals: ON", 35, iY+=24, 125, 22 );

	WCHAR sz[100];
	_snwprintf( sz, 100, L"Rows: %d", g_iNumRows ); sz[99] = 0;	
	g_HUD.AddStatic( IDC_NUMROWS_STATIC, sz, 35, iY+=24, 125, 22 );
	g_HUD.AddSlider( IDC_NUMROWS, 35, iY+=24, 125, 22, 3, 180, g_iNumRows, false, 0 );

	_snwprintf( sz, 100, L"Columns: %d", g_iNumCols ); sz[99] = 0;	
	g_HUD.AddStatic( IDC_NUMCOLS_STATIC, sz, 35, iY+=24, 125, 22 );
	g_HUD.AddSlider( IDC_NUMCOLS, 35, iY+=24, 125, 22, 3, 180, g_iNumCols, false, 0 );


	int uiWaveY = 55;
	int uiWave0X = 0;
	int uiWave1X = 120;
	int uiWave2X = 240;
	int uiWave3X = 360;
	float scale;

	g_WaveSpecificUI.AddButton( IDC_WAVE_0_ENABLE, L"Wave 0", uiWave0X, uiWaveY, 100, 22 );
	g_WaveSpecificUI.AddButton( IDC_WAVE_1_ENABLE, L"Wave 1", uiWave1X, uiWaveY, 100, 22 );
	g_WaveSpecificUI.AddButton( IDC_WAVE_2_ENABLE, L"Wave 2", uiWave2X, uiWaveY, 100, 22 );
	g_WaveSpecificUI.AddButton( IDC_WAVE_3_ENABLE, L"Wave 3", uiWave3X, uiWaveY, 100, 22 );


	scale = WAVE_0_WAVELEN_DEFAULT;
	_snwprintf( sz, 100, L"Wavelength: %0.3f", scale); sz[99]=0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_0_WAVELEN_STATIC, sz, uiWave0X, uiWaveY+IDC_OFFSET_WAVELEN_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_WAVELEN_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_0_WAVELEN, uiWave0X+15, uiWaveY+IDC_OFFSET_WAVELEN_SLIDER, 100, 22, 1, 2000, (int) (scale*1000.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_WAVELEN )->SetVisible( false );

	scale = WAVE_0_AMPLITUDE_DEFAULT;
	_snwprintf( sz, 100, L"Amplitude: %0.2f", scale); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_0_AMPLITUDE_STATIC, sz, uiWave0X, uiWaveY+IDC_OFFSET_AMPLITUDE_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_AMPLITUDE_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_0_AMPLITUDE, uiWave0X+15, uiWaveY+IDC_OFFSET_AMPLITUDE_SLIDER, 100, 22, 0, 15, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_AMPLITUDE )->SetVisible( false );

	scale = WAVE_0_VELOCITY_DEFAULT;
	_snwprintf( sz, 100, L"Velocity: %0.2f", scale); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_0_VELOCITY_STATIC, sz, uiWave0X, uiWaveY+IDC_OFFSET_VELOCITY_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_VELOCITY_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_0_VELOCITY, uiWave0X+15, uiWaveY+IDC_OFFSET_VELOCITY_SLIDER, 100, 22, 0, 35, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_VELOCITY )->SetVisible( false );

	scale = WAVE_0_DIRECTION_DEFAULT;
	_snwprintf( sz, 100, L"Direction: %0.0f deg", scale); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_0_DIRECTION_STATIC, sz, uiWave0X, uiWaveY+IDC_OFFSET_DIRECTION_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_DIRECTION_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_0_DIRECTION, uiWave0X+15, uiWaveY+IDC_OFFSET_DIRECTION_SLIDER, 100, 22, 0, 360, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_DIRECTION )->SetVisible( false );

	scale = WAVE_0_K_EXP_DEFAULT;
	_snwprintf( sz, 100, L"Exponent: %0.0f", scale); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_0_K_EXP_STATIC, sz, uiWave0X, uiWaveY+IDC_OFFSET_K_EXP_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_K_EXP_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_0_K_EXP, uiWave0X+15, uiWaveY+IDC_OFFSET_K_EXP_SLIDER, 100, 22, 1, 10, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_K_EXP )->SetVisible( false );

	g_WaveSpecificUI.AddCheckBox( IDC_WAVE_0_SUM, L"Omit this Wave?", uiWave0X, uiWaveY+IDC_OFFSET_CHECKBOX, 125, 22, false );
	g_WaveSpecificUI.GetCheckBox( IDC_WAVE_0_SUM )->SetVisible( false );
	
	scale = WAVE_1_WAVELEN_DEFAULT;
	_snwprintf( sz, 100, L"Wavelength: %0.3f", scale); sz[99]=0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_1_WAVELEN_STATIC, sz, uiWave1X, uiWaveY+IDC_OFFSET_WAVELEN_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_WAVELEN_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_1_WAVELEN, uiWave1X+15, uiWaveY+IDC_OFFSET_WAVELEN_SLIDER, 100, 22, 1, 2000, (int) (scale*1000.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_WAVELEN )->SetVisible( false );

	scale = WAVE_1_AMPLITUDE_DEFAULT;
	_snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_1_AMPLITUDE_STATIC, sz, uiWave1X, uiWaveY+IDC_OFFSET_AMPLITUDE_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_AMPLITUDE_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_1_AMPLITUDE, uiWave1X+15, uiWaveY+IDC_OFFSET_AMPLITUDE_SLIDER, 100, 22, 0, 15, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_AMPLITUDE )->SetVisible( false );

	scale = WAVE_1_VELOCITY_DEFAULT;
	_snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_1_VELOCITY_STATIC, sz, uiWave1X, uiWaveY+IDC_OFFSET_VELOCITY_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_VELOCITY_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_1_VELOCITY, uiWave1X+15, uiWaveY+IDC_OFFSET_VELOCITY_SLIDER, 100, 22, 0, 35, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_VELOCITY )->SetVisible( false );
		
	scale = WAVE_1_DIRECTION_DEFAULT;
	_snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_1_DIRECTION_STATIC, sz, uiWave1X, uiWaveY+IDC_OFFSET_DIRECTION_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_DIRECTION_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_1_DIRECTION, uiWave1X+15, uiWaveY+IDC_OFFSET_DIRECTION_SLIDER, 100, 22, 0, 360, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_DIRECTION )->SetVisible( false );

	scale = WAVE_1_K_EXP_DEFAULT;
	_snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_1_K_EXP_STATIC, sz, uiWave1X, uiWaveY+IDC_OFFSET_K_EXP_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_K_EXP_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_1_K_EXP, uiWave1X+15, uiWaveY+IDC_OFFSET_K_EXP_SLIDER, 100, 22, 1, 10, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_K_EXP )->SetVisible( false );

	g_WaveSpecificUI.AddCheckBox( IDC_WAVE_1_SUM, L"Omit this Wave?", uiWave1X, uiWaveY+IDC_OFFSET_CHECKBOX, 125, 22, false );
	g_WaveSpecificUI.GetCheckBox( IDC_WAVE_1_SUM )->SetVisible( false );

	scale = WAVE_2_WAVELEN_DEFAULT;
	_snwprintf( sz, 100, L"Wavelength: %0.3f", scale); sz[99]=0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_2_WAVELEN_STATIC, sz, uiWave2X, uiWaveY+IDC_OFFSET_WAVELEN_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_WAVELEN_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_2_WAVELEN, uiWave2X+15, uiWaveY+IDC_OFFSET_WAVELEN_SLIDER, 100, 22, 1, 2000, (int) (scale*1000.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_WAVELEN )->SetVisible( false );

	scale = WAVE_2_AMPLITUDE_DEFAULT;
	_snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_2_AMPLITUDE_STATIC, sz, uiWave2X, uiWaveY+IDC_OFFSET_AMPLITUDE_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_AMPLITUDE_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_2_AMPLITUDE, uiWave2X+15, uiWaveY+IDC_OFFSET_AMPLITUDE_SLIDER, 100, 22, 0, 15, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_AMPLITUDE )->SetVisible( false );

	scale = WAVE_2_VELOCITY_DEFAULT;
	_snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_2_VELOCITY_STATIC, sz, uiWave2X, uiWaveY+IDC_OFFSET_VELOCITY_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_VELOCITY_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_2_VELOCITY, uiWave2X+15, uiWaveY+IDC_OFFSET_VELOCITY_SLIDER, 100, 22, 0, 35, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_VELOCITY )->SetVisible( false );

	scale = WAVE_2_DIRECTION_DEFAULT;
	_snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_2_DIRECTION_STATIC, sz, uiWave2X, uiWaveY+IDC_OFFSET_DIRECTION_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_DIRECTION_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_2_DIRECTION, uiWave2X+15, uiWaveY+IDC_OFFSET_DIRECTION_SLIDER, 100, 22, 0, 360, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_DIRECTION )->SetVisible( false );

	g_WaveSpecificUI.AddCheckBox( IDC_WAVE_2_SUM, L"Omit this Wave?", uiWave2X, uiWaveY+IDC_OFFSET_CHECKBOX, 125, 22, false );
	g_WaveSpecificUI.GetCheckBox( IDC_WAVE_2_SUM )->SetVisible( false );

	scale = WAVE_2_K_EXP_DEFAULT;
	_snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_2_K_EXP_STATIC, sz, uiWave2X, uiWaveY+IDC_OFFSET_K_EXP_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_K_EXP_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_2_K_EXP, uiWave2X+15, uiWaveY+IDC_OFFSET_K_EXP_SLIDER, 100, 22, 1, 10, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_K_EXP )->SetVisible( false );

	scale = WAVE_3_WAVELEN_DEFAULT;
	_snwprintf( sz, 100, L"Wavelength: %0.3f", scale); sz[99]=0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_3_WAVELEN_STATIC, sz, uiWave3X, uiWaveY+IDC_OFFSET_WAVELEN_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_WAVELEN_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_3_WAVELEN, uiWave3X+15, uiWaveY+IDC_OFFSET_WAVELEN_SLIDER, 100, 22, 1, 2000, (int) (scale*1000.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_WAVELEN )->SetVisible( false );

	scale = WAVE_3_AMPLITUDE_DEFAULT;
	_snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_3_AMPLITUDE_STATIC, sz, uiWave3X, uiWaveY+IDC_OFFSET_AMPLITUDE_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_AMPLITUDE_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_3_AMPLITUDE, uiWave3X+15, uiWaveY+IDC_OFFSET_AMPLITUDE_SLIDER, 100, 22, 0, 15, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_AMPLITUDE )->SetVisible( false );
		
	scale = WAVE_3_VELOCITY_DEFAULT;
	_snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
	g_WaveSpecificUI.AddStatic( IDC_WAVE_3_VELOCITY_STATIC, sz, uiWave3X, uiWaveY+IDC_OFFSET_VELOCITY_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_VELOCITY_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_3_VELOCITY, uiWave3X+15, uiWaveY+IDC_OFFSET_VELOCITY_SLIDER, 100, 22, 0, 35, (int) (scale*100.0f), false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_VELOCITY )->SetVisible( false );
		
	scale = WAVE_3_DIRECTION_DEFAULT;
	_snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_3_DIRECTION_STATIC, sz, uiWave3X, uiWaveY+IDC_OFFSET_DIRECTION_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_DIRECTION_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_3_DIRECTION, uiWave3X+15, uiWaveY+IDC_OFFSET_DIRECTION_SLIDER, 100, 22, 0, 360, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_DIRECTION )->SetVisible( false );
		
	scale = WAVE_3_K_EXP_DEFAULT;
	_snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;	
	g_WaveSpecificUI.AddStatic( IDC_WAVE_3_K_EXP_STATIC, sz, uiWave3X, uiWaveY+IDC_OFFSET_K_EXP_STATIC, 100, 10 );
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_K_EXP_STATIC )->SetVisible( false );
	g_WaveSpecificUI.AddSlider( IDC_WAVE_3_K_EXP, uiWave3X+15, uiWaveY+IDC_OFFSET_K_EXP_SLIDER, 100, 22, 1, 10, (int) scale, false, 0 );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_K_EXP )->SetVisible( false );
	
	g_WaveSpecificUI.AddCheckBox( IDC_WAVE_3_SUM, L"Omit this Wave?", uiWave3X, uiWaveY+IDC_OFFSET_CHECKBOX, 125, 22, false );
	g_WaveSpecificUI.GetCheckBox( IDC_WAVE_3_SUM )->SetVisible( false );

	g_WaveSpecificUI.SetCallback(OnGUIEvent);

    g_SampleUI.SetCallback( OnGUIEvent ); iY = 10; 

    _snwprintf( sz, 100, L"# Lights: %d", g_nNumActiveLights ); sz[99] = 0;
    g_SampleUI.AddStatic( IDC_NUM_LIGHTS_STATIC, sz, 35, iY += 24, 125, 22 );
    g_SampleUI.AddSlider( IDC_NUM_LIGHTS, 50, iY += 24, 100, 22, 1, MAX_LIGHTS, g_nNumActiveLights );

    iY += 10;
    _snwprintf( sz, 100, L"Light scale: %0.2f", g_fLightScale ); sz[99] = 0;
    g_SampleUI.AddStatic( IDC_LIGHT_SCALE_STATIC, sz, 35, iY += 24, 125, 22 );
    g_SampleUI.AddSlider( IDC_LIGHT_SCALE, 50, iY += 24, 100, 22, 0, 20, (int) (g_fLightScale * 10.0f) );

    iY += 10;
    g_SampleUI.AddButton( IDC_ACTIVE_LIGHT, L"Change active light (K)", 35, iY += 24, 125, 22, 'K' );
    g_SampleUI.AddCheckBox( IDC_ENABLE_PRESHADER, L"Enable preshaders", 35, iY += 24, 125, 22, g_bEnablePreshader );
}


//--------------------------------------------------------------------------------------
// Called during device initialization, this code checks the device for some 
// minimum set of capabilities, and rejects those that don't pass by returning E_FAIL.
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed )
{
    // No fallback defined by this app, so reject any device that 
    // doesn't support at least ps1.1
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(1,1) )
        return false;

    // Skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// This callback function is called immediately before a device is created to allow the 
// application to modify the device settings. The supplied pDeviceSettings parameter 
// contains the settings that the framework has selected for the new device, and the 
// application can make any desired changes directly to this structure.  Note however that 
// the sample framework will not correct invalid device settings so care must be taken 
// to return valid device settings, otherwise IDirect3D9::CreateDevice() will fail.  
//--------------------------------------------------------------------------------------
void CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps )
{
    // If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
    // then switch to SWVP.
    if( (pCaps->DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT) == 0 ||
         pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) )
    {
        pDeviceSettings->BehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }
    else
    {
        pDeviceSettings->BehaviorFlags = D3DCREATE_HARDWARE_VERTEXPROCESSING;
    }

    // This application is designed to work on a pure device by not using 
    // IDirect3D9::Get*() methods, so create a pure device if supported and using HWVP.
    if ((pCaps->DevCaps & D3DDEVCAPS_PUREDEVICE) != 0 && 
        (pDeviceSettings->BehaviorFlags & D3DCREATE_HARDWARE_VERTEXPROCESSING) != 0 )
        pDeviceSettings->BehaviorFlags |= D3DCREATE_PUREDEVICE;

    // Debugging vertex shaders requires either REF or software vertex processing 
    // and debugging pixel shaders requires REF.  
#ifdef DEBUG_VS
    if( pDeviceSettings->DeviceType != D3DDEVTYPE_REF )
    {
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_HARDWARE_VERTEXPROCESSING;
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_PUREDEVICE;                            
        pDeviceSettings->BehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }
#endif
#ifdef DEBUG_PS
    pDeviceSettings->DeviceType = D3DDEVTYPE_REF;
#endif
}

void LoadTextures()
{
	 // Use D3DX to create a texture from a file based image
	LPCWSTR buf = L"c:\\src\\textures\\brk_brds.bmp";

	if( FAILED( D3DXCreateTextureFromFile( DXUTGetD3DDevice(), buf , &g_pMeshTexture ) ) )
    {
        MessageBox(NULL, L"Could not find grid.bmp", L"Textures.exe", MB_OK);
    }
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// created, which will happen during application initialization and windowed/full screen 
// toggles. This is the best location to create D3DPOOL_MANAGED resources since these 
// resources need to be reloaded whenever the device is destroyed. Resources created  
// here should be released in the OnDestroyDevice callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{
    HRESULT hr;

    // Initialize the font
    V_RETURN( D3DXCreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                              OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                              L"Arial", &g_pFont ) );

    // Load the mesh
    V_RETURN( LoadMesh( pd3dDevice, L"tiny\\tiny.x", &g_pMesh ) );
    V_RETURN( LoadMesh( pd3dDevice, L"UI\\arrow.x", &g_pArrowMesh ) );

	//atl: NOTE: have to wait until the device is created!!
	//InitGridVBandIB();
	//g_pGrid = new CGrid();
	//g_pGrid->Create(3,5); //todo: fix magic #
	
   	if(g_pGrid == NULL)
	{
		g_pGrid = new CSinWaterMesh(pd3dDevice, g_iNumRows, g_iNumCols );
	}
	else
	{
		printf("uh-oh\n");
	}

	//g_pGrid->OnResetDevice(pd3dDevice,g_iNumRows, g_iNumCols);

	//g_pGrid = new CWaterMesh(pd3dDevice, g_iNumRows, g_iNumCols );
	
	g_pVB = g_pGrid->GetD3DVB();
	g_pIB = g_pGrid->GetD3DIB();
	
	g_time = 0.0f;
	g_kexp = 12.0f;
	CVector3 dir;

	dir.Init( 0.0f, 0.0f, 0.0f );
	g_pGrid->InitializeWave(0,WAVE_0_WAVELEN_DEFAULT, WAVE_0_AMPLITUDE_DEFAULT, WAVE_0_VELOCITY_DEFAULT, &dir, WAVE_0_K_EXP_DEFAULT);
	g_pGrid->SetDirection( WAVE_0_DIRECTION_DEFAULT, 0 );
	g_pGrid->InitializeWave(1,WAVE_1_WAVELEN_DEFAULT, WAVE_1_AMPLITUDE_DEFAULT, WAVE_1_VELOCITY_DEFAULT, &dir, WAVE_1_K_EXP_DEFAULT);
	g_pGrid->SetDirection( WAVE_1_DIRECTION_DEFAULT, 1 );
	g_pGrid->InitializeWave(2,WAVE_2_WAVELEN_DEFAULT, WAVE_2_AMPLITUDE_DEFAULT, WAVE_2_VELOCITY_DEFAULT, &dir, WAVE_2_K_EXP_DEFAULT);
	g_pGrid->SetDirection( WAVE_2_DIRECTION_DEFAULT, 2 );
	g_pGrid->InitializeWave(3,WAVE_3_WAVELEN_DEFAULT, WAVE_3_AMPLITUDE_DEFAULT, WAVE_3_VELOCITY_DEFAULT, &dir, WAVE_3_K_EXP_DEFAULT);
	g_pGrid->SetDirection( WAVE_3_DIRECTION_DEFAULT, 3 );

//	LoadTextures();

//    D3DXVECTOR3* pData; 
    D3DXVECTOR3 vCenter;
    FLOAT fObjectRadius;
	CVector3 ctr;
	float rad;
	
	g_pGrid->ComputeBoundingSphere(&ctr, &rad);
	vCenter.x = ctr.x;
	vCenter.y = ctr.y;
	vCenter.z = ctr.z;
	fObjectRadius = rad;
	
    D3DXMatrixTranslation( &g_mWorldFix, -vCenter.x, -vCenter.y, -vCenter.z );
    D3DXMATRIXA16 m;
   // D3DXMatrixRotationY( &m, D3DX_PI );
   // g_mWorldFix *= m;
    D3DXMatrixRotationX( &m, D3DX_PI );
    g_mWorldFix *= m;

    V_RETURN( CDXUTDirectionWidget::StaticOnCreateDevice( pd3dDevice ) );
    for( int i=0; i<MAX_LIGHTS; i++ )
        g_LightControl[i].SetRadius( fObjectRadius );

    // Define DEBUG_VS and/or DEBUG_PS to debug vertex and/or pixel shaders with the 
    // shader debugger. Debugging vertex shaders requires either REF or software vertex 
    // processing, and debugging pixel shaders requires REF.  The 
    // D3DXSHADER_FORCE_*_SOFTWARE_NOOPT flag improves the debug experience in the 
    // shader debugger.  It enables source level debugging, prevents instruction 
    // reordering, prevents dead code elimination, and forces the compiler to compile 
    // against the next higher available software target, which ensures that the 
    // unoptimized shaders do not exceed the shader model limitations.  Setting these 
    // flags will cause slower rendering since the shaders will be unoptimized and 
    // forced into software.  See the DirectX documentation for more information about 
    // using the shader debugger.
    DWORD dwShaderFlags = 0;
    #ifdef DEBUG_VS
        dwShaderFlags |= D3DXSHADER_FORCE_VS_SOFTWARE_NOOPT;
    #endif
    #ifdef DEBUG_PS
        dwShaderFlags |= D3DXSHADER_FORCE_PS_SOFTWARE_NOOPT;
    #endif

    // Preshaders are parts of the shader that the effect system pulls out of the 
    // shader and runs on the host CPU. They should be used if you are GPU limited. 
    // The D3DXSHADER_NO_PRESHADER flag disables preshaders.
    if( !g_bEnablePreshader )
        dwShaderFlags |= D3DXSHADER_NO_PRESHADER;

    // Read the D3DX effect file
    WCHAR str[MAX_PATH];
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"WaveDemo.fx" ) );
	


    // If this fails, there should be debug output as to 
    // why the .fx file failed to compile
    V_RETURN( D3DXCreateEffectFromFile( pd3dDevice, str, NULL, NULL, dwShaderFlags, NULL, &g_pEffect, NULL ) );
	

    // Create the mesh texture from a file
  //  V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"tiny\\tiny_skin.bmp" ) );

    //V_RETURN( D3DXCreateTextureFromFileEx( pd3dDevice, str, D3DX_DEFAULT, D3DX_DEFAULT, 
      //                                 D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, 
        //                               D3DX_DEFAULT, D3DX_DEFAULT, 0, 
          //                             NULL, NULL, &g_pMeshTexture ) );


    // Set effect variables as needed
    //D3DXCOLOR colorMtrlDiffuse(1.0f, 1.0f, 1.0f, 1.0f);
	D3DXCOLOR colorMtrlDiffuse(0.0f, 0.0f, 1.0f, 1.0f);
    D3DXCOLOR colorMtrlAmbient(0.35f, 0.35f, 0.35f, 0);

    V_RETURN( g_pEffect->SetValue("g_MaterialAmbientColor", &colorMtrlAmbient, sizeof(D3DXCOLOR) ) );
    V_RETURN( g_pEffect->SetValue("g_MaterialDiffuseColor", &colorMtrlDiffuse, sizeof(D3DXCOLOR) ) );    
    V_RETURN( g_pEffect->SetTexture( "g_MeshTexture", g_pMeshTexture) );

    // Setup the camera's view parameters
    D3DXVECTOR3 vecEye(0.0f, 0.0f, -10.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, -0.0f);
    g_Camera.SetViewParams( &vecEye, &vecAt );
    //g_Camera.SetRadius( fObjectRadius*3.0f, fObjectRadius*0.5f, fObjectRadius*10.0f );
	//works
//	g_Camera.SetRadius( fObjectRadius*3.0f, fObjectRadius*0.5f, fObjectRadius*10.0f );
	g_Camera.SetRadius( fObjectRadius*2.0f, fObjectRadius*0.5f, fObjectRadius*10.0f );

	//g_pGrid->CreateWaveAtEdge(.2);
	//g_pGrid->CreateWaveAtVertex(5,5,.2f);

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This function loads the mesh and ensures the mesh has normals; it also optimizes the 
// mesh for the graphics card's vertex cache, which improves performance by organizing 
// the internal triangle list for less cache misses.
//--------------------------------------------------------------------------------------
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh )
{
    ID3DXMesh* pMesh = NULL;
    WCHAR str[MAX_PATH];
    HRESULT hr;

    // Load the mesh with D3DX and get back a ID3DXMesh*.  For this
    // sample we'll ignore the X file's embedded materials since we know 
    // exactly the model we're loading.  See the mesh samples such as
    // "OptimizedMesh" for a more generic mesh loading example.
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, strFileName ) );
    V_RETURN( D3DXLoadMeshFromX(str, D3DXMESH_MANAGED, pd3dDevice, NULL, NULL, NULL, NULL, &pMesh) );

    DWORD *rgdwAdjacency = NULL;

    // Make sure there are normals which are required for lighting
    if( !(pMesh->GetFVF() & D3DFVF_NORMAL) )
    {
        ID3DXMesh* pTempMesh;
        V( pMesh->CloneMeshFVF( pMesh->GetOptions(), 
                                  pMesh->GetFVF() | D3DFVF_NORMAL, 
                                  pd3dDevice, &pTempMesh ) );
        V( D3DXComputeNormals( pTempMesh, NULL ) );

        SAFE_RELEASE( pMesh );
        pMesh = pTempMesh;
    }

    // Optimize the mesh for this graphics card's vertex cache 
    // so when rendering the mesh's triangle list the vertices will 
    // cache hit more often so it won't have to re-execute the vertex shader 
    // on those vertices so it will improve perf.     
    rgdwAdjacency = new DWORD[pMesh->GetNumFaces() * 3];
    if( rgdwAdjacency == NULL )
        return E_OUTOFMEMORY;
    V( pMesh->ConvertPointRepsToAdjacency(NULL, rgdwAdjacency) );
    V( pMesh->OptimizeInplace(D3DXMESHOPT_VERTEXCACHE, rgdwAdjacency, NULL, NULL, NULL) );
    delete []rgdwAdjacency;

    *ppMesh = pMesh;

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// reset, which will happen after a lost device scenario. This is the best location to 
// create D3DPOOL_DEFAULT resources since these resources need to be reloaded whenever 
// the device is lost. Resources created here should be released in the OnLostDevice 
// callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{
    HRESULT hr;

    if( g_pFont )
        V_RETURN( g_pFont->OnResetDevice() );
    if( g_pEffect )
        V_RETURN( g_pEffect->OnResetDevice() );
	if(g_pAdamEffect)
		V_RETURN( g_pAdamEffect->OnResetDevice() );

	if(g_pGrid == NULL)
	{
 		g_pGrid = new CSinWaterMesh(pd3dDevice, g_iNumRows, g_iNumCols );
		g_pVB = g_pGrid->GetD3DVB();
		g_pIB = g_pGrid->GetD3DIB();
		
		g_time = 0.0f;
		g_kexp = 12.0f;
		CVector3 dir;

		dir.Init(0.0f,0.0f,0.0f);
		g_pGrid->InitializeWave(0,WAVE_0_WAVELEN_DEFAULT, WAVE_0_AMPLITUDE_DEFAULT, WAVE_0_VELOCITY_DEFAULT, &dir, WAVE_0_K_EXP_DEFAULT);
		g_pGrid->SetDirection( WAVE_0_DIRECTION_DEFAULT, 0 );
		g_pGrid->InitializeWave(1,WAVE_1_WAVELEN_DEFAULT, WAVE_1_AMPLITUDE_DEFAULT, WAVE_1_VELOCITY_DEFAULT, &dir, WAVE_1_K_EXP_DEFAULT);
		g_pGrid->SetDirection( WAVE_1_DIRECTION_DEFAULT, 1 );
		g_pGrid->InitializeWave(2,WAVE_2_WAVELEN_DEFAULT, WAVE_2_AMPLITUDE_DEFAULT, WAVE_2_VELOCITY_DEFAULT, &dir, WAVE_2_K_EXP_DEFAULT);
		g_pGrid->SetDirection( WAVE_2_DIRECTION_DEFAULT, 2 );
		g_pGrid->InitializeWave(3,WAVE_3_WAVELEN_DEFAULT, WAVE_3_AMPLITUDE_DEFAULT, WAVE_3_VELOCITY_DEFAULT, &dir, WAVE_3_K_EXP_DEFAULT);
		g_pGrid->SetDirection( WAVE_3_DIRECTION_DEFAULT, 3 );
	}
	else  //TODO: this gets hit on intiailize FIX AND/OR understand
	{
		//This usually follows OnCreateDevice, which should have given us a grid already.
	}

    // Create a sprite to help batch calls when drawing many lines of text
    V_RETURN( D3DXCreateSprite( pd3dDevice, &g_pSprite ) );

    for( int i=0; i<MAX_LIGHTS; i++ )
        g_LightControl[i].OnResetDevice( pBackBufferSurfaceDesc  );

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 0.1f, 5000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
    g_Camera.SetButtonMasks( MOUSE_LEFT_BUTTON, MOUSE_WHEEL, MOUSE_MIDDLE_BUTTON );

    g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 0 );
    g_HUD.SetSize( 170, 170 );
    g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width-170, pBackBufferSurfaceDesc->Height-240 );
    g_SampleUI.SetSize( 170, 240 );

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called once at the beginning of every frame. This is the
// best location for your application to handle updates to the scene, but is not 
// intended to contain actual rendering calls, which should instead be placed in the 
// OnFrameRender callback.  
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );
}


//--------------------------------------------------------------------------------------
// This callback function will be called at the end of every frame to perform all the 
// rendering calls for the scene, and it will also be called if the window needs to be 
// repainted. After this function has returned, the sample framework will call 
// IDirect3DDevice9::Present to display the contents of the next buffer in the swap chain
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime )
{
    HRESULT hr;
    D3DXMATRIXA16 mWorldViewProjection;
    D3DXVECTOR3 vLightDir[MAX_LIGHTS];
    D3DXCOLOR   vLightDiffuse[MAX_LIGHTS];
    //UINT iPass;
	UINT cPasses;
    D3DXMATRIXA16 mWorld;
    D3DXMATRIXA16 mView;
    D3DXMATRIXA16 mProj;

	// This is a dummy workload which represents parallel computations (physics, AI, etc.) 
	// that a real game engine could take advantage of.  I'm using the grid size as input
	// parameters so that this workload scales with the grid.

	long workload = DUMMY_WORKLOAD * g_pGrid->GetCurrentNumRows() * g_pGrid->GetCurrentNumCols();

	int *pworkload = (int *)malloc( 2 * sizeof(int) * g_pGrid->GetCurrentNumRows() * g_pGrid->GetCurrentNumCols() );
	pworkload[0] = g_pGrid->GetCurrentNumRows();
	pworkload[1] = g_pGrid->GetCurrentNumCols();

	for( int i=2; i < workload; i++ )
	{
		pworkload[i] = (int) ( sqrt( pow(pworkload[i-1], pworkload[i-2]) ) / sqrt( pow(pworkload[i-2], pworkload[i-1]) ) );
	}

	free(pworkload);


	//culls faces with clockwise vertices
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    // Clear the render target and the zbuffer 
	D3DXCOLOR vBackGround;
    V( pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DXCOLOR(0.5f,0.5f,0.5f,0.55f), 1.0f, 0) );

    // Render the scene
    if( SUCCEEDED( pd3dDevice->BeginScene() ) )
    {
        // Get the projection & view matrix from the camera class
        mWorld = g_mWorldFix * *g_Camera.GetWorldMatrix();
        mProj = *g_Camera.GetProjMatrix();
        mView = *g_Camera.GetViewMatrix();

        mWorldViewProjection = mWorld * mView * mProj;

        // Render the light spheres so the user can 
        // visually see the light dir
        for( int i=0; i<g_nNumActiveLights; i++ )
        {
            D3DXCOLOR arrowColor = ( i == g_nActiveLight ) ? D3DXCOLOR(1,1,0,1) : D3DXCOLOR(1,1,1,1);
            V( g_LightControl[i].OnRender( arrowColor, &mView, &mProj, g_Camera.GetEyePt() ) );
            vLightDir[i] = g_LightControl[i].GetLightDirection();
            vLightDiffuse[i] = g_fLightScale * D3DXCOLOR(1,1,1,1);
        }

        V( g_pEffect->SetValue( "g_LightDir", vLightDir, sizeof(D3DXVECTOR3)*MAX_LIGHTS ) );
        V( g_pEffect->SetValue( "g_LightDiffuse", vLightDiffuse, sizeof(D3DXVECTOR4)*MAX_LIGHTS ) );

        // Update the effect's variables.  Instead of using strings, it would 
        // be more efficient to cache a handle to the parameter by calling 
        // ID3DXEffect::GetParameterByName
        V( g_pEffect->SetMatrix( "g_mWorldViewProjection", &mWorldViewProjection ) );
        V( g_pEffect->SetMatrix( "g_mWorld", &mWorld ) );
        V( g_pEffect->SetFloat( "g_fTime", (float)fTime ) );

        D3DXCOLOR vWhite = D3DXCOLOR(1,1,1,1);
		D3DXCOLOR vBlue = D3DXCOLOR(0.0f,0.0f,.75f, 1.0f);
        V( g_pEffect->SetValue("g_MaterialDiffuseColor", &vBlue, sizeof(D3DXCOLOR) ) );
        V( g_pEffect->SetFloat( "g_fTime", (float)fTime ) );      
        V( g_pEffect->SetInt( "g_nNumLights", g_nNumActiveLights ) );      


		// Render the scene with this technique 
        // as defined in the .fx file
        switch( g_nNumActiveLights )
        {
            case 1: V( g_pEffect->SetTechnique( "RenderSceneWithTexture1Light" ) ); break;
            case 2: V( g_pEffect->SetTechnique( "RenderSceneWithTexture2Light" ) ); break;
            case 3: V( g_pEffect->SetTechnique( "RenderSceneWithTexture3Light" ) ); break;
        }

		g_pEffect->SetTechnique("AdamRenderSceneWithNoTexture1Light");
		//g_pEffect->SetTechnique("AdamRenderSceneWithTexture1Light");
		
		g_pEffect->Begin(&cPasses, 0);
			g_pEffect->BeginPass(0);

				LPDIRECT3DDEVICE9 pD3DDevice = NULL;
				pD3DDevice = DXUTGetD3DDevice();

				if ( g_pGrid->IsTakeStepThreaded() )
				{
			
					while( !g_pGrid->IsStepDone() )
					{
						Sleep(0);
						// Wait for VB recalculation to finish
					}
					// Did the helper thread get cancelled since we started waiting for it?
					if( g_pGrid->IsTakeStepThreaded() )
					{
						g_pGrid->CopyVBToRenderVB();		//Make a copy of the latest grid vertices
						g_pGrid->ResetStepDone();			//Allow the other thread to compute a new set of vertices
					}
					else
					{
						//take a time step
						g_pGrid->TakeStepSumOfWavesWithExp(g_time, NUM_WAVES);
						g_time += .08f;
						// THIS thread generated the grid, so just go ahead and display it.
						g_pGrid->CopyVBToRenderVB();
					}
					pD3DDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0));
				}
				else
				{
					//take a time step
					g_pGrid->TakeStepSumOfWavesWithExp(g_time, NUM_WAVES);
					g_time += .08f;
	
					// THIS thread generated the grid, so just go ahead and display it.
					g_pGrid->CopyVBToRenderVB();
                    pD3DDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOM_VERT_POS_NORMAL_TEXTURE0));
				}
				
				pD3DDevice->SetFVF(D3D_FVF_CUSTOMVERTEX_POS_NORMAL_TEXTURE0);
				if(FAILED(pD3DDevice->SetIndices(g_pIB)))
				{
					printf("failed\n");
				}

			    if(FAILED(pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, g_iNumRows*g_iNumCols, 0, (g_iNumRows-1)*(g_iNumCols-1)*2)))
				{
					printf("failed\n");
				}
			
			g_pEffect->EndPass();
		g_pEffect->End();

        g_HUD.OnRender( fElapsedTime ); 
        g_SampleUI.OnRender( fElapsedTime );
		g_WaveSpecificUI.OnRender(fElapsedTime);

        RenderText( fTime );
        
        V( pd3dDevice->EndScene() );
    }
}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText( double fTime )
{
    // The helper object simply helps keep track of text position, and color
    // and then it calls pFont->DrawText( m_pSprite, strMsg, -1, &rc, DT_NOCLIP, m_clr );
    // If NULL is passed in as the sprite object, then it will work fine however the 
    // pFont->DrawText() will not be batched together.  Batching calls will improves perf.
    CDXUTTextHelper txtHelper( g_pFont, g_pSprite, 15 );

    // Output statistics
    txtHelper.Begin();
    txtHelper.SetInsertionPos( 2, 0 );
    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    txtHelper.DrawTextLine( DXUTGetFrameStats() );
    txtHelper.DrawTextLine( DXUTGetDeviceStats() );
    
    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
    txtHelper.DrawFormattedTextLine( L"fTime: %0.1f  sin(fTime): %0.4f", fTime, sin(fTime) );
    
    // Draw help
    if( g_bShowHelp )
    {
        const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetBackBufferSurfaceDesc();
        txtHelper.SetInsertionPos( 2, pd3dsdBackBuffer->Height-15*6 );
        txtHelper.SetForegroundColor( D3DXCOLOR(1.0f, 0.75f, 0.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Controls:" );

        txtHelper.SetInsertionPos( 20, pd3dsdBackBuffer->Height-15*5 );
        txtHelper.DrawTextLine( L"Rotate model: Left mouse button\n"
                                L"Rotate light: Right mouse button\n"
                                L"Rotate camera: Middle mouse button\n"
                                L"Zoom camera: Mouse wheel scroll\n" );

        txtHelper.SetInsertionPos( 250, pd3dsdBackBuffer->Height-15*5 );
        txtHelper.DrawTextLine( L"Hide help: F1\n" 
                                L"Quit: ESC\n" );
    }
    else
    {
        txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Press F1 for help" );
    }
    txtHelper.End();
}


//--------------------------------------------------------------------------------------
// Before handling window messages, the sample framework passes incoming windows 
// messages to the application through this callback function. If the application sets 
// *pbNoFurtherProcessing to TRUE, then the sample framework will not process this message.
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing )
{
    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;
    *pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;
	*pbNoFurtherProcessing = g_WaveSpecificUI.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    g_LightControl[g_nActiveLight].HandleMessages( hWnd, uMsg, wParam, lParam );

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// As a convenience, the sample framework inspects the incoming windows messages for
// keystroke messages and decodes the message parameters to pass relevant keyboard
// messages to the application.  The framework does not remove the underlying keystroke 
// messages, which are still passed to the application's MsgProc callback.
//--------------------------------------------------------------------------------------
void CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown )
{
    if( bKeyDown )
    {
        switch( nChar )
        {
            case VK_F1: g_bShowHelp = !g_bShowHelp; break;
        }
    }
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl )
{
    float scale = 0.0f;
    switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_CHANGEDEVICE:     DXUTSetShowSettingsDialog( !DXUTGetShowSettingsDialog() ); break;

		case IDC_SAVEPREFS:
			{
				fstream ofile("water demo prefs.txt", ios::out);
				ofile << "Wave0 Wavelength: " << g_pGrid->GetWaveLength(0) << '\n';
				ofile << "Wave0 Amplitude: " << g_pGrid->GetAmplitude(0) << '\n';
				ofile << "Wave0 Velocity: " << g_pGrid->GetSpeed(0) << '\n';
				ofile << "Wave0 Direction: " << g_pGrid->GetDirection(0) << '\n';
				ofile << "Wave0 Exponent: " << g_pGrid->GetKExp(0) << '\n';
				ofile << "Wave0 Sum: " << g_pGrid->GetSumWave(0) << '\n';
				ofile << "Wave1 Wavelength: " << g_pGrid->GetWaveLength(1) << '\n';
				ofile << "Wave1 Amplitude: " << g_pGrid->GetAmplitude(1) << '\n';
				ofile << "Wave1 Velocity: " << g_pGrid->GetSpeed(1) << '\n';
				ofile << "Wave1 Direction: " << g_pGrid->GetDirection(1) << '\n';
				ofile << "Wave1 Exponent: " << g_pGrid->GetKExp(1) << '\n';
				ofile << "Wave1 Sum: " << g_pGrid->GetSumWave(1) << '\n';
				ofile << "Wave2 Wavelength: " << g_pGrid->GetWaveLength(2) << '\n';
				ofile << "Wave2 Amplitude: " << g_pGrid->GetAmplitude(2) << '\n';
				ofile << "Wave2 Velocity: " << g_pGrid->GetSpeed(2) << '\n';
				ofile << "Wave2 Direction: " << g_pGrid->GetDirection(2) << '\n';
				ofile << "Wave2 Exponent: " << g_pGrid->GetKExp(2) << '\n';
				ofile << "Wave2 Sum: " << g_pGrid->GetSumWave(2) << '\n';
				ofile << "Wave3 Wavelength: " << g_pGrid->GetWaveLength(3) << '\n';
				ofile << "Wave3 Amplitude: " << g_pGrid->GetAmplitude(3) << '\n';
				ofile << "Wave3 Velocity: " << g_pGrid->GetSpeed(3) << '\n';
				ofile << "Wave3 Direction: " << g_pGrid->GetDirection(3) << '\n';
				ofile << "Wave3 Exponent: " << g_pGrid->GetKExp(3) << '\n';
				ofile << "Wave3 Sum: " << g_pGrid->GetSumWave(3) << '\n';
				ofile.close();
			}
			break;

		case IDC_LOADPREFS:
			{
				char line[100];
				float val;
				bool b;
				fstream ifile("water demo prefs.txt", ios::in);
				if ( !ifile.fail() )
				{
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetWaveLength( val, 0 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetAmplitude( val, 0 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetSpeed( val, 0 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetDirection( val, 0 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetKExp( val, 0 );
					ifile.getline( line, 100, ':' );
					ifile >> b;
					g_pGrid->SetSumWave( b, 0 );

					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetWaveLength( val, 1 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetAmplitude( val, 1 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetSpeed( val, 1 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetDirection( val, 1 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetKExp( val, 1 );
					ifile.getline( line, 100, ':' );
					ifile >> b;
					g_pGrid->SetSumWave( b, 1 );

					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetWaveLength( val, 2 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetAmplitude( val, 2 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetSpeed( val, 2 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetDirection( val, 2 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetKExp( val, 2 );
					ifile.getline( line, 100, ':' );
					ifile >> b;
					g_pGrid->SetSumWave( b, 2 );

					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetWaveLength( val, 3 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetAmplitude( val, 3 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetSpeed( val, 3 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetDirection( val, 3 );
					ifile.getline( line, 100, ':' );
					ifile >> val;
					g_pGrid->SetKExp( val, 3 );
					ifile.getline( line, 100, ':' );
					ifile >> b;
					g_pGrid->SetSumWave( b, 3 );

					SyncGUIToWaveform();

					g_pGrid->SetFirstTime();
				}
				
			}
			break;

        case IDC_ENABLE_PRESHADER: 
        {
            g_bEnablePreshader = g_SampleUI.GetCheckBox( IDC_ENABLE_PRESHADER )->GetChecked(); 

            if( DXUTGetD3DDevice() != NULL )
            {
                OnLostDevice();
                OnDestroyDevice();
                OnCreateDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
                OnResetDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
            }
            break;
        }

        case IDC_ACTIVE_LIGHT:
            if( !g_LightControl[g_nActiveLight].IsBeingDragged() )
            {
                g_nActiveLight++;
                g_nActiveLight %= g_nNumActiveLights;
            }
            break;

        case IDC_NUM_LIGHTS:
            if( !g_LightControl[g_nActiveLight].IsBeingDragged() )
            {
                WCHAR sz[100];
                _snwprintf( sz, 100, L"# Lights: %d", g_SampleUI.GetSlider( IDC_NUM_LIGHTS )->GetValue() ); sz[99] = 0;
                g_SampleUI.GetStatic( IDC_NUM_LIGHTS_STATIC )->SetText( sz );

                g_nNumActiveLights = g_SampleUI.GetSlider( IDC_NUM_LIGHTS )->GetValue();
                g_nActiveLight %= g_nNumActiveLights;
            }
            break;

        case IDC_LIGHT_SCALE: 
            g_fLightScale = (float) (g_SampleUI.GetSlider( IDC_LIGHT_SCALE )->GetValue() * 0.10f);

            WCHAR sz[100];
            _snwprintf( sz, 100, L"Light scale: %0.2f", g_fLightScale ); sz[99] = 0;
            g_SampleUI.GetStatic( IDC_LIGHT_SCALE_STATIC )->SetText( sz );
            break;

		case IDC_WAVE_0_ENABLE:
			g_bWave0Enable = !g_bWave0Enable;
			if (g_bWave0Enable)
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_WAVELEN_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_WAVELEN )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_AMPLITUDE_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_AMPLITUDE )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_VELOCITY_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_VELOCITY )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_DIRECTION_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_DIRECTION )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_K_EXP_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_K_EXP )->SetVisible( true );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_0_SUM )->SetVisible( true );
			}
			else
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_WAVELEN_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_WAVELEN )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_AMPLITUDE_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_AMPLITUDE )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_VELOCITY_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_VELOCITY )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_DIRECTION_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_DIRECTION )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_0_K_EXP_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_0_K_EXP )->SetVisible( false );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_0_SUM )->SetVisible( false );
			}
			break;

		case IDC_WAVE_0_WAVELEN:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_0_WAVELEN )->GetValue() * .001f);
            _snwprintf( sz, 100, L"Wavelength: %0.3f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_0_WAVELEN_STATIC )->SetText( sz );
			g_pGrid->SetWaveLength(scale, 0);
			break;
		case IDC_WAVE_0_AMPLITUDE:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_0_AMPLITUDE )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_0_AMPLITUDE_STATIC )->SetText( sz );
			g_pGrid->SetAmplitude(scale, 0);
			break;
		case IDC_WAVE_0_VELOCITY:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_0_VELOCITY )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_0_VELOCITY_STATIC )->SetText( sz );
			g_pGrid->SetSpeed(scale, 0);
			break;
		case IDC_WAVE_0_DIRECTION:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_0_DIRECTION )->GetValue());
            _snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_0_DIRECTION_STATIC )->SetText( sz );
			g_pGrid->SetDirection(scale, 0);
			break;
		case IDC_WAVE_0_K_EXP:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_0_K_EXP )->GetValue());
            _snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_0_K_EXP_STATIC )->SetText( sz );
			g_pGrid->SetKExp(scale, 0);
			break;
		case IDC_WAVE_0_SUM:
			if( g_WaveSpecificUI.GetCheckBox(IDC_WAVE_0_SUM)->GetChecked() )
			{
				g_pGrid->SetSumWave( false, 0 );
			}
			else
			{
				g_pGrid->SetSumWave( true, 0 );
			}			
			break;

		case IDC_WAVE_1_ENABLE:
			g_bWave1Enable = !g_bWave1Enable;
			if (g_bWave1Enable)
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_WAVELEN_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_WAVELEN )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_AMPLITUDE_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_AMPLITUDE )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_VELOCITY_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_VELOCITY )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_DIRECTION_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_DIRECTION )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_K_EXP_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_K_EXP )->SetVisible( true );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_1_SUM )->SetVisible( true );
			}
			else
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_WAVELEN_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_WAVELEN )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_AMPLITUDE_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_AMPLITUDE )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_VELOCITY_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_VELOCITY )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_DIRECTION_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_DIRECTION )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_1_K_EXP_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_1_K_EXP )->SetVisible( false );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_1_SUM )->SetVisible( false );
			}
			break;
		
		case IDC_WAVE_1_WAVELEN:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_1_WAVELEN )->GetValue() * .001f);
            _snwprintf( sz, 100, L"Wavelength: %0.3f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_1_WAVELEN_STATIC )->SetText( sz );
			g_pGrid->SetWaveLength(scale, 1);
			break;
		case IDC_WAVE_1_AMPLITUDE:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_1_AMPLITUDE )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_1_AMPLITUDE_STATIC )->SetText( sz );
			g_pGrid->SetAmplitude(scale, 1);
			break;
		case IDC_WAVE_1_VELOCITY:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_1_VELOCITY )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_1_VELOCITY_STATIC )->SetText( sz );
			g_pGrid->SetSpeed(scale, 1);
			break;
		case IDC_WAVE_1_DIRECTION:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_1_DIRECTION )->GetValue());
            _snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_1_DIRECTION_STATIC )->SetText( sz );
			g_pGrid->SetDirection(scale, 1);
			break;
		case IDC_WAVE_1_K_EXP:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_1_K_EXP )->GetValue());
            _snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_1_K_EXP_STATIC )->SetText( sz );
			g_pGrid->SetKExp(scale, 1);
			break;
		case IDC_WAVE_1_SUM:
			if( g_WaveSpecificUI.GetCheckBox(IDC_WAVE_1_SUM)->GetChecked() )
			{
				g_pGrid->SetSumWave( false, 1 );
			}
			else
			{
				g_pGrid->SetSumWave( true, 1 );
			}
			break;

		case IDC_WAVE_2_ENABLE:
			g_bWave2Enable = !g_bWave2Enable;
			if (g_bWave2Enable)
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_WAVELEN_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_WAVELEN )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_AMPLITUDE_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_AMPLITUDE )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_VELOCITY_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_VELOCITY )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_DIRECTION_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_DIRECTION )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_K_EXP_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_K_EXP )->SetVisible( true );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_2_SUM )->SetVisible( true );
			}
			else
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_WAVELEN_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_WAVELEN )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_AMPLITUDE_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_AMPLITUDE )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_VELOCITY_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_VELOCITY )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_DIRECTION_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_DIRECTION )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_2_K_EXP_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_2_K_EXP )->SetVisible( false );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_2_SUM )->SetVisible( false );
			}
			break;
		
		case IDC_WAVE_2_WAVELEN:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_2_WAVELEN )->GetValue() * .001f);
            _snwprintf( sz, 100, L"Wavelength: %0.3f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_2_WAVELEN_STATIC )->SetText( sz );
			g_pGrid->SetWaveLength(scale, 2);
			break;
		case IDC_WAVE_2_AMPLITUDE:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_2_AMPLITUDE )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_2_AMPLITUDE_STATIC )->SetText( sz );
			g_pGrid->SetAmplitude(scale, 2);
			break;
		case IDC_WAVE_2_VELOCITY:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_2_VELOCITY )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_2_VELOCITY_STATIC )->SetText( sz );
			g_pGrid->SetSpeed(scale, 2);
			break;
		case IDC_WAVE_2_DIRECTION:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_2_DIRECTION )->GetValue());
            _snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_2_DIRECTION_STATIC )->SetText( sz );
			g_pGrid->SetDirection(scale, 2);
			break;
		case IDC_WAVE_2_K_EXP:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_2_K_EXP )->GetValue());
            _snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_2_K_EXP_STATIC )->SetText( sz );
			g_pGrid->SetKExp(scale, 2);
			break;
		case IDC_WAVE_2_SUM:
			if( g_WaveSpecificUI.GetCheckBox(IDC_WAVE_2_SUM)->GetChecked() )
			{
				g_pGrid->SetSumWave( false, 2 );
			}
			else
			{
				g_pGrid->SetSumWave( true, 2 );
			}
			break;

		case IDC_WAVE_3_ENABLE:
			g_bWave3Enable = !g_bWave3Enable;
			if (g_bWave3Enable)
			{		
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_WAVELEN_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_WAVELEN )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_AMPLITUDE_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_AMPLITUDE )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_VELOCITY_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_VELOCITY )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_DIRECTION_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_DIRECTION )->SetVisible( true );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_K_EXP_STATIC )->SetVisible( true );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_K_EXP )->SetVisible( true );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_3_SUM )->SetVisible( true );
			}
			else
			{
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_WAVELEN_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_WAVELEN )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_AMPLITUDE_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_AMPLITUDE )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_VELOCITY_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_VELOCITY )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_DIRECTION_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_DIRECTION )->SetVisible( false );
				g_WaveSpecificUI.GetStatic( IDC_WAVE_3_K_EXP_STATIC )->SetVisible( false );
				g_WaveSpecificUI.GetSlider( IDC_WAVE_3_K_EXP )->SetVisible( false );
				g_WaveSpecificUI.GetCheckBox( IDC_WAVE_3_SUM )->SetVisible( false );
			}
			break;

		case IDC_WAVE_3_WAVELEN:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_3_WAVELEN )->GetValue() * .001f);
            _snwprintf( sz, 100, L"Wavelength: %0.3f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_3_WAVELEN_STATIC )->SetText( sz );
			g_pGrid->SetWaveLength(scale, 3);
			break;
		case IDC_WAVE_3_AMPLITUDE:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_3_AMPLITUDE )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Amplitude: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_3_AMPLITUDE_STATIC )->SetText( sz );
			g_pGrid->SetAmplitude(scale, 3);
			break;
		case IDC_WAVE_3_VELOCITY:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_3_VELOCITY )->GetValue() * .01f);
            _snwprintf( sz, 100, L"Velocity: %0.2f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_3_VELOCITY_STATIC )->SetText( sz );
			g_pGrid->SetSpeed(scale, 3);
			break;
		case IDC_WAVE_3_DIRECTION:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_3_DIRECTION )->GetValue());
            _snwprintf( sz, 100, L"Direction: %0.0f deg", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_3_DIRECTION_STATIC )->SetText( sz );
			g_pGrid->SetDirection(scale, 3);
			break;
		case IDC_WAVE_3_K_EXP:
			scale = (float) (g_WaveSpecificUI.GetSlider( IDC_WAVE_3_K_EXP )->GetValue());
            _snwprintf( sz, 100, L"Exponent: %0.0f", scale ); sz[99] = 0;
            g_WaveSpecificUI.GetStatic( IDC_WAVE_3_K_EXP_STATIC )->SetText( sz );
			g_pGrid->SetKExp(scale, 3);
			break;
		case IDC_WAVE_3_SUM:
			if( g_WaveSpecificUI.GetCheckBox(IDC_WAVE_3_SUM)->GetChecked() )
			{
				g_pGrid->SetSumWave( false, 3 );
			}
			else
			{
				g_pGrid->SetSumWave( true, 3 );
			}			
			break;

		case IDC_THREADING:
			if( g_pGrid->IsTakeStepThreaded() )
			{
				g_pGrid->SetExitThread();
				while( g_pGrid->IsTakeStepThreaded() )
				{
					// Wait for child thread to exit
					Sleep(0);
				}
				_snwprintf( sz, 100, L"Threading: OFF"); sz[99]=0;
				g_HUD.GetButton( IDC_THREADING )->SetText( sz );
			}
			else
			{
				HANDLE hThreadHandle;
				DWORD dwThreadId;
                g_pGrid->SetTakeStepThreaded();    // Parent must indicate that child thread has been launched
				
				hThreadHandle = (HANDLE) _beginthreadex( NULL, 0, LaunchTakeStepThread, (void*)&g_time, 0, (unsigned int*)&dwThreadId );
				CloseHandle( hThreadHandle );

				_snwprintf( sz, 100, L"Threading: ON"); sz[99]=0;
				g_HUD.GetButton( IDC_THREADING )->SetText( sz );
			}
			break;

		case IDC_USE_WAVE_DERIVATIVE:
			if( g_pGrid->UsingWaveDerivative() )
			{
				g_pGrid->ResetUseWaveDerivative();
				_snwprintf( sz, 100, L"Derive Normals: OFF"); sz[99]=0;
				g_HUD.GetButton( IDC_USE_WAVE_DERIVATIVE )->SetText( sz );
			}
			else
			{
				g_pGrid->SetUseWaveDerivative();
				_snwprintf( sz, 100, L"Derive Normals: ON"); sz[99]=0;
				g_HUD.GetButton( IDC_USE_WAVE_DERIVATIVE )->SetText( sz );
			}
			break;

		case IDC_USE_FAST_LOOKUP:
			if( g_pGrid->UsingFastLookup() )
			{
				g_pGrid->ResetUseFastLookup();
				_snwprintf( sz, 100, L"Fast Normals: OFF"); sz[99]=0;
				g_HUD.GetButton( IDC_USE_FAST_LOOKUP )->SetText( sz );
			}
			else
			{
				g_pGrid->SetUseFastLookup();
				_snwprintf( sz, 100, L"Fast Normals: ON"); sz[99]=0;
				g_HUD.GetButton( IDC_USE_FAST_LOOKUP )->SetText( sz );
			}
			break;

		case IDC_NUMROWS:
			_snwprintf( sz, 100, L"Rows: %d", g_HUD.GetSlider( IDC_NUMROWS )->GetValue() ); sz[99] = 0;
            g_HUD.GetStatic( IDC_NUMROWS_STATIC )->SetText( sz );
					
			OnLostDevice();
            OnDestroyDevice();
			g_iNumRows = g_HUD.GetSlider( IDC_NUMROWS )->GetValue();
            OnCreateDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
            OnResetDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
			break;

		case IDC_NUMCOLS:
			_snwprintf( sz, 100, L"Columns: %d", g_HUD.GetSlider( IDC_NUMCOLS )->GetValue() ); sz[99] = 0;
            g_HUD.GetStatic( IDC_NUMCOLS_STATIC )->SetText( sz );

			OnLostDevice();
            OnDestroyDevice();
			g_iNumCols = g_HUD.GetSlider( IDC_NUMCOLS )->GetValue();
            OnCreateDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
            OnResetDevice( DXUTGetD3DDevice(), DXUTGetBackBufferSurfaceDesc() );
			break;

		default:
			;
    }
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// entered a lost state and before IDirect3DDevice9::Reset is called. Resources created
// in the OnResetDevice callback should be released here, which generally includes all 
// D3DPOOL_DEFAULT resources. See the "Lost Devices" section of the documentation for 
// information about lost devices.
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice()
{
	// Clean up child thread
	if ( g_pGrid->IsTakeStepThreaded() )
		g_pGrid->SetExitThread();                    // Tell child to exit ASAP
	while( g_pGrid->IsTakeStepThreaded() )
	{
		Sleep(0);
		// Wait for child to exit
	}

	CDXUTDirectionWidget::StaticOnLostDevice();
    if( g_pFont )
        g_pFont->OnLostDevice();
    if( g_pEffect )
        g_pEffect->OnLostDevice();
	if( g_pAdamEffect )
        g_pAdamEffect->OnLostDevice();

	if(g_pGrid) 
	{
		g_pGrid->OnLostDevice();
		delete g_pGrid;
		g_pGrid = NULL;
		g_pVB = NULL;
		g_pIB = NULL;
	}

    SAFE_RELEASE(g_pSprite);
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// been destroyed, which generally happens as a result of application termination or 
// windowed/full screen toggles. Resources created in the OnCreateDevice callback 
// should be released here, which generally includes all D3DPOOL_MANAGED resources. 
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice()
{
    CDXUTDirectionWidget::StaticOnDestroyDevice();
    SAFE_RELEASE(g_pEffect);
    SAFE_RELEASE(g_pFont);
    SAFE_RELEASE(g_pMesh);
    SAFE_RELEASE(g_pMeshTexture);
    SAFE_RELEASE(g_pArrowMesh);
}


void printVB()
{
	int iResult = -1;

	VOID *pVerts = NULL;
	iResult = g_pVB->Lock(0, g_iNumRows*g_iNumCols*sizeof(CUSTOM_VERT_POS_NORMAL), (void **)&pVerts, 0);
	if(iResult != D3D_OK)
	{
		printf("Fill VB fail\n");
	}

	CUSTOM_VERT_POS_NORMAL *arr = (CUSTOM_VERT_POS_NORMAL *) pVerts;

	for(int i=0;i<g_iNumRows*g_iNumCols;i++)
	{
		printf("arr[i] = %f %f %f\n", i, arr[i].x, arr[i].y, arr[i].z);
	}

	g_pVB->Unlock();
}

void printIB()
{
	int iResult = -1;
	int iBufSize = sizeof(short int) * ((g_iNumRows-1) * (g_iNumCols-1) * 6);
	int iCount = ((g_iNumRows-1) * (g_iNumCols-1) * 6);

	VOID *pIndices = NULL;
	iResult = g_pIB->Lock(0, iBufSize, (void **)&pIndices, 0);
	if(iResult != D3D_OK)
	{
		printf("Create IB failed\n");
	}

	short int *arr = (short int *)pIndices;
	for(int i=0;i<iCount;i++)
	{
		printf("arr: %d\n", arr[i]);
	}

	g_pIB->Unlock();
}
//DAR:  This is a really crude hack that needs to be cleaned up.
void SyncGUIToWaveform()
{
	float val;
	bool b;
	WCHAR sz[100];

	val = g_pGrid->GetWaveLength(0);
	_snwprintf( sz, 100, L"Wavelength: %0.3f", val); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_WAVELEN_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_WAVELEN )->SetValue( (int) (val*1000.0f) );  // compute val*1000.0f BEFORE casting to int, else sliders will move to left on load (0.xxx -> 0 as an int)
	val = g_pGrid->GetAmplitude(0);
	_snwprintf( sz, 100, L"Amplitude: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_AMPLITUDE_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_AMPLITUDE )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetSpeed(0);
	_snwprintf( sz, 100, L"Velocity: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_VELOCITY_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_VELOCITY )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetDirection(0);
	_snwprintf( sz, 100, L"Direction: %0.0f deg", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_DIRECTION_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_DIRECTION )->SetValue( (int) val );
	val = g_pGrid->GetKExp(0);
	_snwprintf( sz, 100, L"Exponent: %0.0f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_0_K_EXP_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_0_K_EXP )->SetValue( (int) val );
	b = g_pGrid->GetSumWave(0);
	g_WaveSpecificUI.GetCheckBox(IDC_WAVE_0_SUM)->SetChecked( !b );

	val = g_pGrid->GetWaveLength(1);
	_snwprintf( sz, 100, L"Wavelength: %0.3f", val); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_WAVELEN_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_WAVELEN )->SetValue( (int) (val*1000.0f) );
	val = g_pGrid->GetAmplitude(1);
	_snwprintf( sz, 100, L"Amplitude: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_AMPLITUDE_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_AMPLITUDE )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetSpeed(1);
	_snwprintf( sz, 100, L"Velocity: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_VELOCITY_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_VELOCITY )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetDirection(1);
	_snwprintf( sz, 100, L"Direction: %0.0f deg", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_DIRECTION_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_DIRECTION )->SetValue( (int) val );
	val = g_pGrid->GetKExp(1);
	_snwprintf( sz, 100, L"Exponent: %0.0f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_1_K_EXP_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_1_K_EXP )->SetValue( (int) val );
	b = g_pGrid->GetSumWave(1);
	g_WaveSpecificUI.GetCheckBox(IDC_WAVE_1_SUM)->SetChecked( !b );

	val = g_pGrid->GetWaveLength(2);
	_snwprintf( sz, 100, L"Wavelength: %0.3f", val); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_WAVELEN_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_WAVELEN )->SetValue( (int) (val*1000.0f) );
	val = g_pGrid->GetAmplitude(2);
	_snwprintf( sz, 100, L"Amplitude: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_AMPLITUDE_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_AMPLITUDE )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetSpeed(2);
	_snwprintf( sz, 100, L"Velocity: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_VELOCITY_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_VELOCITY )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetDirection(2);
	_snwprintf( sz, 100, L"Direction: %0.0f deg", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_DIRECTION_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_DIRECTION )->SetValue( (int) val );
	val = g_pGrid->GetKExp(2);
	_snwprintf( sz, 100, L"Exponent: %0.0f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_2_K_EXP_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_2_K_EXP )->SetValue( (int) val );
	b = g_pGrid->GetSumWave(2);
	g_WaveSpecificUI.GetCheckBox(IDC_WAVE_2_SUM)->SetChecked( !b );

	val = g_pGrid->GetWaveLength(3);
	_snwprintf( sz, 100, L"Wavelength: %0.3f", val); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_WAVELEN_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_WAVELEN )->SetValue( (int) (val*1000.0f) );
	val = g_pGrid->GetAmplitude(3);
	_snwprintf( sz, 100, L"Amplitude: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_AMPLITUDE_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_AMPLITUDE )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetSpeed(3);
	_snwprintf( sz, 100, L"Velocity: %0.2f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_VELOCITY_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_VELOCITY )->SetValue( (int) (val*100.0f) );
	val = g_pGrid->GetDirection(3);
	_snwprintf( sz, 100, L"Direction: %0.0f deg", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_DIRECTION_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_DIRECTION )->SetValue( (int) val );
	val = g_pGrid->GetKExp(3);
	_snwprintf( sz, 100, L"Exponent: %0.0f", val ); sz[99] = 0;
	g_WaveSpecificUI.GetStatic( IDC_WAVE_3_K_EXP_STATIC )->SetText( sz );
	g_WaveSpecificUI.GetSlider( IDC_WAVE_3_K_EXP )->SetValue( (int) val );
	b = g_pGrid->GetSumWave(3);
	g_WaveSpecificUI.GetCheckBox(IDC_WAVE_3_SUM)->SetChecked( !b );
}
// Function return type & parameter type depend on which thread libraries are used.

unsigned __stdcall LaunchTakeStepThread( void* pTime )
{
	g_pGrid->TakeStepThread( (float*)pTime );
	return( GetCurrentThreadId() );
}