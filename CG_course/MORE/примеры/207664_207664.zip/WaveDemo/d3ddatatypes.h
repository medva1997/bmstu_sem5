//-------------------------------------------------------------------------------------
//
// Copyright � 2004 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations a bout the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software not any
// responsibility to update it.
//
//-------------------------------------------------------------------------------------

// This is a place to put d3d datatypes, so we only have 1 copy of them.
#ifndef D3DDATATYPES_H
#define D3DDATATYPES_H

#include "dxstdafx.h"

struct CUSTOM_VERT_POS_NORMAL {
	float x,y,z;
	float nx,ny,nz;
};

struct CUSTOM_VERT_POS_NORMAL_TEXTURE0 {
	float x,y,z;
	float nx,ny,nz;
	float tu, tv;
};


#define D3D_FVF_CUSTOMVERTEX_POS_NORMAL (D3DFVF_XYZ | D3DFVF_NORMAL )
#define D3D_FVF_CUSTOMVERTEX_POS_NORMAL_TEXTURE0 (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE2(0) )

struct CUSTOMVERTEX_POS_COL
{
	FLOAT x,y,z;
	DWORD col;
};

struct CUSTOMVERTEX_POS_COL_TEX
{
	FLOAT x,y,z;
	DWORD col;
	FLOAT tu,tv;
};

#endif