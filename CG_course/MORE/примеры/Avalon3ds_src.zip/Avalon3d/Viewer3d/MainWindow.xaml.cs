﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Windows.Media.Animation;
using MeshUtilities;

/// H I S T O R Y
/// 
/// 05-06-2005 Added animated Error message - for errors when loading 3ds file
/// 04-06-2005 Updated the code for new RC1 version of Avalon
/// 12-06-2005 Improved cameraPreview and added wireframe


namespace Viewer3d
{
    
    /// <summary>
	/// Interaction logic for Viewer3d.xaml
	/// </summary>

	public partial class MainWindow : Window
    {
        #region Constants
        // camera.3ds and default template are set to be copied to output directory
        public const string Camera3dsFilePath = "camera.3ds";
        public const string XamlExportTemplateFilePath = "XamlExportDefaultTemplate.xaml";
        #endregion

        #region Properties
        private MeshUtilities.MeshFactory.ShadingMode currentShadingMode;

		private Reader3ds _current3dsReader; // Used to access other cameras, ...

		private CheckBox freeLightCheckBox; // Light checkboxes are dynamically added - class private so it is created only once

        Transform3DGroup previewTransform;
		#endregion

		#region Constructor
		public MainWindow()
			: base()
		{
			InitializeComponent();
		}
		#endregion

		#region WindowLoaded
		private void WindowLoaded(object sender, EventArgs e)
		{
			OriginalRadioButton.IsChecked = true; // By default

            InitPreview();
		}
		#endregion

        #region InitPreview
        private void InitPreview()
        {
            Model3DGroup newModel3DGroup;
            Reader3ds newReaded3ds;

            // Read camera for Preview
            newReaded3ds = new Reader3ds();

            newReaded3ds.AddDefaultLight = true;
            newModel3DGroup = newReaded3ds.ReadFile(Camera3dsFilePath);

            ViewportPreview.Models = newModel3DGroup;

            // ViewportPreview.Models.Children[0] - directional light
            ((GeometryModel3D)ViewportPreview.Models.Children[1]).Material = new DiffuseMaterial(new SolidColorBrush(Colors.LightGray));
            ((GeometryModel3D)ViewportPreview.Models.Children[2]).Material = new DiffuseMaterial(new SolidColorBrush(Colors.LightGray));
            ((GeometryModel3D)ViewportPreview.Models.Children[3]).Material = new DiffuseMaterial(new SolidColorBrush(Colors.Gold));

            // Add transform for rotating cameras
            previewTransform = new Transform3DGroup();

            RotateTransform3D rotateTransform1 = new RotateTransform3D();
            RotateTransform3D rotateTransform2 = new RotateTransform3D();

            Rotation3D rotation1 = new Rotation3D(new Vector3D(1, 0, 0), 0);
            Rotation3D rotation2 = new Rotation3D(new Vector3D(0, 0, 1), 0);

            rotateTransform1.Rotation = rotation1;
            rotateTransform2.Rotation = rotation2;

            previewTransform.Children.Add(rotateTransform1);
            previewTransform.Children.Add(rotateTransform2);
            
            // Camera contains 2 mesh objects 
            ((GeometryModel3D)ViewportPreview.Models.Children[1]).Transform = previewTransform;
            ((GeometryModel3D)ViewportPreview.Models.Children[2]).Transform = previewTransform;
        }
        #endregion

        #region ReloadMesh
        private void ReloadMesh(string fileName)
		{
            try
            {
                Model3DGroup newModel3DGroup;
                Reader3ds newReader3ds;

                //newModel3DGroup = new Model3DGroup();
                newReader3ds = new Reader3ds();

                newModel3DGroup = newReader3ds.ReadFile(FileNameTextBox.Text);

                if (currentShadingMode != MeshFactory.ShadingMode.Original)
                    newModel3DGroup = MeshFactory.GetShadedModelGroup(newModel3DGroup, currentShadingMode);

                // If successful add it to Viewport1
                _current3dsReader = newReader3ds; // this class contains more data than newModel3DGroup (all the cameras, ...)
                Viewport1.Models = newModel3DGroup;
            }
            catch (Exception ex)
            {
                // Set error text
                ErrorLabel2.Content = ex.Message;

                // Show error message and start its disappearing animatiom
                errorGrid.Visibility = Visibility.Visible;
                //errorGrid.Opacity = 1;

                // Start animation: show error for some time and then hide it
this.FindStoryboardClock(errorDisappearing).ClockController.Begin();
            }
		}
		#endregion

		#region Initialze - SetCamerasRadioButtons, SetLightsCheckBoxes
		private void SetCamerasRadioButtons()
		{
            if (_current3dsReader == null)
                return;

			cameraRadioButtons.Items.Clear();

			// Add cameras from 3ds
			for (int i = 0; i < _current3dsReader.Cameras.Count; i++)
				cameraRadioButtons.Items.Add("camera " + i.ToString());

			// Add free camera
			cameraRadioButtons.Items.Add("FREE CAMERA");

			if (_current3dsReader.Cameras.Count > 0)
				cameraRadioButtons.SelectedIndex = 0; // first loaded camera selected
			else
			{
				Viewport1.Camera = CreateNewDummyCamera();
				cameraRadioButtons.SelectedIndex = cameraRadioButtons.Items.Count - 1; // free camera (the last item)
			}
		}

		private void SetLightsCheckBoxes()
		{
			CheckBox oneCheckBox;

            if (_current3dsReader == null)
                return;

			// Delete all check boxes
			CheckBoxStackPanel.Children.Clear();

			// Add one check box for each light from 3ds file
			for (int i = 0; i < _current3dsReader.Lights.Count; i++)
			{
				oneCheckBox = new CheckBox();

				oneCheckBox.Name = "LightCheckBox" + i;
				oneCheckBox.Content = "Light " + (i + 1);
				oneCheckBox.CheckState = CheckState.Checked;
                oneCheckBox.IsCheckedChanged += new RoutedPropertyChangedEventHandler<bool>(lightCheckBox_IsCheckedChanged);

				CheckBoxStackPanel.Children.Add(oneCheckBox);
			}

			// Add free light checkbox
			if (freeLightCheckBox == null)
			{
				freeLightCheckBox = new CheckBox();

				freeLightCheckBox.Name = "FreeLightCheckBox";
				freeLightCheckBox.Content = "FREE LIGHT:";
                freeLightCheckBox.IsCheckedChanged += new RoutedPropertyChangedEventHandler<bool>(lightCheckBox_IsCheckedChanged);
			}

			if (_current3dsReader.Lights.Count == 0)
				freeLightCheckBox.CheckState = CheckState.Checked;
			else
				freeLightCheckBox.CheckState = CheckState.Unchecked;

			CheckBoxStackPanel.Children.Add(freeLightCheckBox);

			RefreshLights();
		}
		#endregion

		#region CreateNewDummyCamera, CreateNewDummyLight
		Camera CreateNewDummyCamera()
		{
			PerspectiveCamera newCamera = new PerspectiveCamera();

			newCamera.Up = new Vector3D(0, 0, 1);
			newCamera.FieldOfView = 50;
			newCamera.NearPlaneDistance = 1;
			newCamera.FarPlaneDistance = 500;

			return newCamera;
		}

		Light CreateNewDummyLight()
		{
			DirectionalLight newLight = new DirectionalLight();

			newLight.Color = Colors.White;
			newLight.Direction = new Vector3D(0, 0, -1); // by default from top down

			return newLight;
		}
		#endregion

        #region RefreshLights, RefreshFreeCamera, RefreshPreviewTransform
        void RefreshLights()
		{
			Transform3DGroup lightTransform;
			RotateTransform3D rotationTransform;
			DirectionalLight newLight;

			// Remove all lights from Viewport1
			for (int i = Viewport1.Models.Children.Count - 1; i >= 0; i--)
			{
				if (Viewport1.Models.Children[i] is Light)
					Viewport1.Models.Children.RemoveAt(i);
			}

			// TODO: Reconsider showing/hiding lights instead of clearing and adding them to the scene

			foreach (UIElement oneUIControl in CheckBoxStackPanel.Children)
			{
				if (oneUIControl is CheckBox)
				{
					CheckBox oneCheckBox = oneUIControl as CheckBox;
					if (oneCheckBox.Name.StartsWith("LightCheckBox") && oneCheckBox.IsChecked)
					{
						try
						{
							// get index from CheckBox id
							int index = int.Parse(oneCheckBox.Name.Substring(13));

							// Add light to the scene
							Viewport1.Models.Children.Add(_current3dsReader.Lights[index]);
						}
						catch (FormatException)
						{ }
					}
				}
			}

			if (freeLightCheckBox != null && freeLightCheckBox.IsChecked)
			{
				// Add free light 
                newLight = (DirectionalLight)CreateNewDummyLight();

                // Create new transform collection and rotate the camera
                lightTransform = new Transform3DGroup();

                rotationTransform = new RotateTransform3D(new Vector3D(1, 0, 0), rotateLightAngleX.Value);
                lightTransform.Children.Add(rotationTransform);

                rotationTransform = new RotateTransform3D(new Vector3D(0, 0, 1), rotateLightAngleZ.Value);
                lightTransform.Children.Add(rotationTransform);

                newLight.Transform = lightTransform;

                Viewport1.Models.Children.Add(newLight);
			}
		}

		void RefreshFreeCamera()
		{
			Transform3DGroup cameraTransform;
			RotateTransform3D rotationTransform;
			RotateTransform3D cameraUpTransform;
			Point3D originalCameraPosition;
			Vector3D cameraUp;
			double distance;

			if (cameraRadioButtons.SelectedIndex != (cameraRadioButtons.Items.Count - 1)) return; // Not a free camera mode

			// Calculate camera distance: max_distance * distance from slider
			try
			{
				distance = double.Parse(maxCameraDistance.Text);
			}
			catch (FormatException)
			{
				distance = 500;
				maxCameraDistance.Text = distance.ToString();
			}

			// Also set far plen distance for camera
			(Viewport1.Camera as PerspectiveCamera).FarPlaneDistance = distance * 2;

			distance *= cameraDistance.Value;

			originalCameraPosition = new Point3D(0, -distance, 0);

			// Create new transform collection and rotate the camera
            cameraTransform = new Transform3DGroup();

			rotationTransform = new RotateTransform3D(new Vector3D(1, 0, 0), -rotateCameraAngleX.Value);
			cameraTransform.Children.Add(rotationTransform);

			rotationTransform = new RotateTransform3D(new Vector3D(0, 0, 1), -rotateCameraAngleZ.Value);
            cameraTransform.Children.Add(rotationTransform);

			cameraUpTransform = new RotateTransform3D(new Vector3D(0, 1, 0), -rotateCameraAngle.Value); // Added - to rotateCameraAngle => better effect
			cameraUp = cameraUpTransform.Transform(new Vector3D(0, 0, 1));

			// Set the old camera to the new rotates one
            (Viewport1.Camera as PerspectiveCamera).Position = cameraTransform.Transform(originalCameraPosition);
            (Viewport1.Camera as PerspectiveCamera).Up = cameraUp;

            RefreshPreviewTransform();
        }

        private void RefreshPreviewTransform()
        {
            ((RotateTransform3D)previewTransform.Children[0]).Rotation.Angle = -rotateCameraAngleX.Value;
            ((RotateTransform3D)previewTransform.Children[1]).Rotation.Angle = -rotateCameraAngleZ.Value;
        }
		#endregion

        #region ShowWireframe, HideWireframe
        private void ShowWireframe()
        {
            // Add wireframe
            Model3D oneModel3D;
            int modelsCount;

            modelsCount = Viewport1.Models.Children.Count; // Saved because there are children added in for loop
            for (int i = 0; i < modelsCount; i++)
            {
                oneModel3D = Viewport1.Models.Children[i];

                if (oneModel3D is GeometryModel3D)
                {
                    GeometryModel3D oneGeometryModel3D;
                    MeshGeometry3D oneMeshObject;

                    oneGeometryModel3D = oneModel3D as GeometryModel3D;
                    oneMeshObject = oneGeometryModel3D.Geometry as MeshGeometry3D;

                    for (int n = 0; n < oneMeshObject.TriangleIndices.Count; n += 3)
                    {
                        ScreenSpaceLines3D one3dLine = new ScreenSpaceLines3D();

                        one3dLine.Thickness = 3;
                        one3dLine.Color = Colors.Blue;

                        // 4 points for one tree lines - one TriangleIndice
                        one3dLine.Points.Add(oneMeshObject.Positions[oneMeshObject.TriangleIndices[n + 0]]);
                        one3dLine.Points.Add(oneMeshObject.Positions[oneMeshObject.TriangleIndices[n + 1]]);
                        one3dLine.Points.Add(oneMeshObject.Positions[oneMeshObject.TriangleIndices[n + 2]]);
                        one3dLine.Points.Add(oneMeshObject.Positions[oneMeshObject.TriangleIndices[n + 0]]);

                        Viewport1.Models.Children.Add(one3dLine);
                    }
                }
            }
        }

        private void HideWireframe()
        {
            Model3D oneModel3D;

            // ScreenSpaceLines3D could not be imported from 3ds -> so just go through Viewport1.Models.Children and delete all ScreenSpaceLines3D
            for (int i = Viewport1.Models.Children.Count - 1; i >= 0; i--) // from last to first
            {
                oneModel3D = Viewport1.Models.Children[i];

                if (oneModel3D is ScreenSpaceLines3D)
                    Viewport1.Models.Children.RemoveAt(i);
            }
        }
        #endregion

        #region ExportXamlToClipboard
        private void ExportXamlToClipboard()
        {
            MeshUtilities.XamlExporter thisXamlExporter;
            string xamlText;

            thisXamlExporter = new MeshUtilities.XamlExporter();

            try
            {
                // Set DoubleFormatString
                int noDecimals;

                noDecimals = Int32.Parse(XamlDecimalsTextBox.Text);
                if (noDecimals == 0)
                    thisXamlExporter.DoubleFormatString = "#0";
                else if ((noDecimals > 0) && (noDecimals < 15))
                    thisXamlExporter.DoubleFormatString = "#0." + "#".PadRight(noDecimals, '#');
            }
            catch (FormatException)
            {
                XamlDecimalsTextBox.Text = "5";
                thisXamlExporter.DoubleFormatString = "#0.#####";
            }

            thisXamlExporter.LoadXamlTemplate(XamlExportTemplateFilePath);

            xamlText = "<!-- Exported with MeshUtilities by Andrej Benedik (c) 2005. File name: '" + FileNameTextBox.Text + "' -->\r\n";
            xamlText += thisXamlExporter.ExportModel3DGroup(Viewport1.Models, Viewport1.Camera);

            System.Windows.Clipboard.SetDataObject(xamlText, true);
        }
        #endregion

		#region SetPanels visibilites
		void SetShadingVisibility(bool isVisble)
		{
            if (isVisble)
            {
                ShadingPanel.Visibility = Visibility.Visible;
                ShadingButton.Style = (Style)MainGrid.Resources["PressedButton"];
            }
            else
            {
                ShadingPanel.Visibility = Visibility.Collapsed;
                ShadingButton.Style = (Style)MainGrid.Resources["SimpleButton"];
            }
		}

		void SetCamerasVisibility(bool isVisble)
		{
            if (isVisble)
            {
                CamerasPanel.Visibility = Visibility.Visible;
                CamerasButton.Style = (Style)MainGrid.Resources["PressedButton"];
            }
            else
            {
                CamerasPanel.Visibility = Visibility.Collapsed;
                CamerasButton.Style = (Style)MainGrid.Resources["SimpleButton"];
            }
		}

		void SetLightsVisibility(bool isVisble)
		{
            if (isVisble)
            {
                LightsPanel.Visibility = Visibility.Visible;
                LightsButton.Style = (Style)MainGrid.Resources["PressedButton"];
            }
            else
            {
                LightsPanel.Visibility = Visibility.Collapsed;
                LightsButton.Style = (Style)MainGrid.Resources["SimpleButton"];
            }
		}

		void SetExportVisibility(bool isVisble)
		{
            if (isVisble)
            {
                ExportPanel.Visibility = Visibility.Visible;
                ExportButton.Style = (Style)MainGrid.Resources["PressedButton"];
            }
            else
            {
                ExportPanel.Visibility = Visibility.Collapsed;
                ExportButton.Style = (Style)MainGrid.Resources["SimpleButton"];
            }
		}
		#endregion

        #region ShowWireframeChanged
        void ShowWireframeChanged(object sender, RoutedEventArgs e)
		{
            if (ShowWireframeCheckbox.CheckState == CheckState.Checked)
                ShowWireframe();
            else
                HideWireframe();
        }
        #endregion

        #region Events - Button clicks, check changes, ...
        void ShadingOnChange(object sender, RoutedEventArgs e)
		{
			if (OriginalRadioButton.IsChecked) currentShadingMode = MeshUtilities.MeshFactory.ShadingMode.Original;
			if (FlatRadioButton.IsChecked)     currentShadingMode = MeshUtilities.MeshFactory.ShadingMode.FlatShading;
			if (GouraudRadioButton.IsChecked)  currentShadingMode = MeshUtilities.MeshFactory.ShadingMode.GouraudShading;

            Camera saveSceneCamera = Viewport1.Camera;

			if (_current3dsReader != null) // Do not reload in window init phase
				ReloadMesh(FileNameTextBox.Text);

            Viewport1.Camera = saveSceneCamera;
            RefreshLights();
		}

		void LoadButtonOnClick(object sender, RoutedEventArgs e)
		{
            errorGrid.Visibility = Visibility.Hidden;
			ReloadMesh(FileNameTextBox.Text);

            SetCamerasRadioButtons();
            SetLightsCheckBoxes();

            SetCamerasVisibility(true);
            SetLightsVisibility(true);
		}

		void SelectedCameraChanged(object sender, RoutedEventArgs e)
		{
			if (cameraRadioButtons.SelectedIndex == -1) return;

            if (cameraRadioButtons.SelectedIndex == (cameraRadioButtons.Items.Count - 1)) // last item is free camera
            {
                Viewport1.Camera = CreateNewDummyCamera();
                RefreshFreeCamera();
            }
            else
            {
                Viewport1.Camera = _current3dsReader.Cameras[cameraRadioButtons.SelectedIndex];

                PerspectiveCamera currentPerspectiveCamera = Viewport1.Camera as PerspectiveCamera;

                double dx, dy, dz;
                double rotateZ, rotateX;

                dx = currentPerspectiveCamera.Position.X - currentPerspectiveCamera.LookAtPoint.X;
                dy = currentPerspectiveCamera.Position.Y - currentPerspectiveCamera.LookAtPoint.Y;
                dz = currentPerspectiveCamera.Position.Z - currentPerspectiveCamera.LookAtPoint.Z;

                // Calculate rotation angle around Z axis
                if (dx != 0)
                    rotateZ = Math.Atan2(dy, dx) * 180 / Math.PI;
                else
                    rotateZ = (dy > 0) ? 90 : -90; // Avoid devidion by zero

                if (dy < 0) // for III. and IV. quadrant => rotateZ < 0
                    rotateZ = 360 + rotateZ;

                rotateCameraAngleZ.Value = 270 - rotateZ; // to adjust to the slider values ( = (360-rotateZ) + 90 )


                // Calculate rotation angle around X axis
                if (dx != 0)
                    rotateX = Math.Atan2(dz, dx) * 180 / Math.PI;
                else
                    rotateX = (dy > 0) ? 90 : -90; // Avoid devidion by zero

                if (dy < 0) // for III. and IV. quadrant => rotateZ < 0
                    rotateX = 360 + rotateX;

                rotateCameraAngleX.Value = 180 - rotateX; // to adjust to the slider values ( = (360-rotateZ) + 90 )

                // Calculate distance
                maxCameraDistance.Text = Convert.ToInt16(2 * Math.Sqrt(dx * dx + dy * dy + dz * dz)).ToString();
                cameraDistance.Value = 0.5;

                RefreshPreviewTransform();
            }
		}

        void lightCheckBox_IsCheckedChanged(object sender, RoutedPropertyChangedEventArgs<bool> e)
        {
            if (Viewport1 != null)
                RefreshLights();
        }

        void ExportXamlToClipboardButtonOnClick(object sender, RoutedEventArgs e)
        {
            ExportXamlToClipboard();
        }
		#endregion

		#region Events - FreeLightChanged, FreeCameraChanged
		void FreeLightChanged(object sender, RoutedEventArgs e)
		{
			if (Viewport1 != null && freeLightCheckBox != null)
				if (freeLightCheckBox.IsChecked) RefreshLights();
		}
			
		void FreeCameraChanged(object sender, RoutedEventArgs e)
		{
			if (Viewport1 != null)
				RefreshFreeCamera();
		}
		#endregion

		#region Events - PanelsVisibility Button Click
		void ShadingButtonClick(object sender, RoutedEventArgs e)
		{
			SetShadingVisibility(ShadingPanel.Visibility == Visibility.Collapsed); // If now collapsed than show it
		}

		void CamerasButtonClick(object sender, RoutedEventArgs e)
		{
			SetCamerasVisibility(CamerasPanel.Visibility == Visibility.Collapsed); // If now collapsed than show it
		}

		void LightsButtonClick(object sender, RoutedEventArgs e)
		{
			SetLightsVisibility(LightsPanel.Visibility == Visibility.Collapsed); // If now collapsed than show it
		}

		void ExportButtonClick(object sender, RoutedEventArgs e)
		{
			SetExportVisibility(ExportPanel.Visibility == Visibility.Collapsed); // If now collapsed than show it
		}
		#endregion
    }
}