﻿using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace Viewer3d
{
	/// <summary>
	/// Interaction logic for MyApp.xaml
	/// </summary>

	public partial class MyApp : Application
	{
		void AppStartingUp(object sender, StartingUpCancelEventArgs e)
		{
			MainWindow mainWindow = new MainWindow();
			mainWindow.Show();
		}

	}
}