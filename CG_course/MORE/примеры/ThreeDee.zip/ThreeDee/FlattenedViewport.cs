﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Pelebyte.ThreeDee
{
    public class FlattenedViewport : Decorator
    {
        #region Dependency Properties

        private static readonly DependencyPropertyKey MouseLocationPropertyKey =
            DependencyProperty.RegisterReadOnly(
                "MouseLocation", typeof(Point?), typeof(FlattenedViewport),
                new PropertyMetadata(null));

        public static readonly DependencyProperty MouseLocationProperty =
            MouseLocationPropertyKey.DependencyProperty;

        public static readonly DependencyProperty ChildVisualProperty =
            DependencyProperty.Register(
                "ChildVisual", typeof(Visual3D),
                typeof(FlattenedViewport),
                new PropertyMetadata(null, OnChildVisualChanged));

        private static void OnChildVisualChanged(
            DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var fv = d as FlattenedViewport;
            if (fv != null)
            {
                fv.OnChildVisualChanged((Visual3D)e.OldValue, (Visual3D)e.NewValue);
            }
        }

        #endregion

        static FlattenedViewport()
        {
            WhiteLight = new AmbientLight(Colors.White);
            WhiteLight.Freeze();
        }

        private static readonly AmbientLight WhiteLight;

        private readonly Border _border;
        private readonly Viewport3D _viewport;
        private readonly OrthographicCamera _camera;
        private readonly ModelVisual3D _sceneRoot;

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="FlattenedViewport"/> class.
        /// </summary>
        public FlattenedViewport()
        {
            _border = new Border();
            _border.Background = Brushes.White;
            _viewport = new Viewport3D();
            _camera = new OrthographicCamera(
                new Point3D(0, 0, 1), new Vector3D(0, 0, -1),
                new Vector3D(0, 1, 0), ActualWidth);
            BindingOperations.SetBinding(
                _camera,
                OrthographicCamera.WidthProperty,
                new Binding
                {
                    Source = this,
                    Path = new PropertyPath(ActualWidthProperty),
                });
            _viewport.Camera = _camera;

            _sceneRoot = new ModelVisual3D();
            var root = new ModelVisual3D();
            root.Children.Add(new ModelVisual3D{Content=WhiteLight});
            root.Children.Add(_sceneRoot);
            _viewport.Children.Add(root);

            _border.Child = _viewport;
            base.Child = _border;
        }

        [Browsable(false)]
        public override UIElement Child
        {
            get { return _border; }
            set { if (value == _border) return; throw new NotSupportedException(); }
        }

        public Visual3D ChildVisual
        {
            get { return (Visual3D)GetValue(ChildVisualProperty); }
            set { SetValue(ChildVisualProperty, value); }
        }

        public Point? MouseLocation
        {
            get { return (Point?)GetValue(MouseLocationProperty); }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            var pt = e.GetPosition(this);

            double width = this.ActualWidth;
            double height = this.ActualHeight;

            pt.X = pt.X - width / 2;
            pt.Y = height / 2 - pt.Y;

            this.SetValue(MouseLocationPropertyKey, pt);
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            this.ClearValue(MouseLocationPropertyKey);
            base.OnMouseLeave(e);
        }

        protected virtual void OnChildVisualChanged(Visual3D oldValue, Visual3D newValue)
        {
            if (oldValue == newValue) return;

            _sceneRoot.Children.Clear();
            if (newValue != null)
            {
                _sceneRoot.Children.Add(newValue);
            }
        }
    }
}
