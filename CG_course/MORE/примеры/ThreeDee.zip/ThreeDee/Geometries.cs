﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Pelebyte.ThreeDee
{
    /// <summary>
    /// Contains static methods for generating basic geometries.
    /// </summary>
    public static class Geometries
    {
        public static MeshGeometry3D GenerateRegularPolygon(int sides)
        {
            if (sides < 3)
            {
                throw new ArgumentException("A polygon must have at least three sides.", "sides");
            }

            double increment = Math.PI * 2.0 / sides;
            double r = 0.5 / Math.Cos(Math.PI / sides);
            double angle;

            if (sides % 2 == 1)
            {
                // for triangles, pentagons, and all other odd-sided polygons, put the
                // first point at 90 degrees; we'll work counter-clockwise to fill in
                // the rest of the points
                angle = Math.PI / 2;
            }
            else
            {
                // for squares, hexagons, octagons, and all other even-sided polygons,
                // put the first point "just before" 90 degrees; we'll ensure the top
                // and bottom sides are "flat"
                angle = (Math.PI - increment) / 2;
            }

            var positions = new Point3D[sides];
            var normals = new Vector3D[sides];
            var triangleIndices = new int[(sides - 2) * 3];
            var textureCoords = new Point[sides];

            // if you're not a fan of trigonometry, you'll have to take
            // this loop in blind faith
            for (int i = 0; i < sides; i++)
            {
                // we do a tiny bit of rounding so that doubles aren't
                // so annoying
                double x = Math.Round(r * Math.Cos(angle), 6);
                double y = Math.Round(r * Math.Sin(angle), 6);

                positions[i] = new Point3D(x, y, 0.0);
                normals[i] = new Vector3D(0.0, 0.0, 1.0);
                if (i < (sides - 2))
                {
                    int i3 = i * 3;
                    triangleIndices[i3 + 1] = i + 1;
                    triangleIndices[i3 + 2] = i + 2;
                }
                textureCoords[i] = new Point(Math.Round(0.5 + Math.Cos(angle)/2, 6), Math.Round(0.5 - Math.Sin(angle)/2, 6));

                angle += increment;
            }

            // now pack it up and ship it off to the client
            var mesh = new MeshGeometry3D
            {
                Positions = new Point3DCollection(positions),
                Normals = new Vector3DCollection(normals),
                TriangleIndices = new Int32Collection(triangleIndices),
                TextureCoordinates = new PointCollection(textureCoords)
            };
            mesh.Freeze();
            return mesh;
        }
    }
}
