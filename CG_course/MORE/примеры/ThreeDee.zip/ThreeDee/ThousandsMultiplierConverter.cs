﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Pelebyte.ThreeDee
{
    public class ThousandsMultiplierConverter : IValueConverter
    {
        public static readonly ThousandsMultiplierConverter Instance =
            new ThousandsMultiplierConverter();

        object IValueConverter.Convert(
            object value, Type targetType, object parameter,
            CultureInfo culture)
        {
            return (double)value * 1000;
        }

        object IValueConverter.ConvertBack(
            object value, Type targetType, object parameter,
            CultureInfo culture)
        {
            return (double)value / 1000;
        }
    }
}
