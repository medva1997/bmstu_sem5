﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Pelebyte.ThreeDee
{
    public class ThreeDeeModel : INotifyPropertyChanged
    {
        private static readonly PropertyChangedEventArgs DotCountEvArgs =
            new PropertyChangedEventArgs("DotCount");
        private static readonly PropertyChangedEventArgs ModelEvArgs =
            new PropertyChangedEventArgs("Model");
        private static readonly PropertyChangedEventArgs RadiusScaleEvArgs =
            new PropertyChangedEventArgs("RadiusScale");

        public static int GetIndex(DependencyObject obj)
        {
            return (int)obj.GetValue(IndexProperty);
        }

        public static void SetIndex(DependencyObject obj, int value)
        {
            obj.SetValue(IndexProperty, value);
        }

        public static readonly DependencyProperty IndexProperty =
            DependencyProperty.RegisterAttached(
                "Index", typeof(int), typeof(ThreeDeeModel),
                new PropertyMetadata(0));

        private int _dotCount;
        private ModelVisual3D _model;

        private static readonly IMultiValueConverter XValueConverter =
            ValueConverters.CreateConverter<double, double, int, double>(
                (t, r, i) => i * r * Math.Cos(t + i));
        private static readonly IMultiValueConverter YValueConverter =
            ValueConverters.CreateConverter<double, double, int, double>(
                (t, r, i) => i * r * Math.Sin(t + i));

        private readonly BindingBase _thetaBinding;
        private readonly BindingBase _radiusBinding;

        public ThreeDeeModel()
        {
            _radiusScale = 1.0;

            _thetaBinding = new Binding { Source = this, Path = new PropertyPath("ThetaShift") };
            _radiusBinding = new Binding { Source = this, Path = new PropertyPath("RadiusScale") };
        }

        public int DotCount
        {
            get { return _dotCount; }
            set
            {
                if (_dotCount != value)
                {
                    _dotCount = value;

                    this.Model = BuildModelForDotCount(value);

                    OnPropertyChanged(DotCountEvArgs);
                }
            }
        }

        private static readonly ScaleTransform3D Scale;
        private static readonly MeshGeometry3D Square =
            Geometries.GenerateRegularPolygon(4);

        public static readonly Material GreenMaterial;
        public static readonly Material RedMaterial;

        static ThreeDeeModel()
        {
            GreenMaterial = new DiffuseMaterial(Brushes.DarkGreen);
            GreenMaterial.Freeze();

            RedMaterial = new DiffuseMaterial(Brushes.DarkRed);
            RedMaterial.Freeze();

            Scale = new ScaleTransform3D(5.0, 5.0, 1.0);
            Scale.Freeze();
        }

        private ModelVisual3D BuildModelForDotCount(int value)
        {
            if (value == 0) return null;

            //gm3D.Freeze();

            var rootVisual = new ModelVisual3D();
            var c = rootVisual.Children;
            for (int i = 0; i < value; i++)
            {
                var gm3D = new GeometryModel3D
                {
                    Material = GreenMaterial,
                    Geometry = Square,
                    Transform = Scale,
                };
                SetIndex(gm3D, i);

                var mv = new ModelVisual3D { Content = gm3D };
                var tt = new TranslateTransform3D();
                mv.Transform = tt;

                BindingOperations.SetBinding(
                    tt, TranslateTransform3D.OffsetXProperty,
                    new MultiBinding
                    {
                        Converter = XValueConverter,
                        Bindings =
                            {
                                _thetaBinding, _radiusBinding,
                                new Binding {Source = gm3D, Path=new PropertyPath(IndexProperty)}
                            }
                    });
                BindingOperations.SetBinding(
                    tt, TranslateTransform3D.OffsetYProperty,
                    new MultiBinding
                    {
                        Converter = YValueConverter,
                        Bindings =
                            {
                                _thetaBinding, _radiusBinding,
                                new Binding {Source = gm3D, Path=new PropertyPath(IndexProperty)}
                            }
                    });
                c.Add(mv);
            }

            return rootVisual;
        }



        private double _radiusScale;

        public double RadiusScale
        {
            get { return _radiusScale; }
            set
            {
                if (value <= 0.0)
                {
                    throw new ArgumentException(
                        "RadiusScale must be a positive number.", "value");
                }

                if (_radiusScale != value)
                {
                    _radiusScale = value;
                    OnPropertyChanged(RadiusScaleEvArgs);
                }
            }
        }

        private double _thetaShift;

        public double ThetaShift
        {
            get { return _thetaShift; }
            set
            {
                value = value - Math.Floor(value / (Math.PI * 2)) * (Math.PI * 2);

                if (_thetaShift != value)
                {
                    _thetaShift = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("ThetaShift"));
                }
            }
        }


        public ModelVisual3D Model
        {
            get { return _model; }
            set
            {
                if (_model != value)
                {
                    _model = value;
                    OnPropertyChanged(ModelEvArgs);
                }
            }
        }

        protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
