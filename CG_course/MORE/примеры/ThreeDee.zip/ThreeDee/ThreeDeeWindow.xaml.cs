﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Pelebyte.ThreeDee
{
    /// <summary>
    /// The main window.
    /// </summary>
    public partial class ThreeDeeWindow
    {
        private GeometryModel3D _lastHitModel;
        private bool _isMouseDown;

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="ThreeDeeWindow"/> class.
        /// </summary>
        public ThreeDeeWindow()
        {
            InitializeComponent();
            this.DataContext = new ThreeDeeModel();
        }

        private void ViewportControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isMouseDown)
            {
                AdjustCoordinates(e);
            }
            else
            {
                Point pt = e.GetPosition(ViewportControl);
                var pointParams = new PointHitTestParameters(pt);

                if (_lastHitModel != null)
                {
                    _lastHitModel.Material = ThreeDeeModel.GreenMaterial;
                    _lastHitModel = null;
                }

                VisualTreeHelper.HitTest(
                    ViewportControl, null, HitTestCallback, pointParams);
            }
        }

        private void ViewportControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            _isMouseDown = true;
            AdjustCoordinates(e);
        }

        private void ViewportControl_MouseUp(object sender, MouseButtonEventArgs e)
        {
            _isMouseDown = false;
        }

        /// <summary>
        /// Adjusts the settings of the <see cref="ThreeDeeModel"/>
        /// based on the "selected" model and the mouse event.
        /// </summary>
        /// <param name="e">
        /// The <see cref="MouseEventArgs"/> instance containing the
        /// event data.
        /// </param>
        private void AdjustCoordinates(MouseEventArgs e)
        {
            if (_lastHitModel == null) return;

            // solve for an ideal location for the selected point
            int n = ThreeDeeModel.GetIndex(_lastHitModel);

            // the centerpoint can't be moved
            if (n == 0) return;

            var candidate = ViewportControl.MouseLocation;
            if (!candidate.HasValue) return;

            var pt = candidate.Value;

            double scale = Math.Sqrt(pt.X * pt.X + pt.Y * pt.Y) / n;
            if (scale == 0.0) return;

            double theta = Math.Atan(pt.Y / pt.X) - n;
            if (pt.X < 0.0) theta += Math.PI;

            var model = (ThreeDeeModel)this.DataContext;
            if (model != null)
            {
                Debug.Assert(!double.IsNaN(scale), "RadiusShift is wrong...");
                Debug.Assert(!double.IsNaN(theta), "ThetaShift is wrong...");
                model.RadiusScale = scale;
                model.ThetaShift = theta;
            }
        }

        /// <summary>
        /// The callback that handles hit testing.
        /// </summary>
        /// <param name="result">
        /// The result of the hit test.
        /// </param>
        /// <returns>
        /// Directions on how to proceed with the rest of the hit test.
        /// </returns>
        private HitTestResultBehavior HitTestCallback(HitTestResult result)
        {
            var rayResult = result as RayMeshGeometry3DHitTestResult;
            if (rayResult != null)
            {
                var model = rayResult.ModelHit as GeometryModel3D;
                if (model != null)
                {
                    _lastHitModel = model;
                    _lastHitModel.Material = ThreeDeeModel.RedMaterial;
                    return HitTestResultBehavior.Stop;
                }
            }

            return HitTestResultBehavior.Continue;
        }


    }
}
