﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Data;

namespace Pelebyte.ThreeDee
{
    public static class ValueConverters
    {
        public static IMultiValueConverter CreateConverter<T, TResult>(Func<T, TResult> convert)
        {
            return new Arg1<T, TResult>(convert, null);
        }

        public static IMultiValueConverter CreateConverter<T1, T2, TResult>(Func<T1, T2, TResult> convert)
        {
            return new Arg2<T1, T2, TResult>(convert);
        }

        public static IMultiValueConverter CreateConverter<T1, T2, T3, TResult>(Func<T1, T2, T3, TResult> convert)
        {
            return new Arg3<T1, T2, T3, TResult>(convert);
        }

        private sealed class Arg1<T, TResult> : IMultiValueConverter
        {
            private readonly Func<T, TResult> _convert;
            private readonly Func<TResult, T> _convertBack;

            public Arg1(Func<T, TResult> convert, Func<TResult, T> convertBack)
            {
                _convert = convert;
                _convertBack = convertBack;
            }

            public object Convert(
                object[] values, Type targetType, object parameter,
                CultureInfo culture)
            {
                if (values[0] is T)
                {
                    return _convert((T)values[0]);
                }
                else
                {
                    return _convert((T)values[0]);
                }
            }

            public object[] ConvertBack(
                object value, Type[] targetTypes, object parameter,
                CultureInfo culture)
            {
                throw new NotSupportedException();
            }
        }

        private sealed class Arg2<T1, T2, TResult> : IMultiValueConverter
        {
            private readonly Func<T1, T2, TResult> _convert;

            public Arg2(Func<T1, T2, TResult> convert)
            {
                _convert = convert;
            }

            public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
            {
                if (values[0] is T1 && values[1] is T2)
                {
                    return _convert((T1)values[0], (T2)values[1]);
                }
                else
                {
                    return _convert((T1)values[0], (T2)values[1]);
                }
            }

            public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            {
                throw new NotSupportedException();
            }
        }

        private sealed class Arg3<T1, T2, T3, TResult> : IMultiValueConverter
        {
            private readonly Func<T1, T2, T3, TResult> _convert;

            public Arg3(Func<T1, T2, T3, TResult> convert)
            {
                _convert = convert;
            }

            public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
            {
                return _convert((T1)values[0], (T2)values[1], (T3)values[2]);
            }

            public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            {
                throw new NotSupportedException();
            }
        }

    }
}
