﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Media.Animation;

namespace WaterEffect
{
    /// <summary>
    /// Interaction logic for WaterDemo.xaml
    /// </summary>
    public partial class WaterDemo : Window
    {
        public WaterDemo()
        {
            InitializeComponent();
            new DispatcherTimer(TimeSpan.FromSeconds(3), DispatcherPriority.Normal, RandomRippleMain, Dispatcher);

            RandomRippleMain(null, EventArgs.Empty);
        }

        private void RandomRippleMain(object sender, EventArgs e)
        {
            rippleMain.Center = new Point(((double)new Random().Next(1, 10)) / 10.0, ((double)new Random().Next(0, 20)) / 20.0);
            ((Storyboard)TryFindResource("waterAnimMain")).Begin();

            rippleMain.Center = new Point(((double)new Random().Next(1, 5)) / 10.0, ((double)new Random().Next(0, 10)) / 10.0);
            ((Storyboard)TryFindResource("waterAnimSub")).Begin();
        }
    }

    /// <summary>
    /// Behaviour to store the mouse down point
    /// </summary>
    public class MouseBehaviour
    {
        #region HandleLastMousUp

        /// <summary>
        /// HandleLastMousUp Attached Dependency Property
        /// </summary>
        public static readonly DependencyProperty HandleLastMousUpProperty =
            DependencyProperty.RegisterAttached("HandleLastMousUp", typeof(bool), typeof(MouseBehaviour),
                new FrameworkPropertyMetadata((bool)false,
                    new PropertyChangedCallback(OnHandleLastMousUpChanged)));

        /// <summary>
        /// Gets the HandleLastMousUp property.  This dependency property 
        /// indicates ....
        /// </summary>
        public static bool GetHandleLastMousUp(DependencyObject d)
        {
            return (bool)d.GetValue(HandleLastMousUpProperty);
        }

        /// <summary>
        /// Sets the HandleLastMousUp property.  This dependency property 
        /// indicates ....
        /// </summary>
        public static void SetHandleLastMousUp(DependencyObject d, bool value)
        {
            d.SetValue(HandleLastMousUpProperty, value);
        }

        /// <summary>
        /// Handles changes to the HandleLastMousUp property.
        /// </summary>
        private static void OnHandleLastMousUpChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SetLastMouseUp(d, new Point());
            var element = (UIElement)d;
            if (GetHandleLastMousUp(d))
                element.PreviewMouseUp += new MouseButtonEventHandler(ElementPreviewMouseUp);
            else
                element.PreviewMouseUp -= new MouseButtonEventHandler(ElementPreviewMouseUp);
        }

        static void ElementPreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            FrameworkElement element = (FrameworkElement)sender;
            var point = e.GetPosition(element);
            var newPoint = new Point(point.X / element.ActualWidth, point.Y / element.ActualHeight);
            SetLastMouseUp(element, newPoint);
        }

        #endregion

        #region LastMouseUp

        /// <summary>
        /// LastMouseUp Attached Dependency Property
        /// </summary>
        public static readonly DependencyProperty LastMouseUpProperty =
            DependencyProperty.RegisterAttached("LastMouseUp", typeof(Point), typeof(MouseBehaviour),
                new FrameworkPropertyMetadata((Point)new Point()));

        /// <summary>
        /// Gets the LastMouseUp property.  This dependency property 
        /// indicates ....
        /// </summary>
        public static Point GetLastMouseUp(DependencyObject d)
        {
            return (Point)d.GetValue(LastMouseUpProperty);
        }

        /// <summary>
        /// Sets the LastMouseUp property.  This dependency property 
        /// indicates ....
        /// </summary>
        public static void SetLastMouseUp(DependencyObject d, Point value)
        {
            d.SetValue(LastMouseUpProperty, value);
        }

        #endregion

    }
}