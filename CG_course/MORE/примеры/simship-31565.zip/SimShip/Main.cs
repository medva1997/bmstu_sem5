using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SimShip
{
    public class Global
    {
        public static bool gWaterShowWireFrame = false;
        public static bool gShipShowWireFrame = false;
        public static bool gShipShowForces = false;
        public static bool gShipShowTriangles = false;
        public static bool gShipShowNormals = false;
        public static bool gShipDisplayModel = false;
        public static int gTypeOfSea = 1;
        public static int gCompteur = 0;
        public static float gRotationX = 0f;
        public static float gRotationY = 0f;
        public static float gRotationZ = MathHelper.ToRadians(0f);
        public static bool gBreak = false;
    }

    public class Main : Microsoft.Xna.Framework.Game
    {        
        #region Fields
        GraphicsDeviceManager mGraphics;
        SpriteBatch mSpriteBatch;
        SpriteFont mSpriteFont;

        CameraComponent camera;
        int windowWidth;
        int windowHeight;
        Quaternion modelOrientation;
        Vector3 modelPosition;
        KeyboardState currentKeyboardState;
        KeyboardState prevKeyboardState;
        const float CAMERA_FOV = 90.0f;
        const float CAMERA_ZNEAR = 0.01f;
        const float CAMERA_ZFAR = 1000.0f;
        const float CAMERA_OFFSET = 1f;
        const float TILE = 200.0f;
        const float CAMERA_BOUNDS_MIN_X = -TILE;
        const float CAMERA_BOUNDS_MAX_X =  TILE;
        const float CAMERA_BOUNDS_MIN_Y = -TILE;
        const float CAMERA_BOUNDS_MAX_Y =  TILE;
        const float CAMERA_BOUNDS_MIN_Z = -TILE;
        const float CAMERA_BOUNDS_MAX_Z =  TILE;
        
        public Water mWaterMesh;
        Mesh mShip;
        Mesh mAxes;

        GameTime mGameTime;
        float mEllapsedTime;
        int mFrameCount;
        int mFrameRate;
        int mSavedCount;

        #region Help
        bool mShowHelp = false;
        string mStringHelpGeneral;
        string mStringHelpCamera;
        #endregion

        bool mShowMaps = false;
        public bool mPause = false;
        int mNoOldShip = -1;
        int mNoCurrentShip;
        int mNoMaxShip = 4;
        public int mTypeOfSea = 1;
        int mSavedBackBufferWidth, mSavedBackBufferHeight;
        #endregion

        public Main()
        {
            mGraphics = new GraphicsDeviceManager(this);
            mGraphics.PreferredBackBufferWidth = windowWidth = 1024;
            mGraphics.PreferredBackBufferHeight = windowHeight = 768;
            mSavedBackBufferWidth = 1024;
            mSavedBackBufferHeight = 768;
            mGraphics.PreferMultiSampling = true;
            mGraphics.SynchronizeWithVerticalRetrace = false;
            mGraphics.IsFullScreen = false;
            
            this.IsFixedTimeStep = false;
            //this.TargetElapsedTime = new TimeSpan(0, 0, 0, 0, 36);    // pour enregistrement vid�o
            this.IsMouseVisible = false;
            Content.RootDirectory = "Content";

            camera = new CameraComponent(this);
            Components.Add(camera);

            // Contr�les de fen�tre
            ((System.Windows.Forms.Form)System.Windows.Forms.Form.FromHandle(this.Window.Handle)).MaximizeBox = true;
            ((System.Windows.Forms.Form)System.Windows.Forms.Form.FromHandle(this.Window.Handle)).FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.Window.ClientSizeChanged += new EventHandler(Window_ClientSizeChanged);
        }
        protected override void Initialize()
        {
            // Allows the game to perform any initialization it needs to before starting to run.
            // This is where it can query for any required services and load any non-graphic
            // related content.  Calling base.Initialize will enumerate through any components
            // and initialize them as well.

            // Setup the camera
            InitCamera();
            // Setup the text help
            InitHelp();

            #region Load the environment (i.e. the sky sphere)
            Mesh mesh = new Environment(this);
            mesh.ModelName = "Sky/sphere";
            mesh.Scale = 200f;
            mesh.EffectAsset = "Shaders/EnvironmentMap";
            mesh.EnvironmentTextureAsset = "Sky/sky01";
            mesh.Buoyancy = false;
            Components.Add(mesh);
            #endregion

            #region Load the ground
            bool bEauClaire = false;
            if (bEauClaire)
            {
                //load the ground mesh
                mesh = new Mesh(this);
                mesh.ModelName = "Models/sol_bleu";
                mesh.SpecularLighting = false;
                mesh.Scale = 10f;
                mesh.Position = new Vector3(0f, -20f, 0f);
                Components.Add(mesh);
            }
            #endregion

            #region Load the ship mesh
            mNoCurrentShip = 1;
            SelectShip(mNoCurrentShip);
            #endregion

            #region Load the buoys mesh
            //mesh = new Mesh(this);
            //mesh.ModelName = "Ships/Buoys/Buoy_green";
            //mesh.Lights = CreateLights();
            //mesh.Scale = 0.5f;
            //mesh.Position = new Vector3(0f, 0f, 10f);        // Buoy
            //Components.Add(mesh);
            //mesh = new Mesh(this);
            //mesh.ModelName = "Ships/Buoys/Buoy";
            //mesh.ModelDisplayName = "Ships/Buoys/Buoy_red";
            //mesh.Lights = CreateLights();
            //mesh.Scale = 0.5f;
            ////mesh.Position = new Vector3(0f, 0f, -10f);        // Buoy
            ////mesh.GravityOffset = new Vector3(0f, -1f, 0f);
            ////mesh.Mass = 750;
            ////mesh.ToCompute = true;
            //Components.Add(mesh);
            #endregion

            #region Load the axes
            mAxes = new Mesh(this);
            mAxes.ModelName = "Models/Axes";
            mAxes.SpecularLighting = false;
            mAxes.Scale = 1f;
            mAxes.Position = new Vector3(0f, 0f, 0f);
            mAxes.Buoyancy = false;
            mAxes.ToDraw = false;
            Components.Add(mAxes);
            #endregion

            #region Water options & create water mesh
            // Fill out the water options struct
            // note: width and height could potentially be only 1 cell wide/deep
            WaterOptions options = new WaterOptions();
            int grid = 64;
            options.SizeX = grid + 1;
            options.SizeZ = grid + 1;
            options.CellSpacing = 1f;
            options.WaveMapAsset0 = "Textures/wave0";
            options.WaveMapAsset1 = "Textures/wave1";
            options.WaveMapVelocity0 = new Vector2(-0.01f, 0f);
            options.WaveMapVelocity1 = new Vector2(0.01f, 0f);
            options.WaveMapScale = 10f; // 2.5f
            if (bEauClaire) options.WaterColor = new Vector4(0.75f, 0.8f, 0.75f, 1f);
            else            options.WaterColor = new Vector4((float)(70 / 256f), (float)(100 / 256f), (float)(110 / 256f), 1f);
            //options.WaterColor = new Vector4(0.43f, 0.57f, 0.65f, 1f);
            options.SunColor = new Vector4(1.0f, 0.8f, 0.4f, 1.0f);
            options.SunDirection = new Vector3(-3.5f, -0.5f, -10f);
            options.SunFactor = 1.5f;
            options.SunPower = 250.0f;

            // Create the water object and assign it a delegate function that will render the scene objects
            mWaterMesh = new Water(this);
            mWaterMesh.Options = options;
            mWaterMesh.EffectAsset = "Shaders/WaterEH";
            mWaterMesh.World = Matrix.CreateTranslation(Vector3.UnitY * 0f);
            mWaterMesh.RenderObjects = DrawObjects;
            Components.Add(mWaterMesh);
            #endregion
            
            // Setup the initial input states.
            currentKeyboardState = Keyboard.GetState();

            base.Initialize();
        }
        protected override void LoadContent()
        {
            base.LoadContent();

            // Create a new SpriteBatch, which can be used to draw textures.
            mSpriteBatch = new SpriteBatch(GraphicsDevice);

            // Load the sprite font
            mSpriteFont = Content.Load<SpriteFont>("Fonts/Verdana_10");
        }
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
            Content.Unload();
        }
        protected override void Update(GameTime gameTime)
        {
            if (!this.IsActive) return;

            mGameTime = gameTime;
            float timeDelta = (float)gameTime.ElapsedGameTime.TotalSeconds;
            mEllapsedTime += timeDelta;

            ProcessInput();

            #region Update Sea
            if (!mPause)
            {
                switch (Global.gTypeOfSea)
                {
                    case 1:
                        mWaterMesh.UpdateSea1(gameTime);
                        break;
                    case 2:
                        mWaterMesh.UpdateSea2(gameTime);
                        break;
                    case 3:
                        mWaterMesh.UpdateSea3(gameTime);
                        break;
                    case 4:
                        mWaterMesh.UpdateSea4(gameTime);
                        break;
                }
            }
            #endregion

            #region Update the frame rate
            if (mEllapsedTime >= 1.0f)
            {
                mFrameRate = mFrameCount;
                mEllapsedTime = 0.0f;
                mFrameCount = 0;
            }
            #endregion

            base.Update(gameTime);
        }
        protected override void Draw(GameTime gameTime)
        {
            if (mGraphics.GraphicsDevice.IsDisposed) return;
            mFrameCount++;

            // Pour tous les objets (autres que Water), mettre � jour les matrices View & Projection
            foreach (GameComponent gc in Components)
            {
                if (!(gc is DrawableGameComponent)) continue;   // Cas de Camera
                if (!(gc is Mesh)) continue;                    // Cas de Water
                ((Mesh)gc).View = camera.ViewMatrix;
                ((Mesh)gc).Projection = camera.ProjectionMatrix;
            }

            // Pour l'object Water, mettre � jour les matrices View & Projection
            mWaterMesh.SetCamera(camera.ViewProjectionMatrix, camera.Position);
            // Et cr�er les textures de r�fraction et de r�flection avec l'aide de la fonction DrawObjects ci-dessous
            mWaterMesh.UpdateWaterMaps(gameTime);

            GraphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.CornflowerBlue, 1.0f, 1);
            GraphicsDevice.RenderState.CullMode = CullMode.None;

            base.Draw(gameTime);
            DrawText();
       }

        void InitCamera()
        {
            GraphicsDevice device = mGraphics.GraphicsDevice;
            float aspectRatio = (float)windowWidth / (float)windowHeight;

            camera.Perspective(CAMERA_FOV, aspectRatio, CAMERA_ZNEAR, CAMERA_ZFAR);
            camera.Position = new Vector3(0.0f, CAMERA_OFFSET, 0.0f);
            camera.Acceleration = new Vector3(10f);
            camera.Velocity = new Vector3(10f);
            camera.OrbitMinZoom = 1.0f;
            camera.OrbitMaxZoom = 100.0f;
            camera.OrbitOffsetDistance = 17f;

            ChangeCameraBehavior(Camera.Behavior.Orbit);
        }
        void InitHelp()
        {
            System.Text.StringBuilder buffer1 = new System.Text.StringBuilder();

            buffer1.AppendLine("GENERAL");
            buffer1.AppendLine("=======");
            buffer1.AppendLine("P to Pause");
            buffer1.AppendLine("M to show Maps");
            buffer1.AppendLine("Screen Print to capture");
            buffer1.AppendLine("F11 to toggle full screen");
            buffer1.AppendLine("A to show Axes");
            buffer1.AppendLine();
            buffer1.AppendLine("D for Display model");
            buffer1.AppendLine("W for Water wireframe");
            buffer1.AppendLine("S for Ship wireframe");
            buffer1.AppendLine("F5 - F8 for sea state");
            buffer1.AppendLine("V for waves");
            buffer1.AppendLine("+/- to select ship");
            buffer1.AppendLine();
            buffer1.AppendLine("Num 4 - 6 to yaw the ship");
            buffer1.AppendLine("Num 2 - 8 to pitch the ship");
            buffer1.AppendLine("Num 7 - 9 to roll the ship");
            buffer1.AppendLine("Num 5 to reset ship orientation");

            mStringHelpGeneral = buffer1.ToString();

            System.Text.StringBuilder buffer2 = new System.Text.StringBuilder();
            
            buffer2.AppendLine("CAMERA");
            buffer2.AppendLine("======");
            buffer2.AppendLine("1 to switch to first person behavior");
            buffer2.AppendLine("2 to switch to spectator behavior");
            buffer2.AppendLine("3 to switch to flight behavior");
            buffer2.AppendLine("4 to switch to orbit behavior");
            buffer2.AppendLine();
            buffer2.AppendLine("First Person and Spectator behaviors:");
            buffer2.AppendLine("  W and S to move forwards and backwards");
            buffer2.AppendLine("  A and D to strafe left and right");
            buffer2.AppendLine("  E and Q to move up and down");
            buffer2.AppendLine("  Move mouse to free look");
            buffer2.AppendLine();
            buffer2.AppendLine("Flight behavior:");
            buffer2.AppendLine("  W and S to move forwards and backwards");
            buffer2.AppendLine("  A and D to yaw left and right");
            buffer2.AppendLine("  E and Q to move up and down");
            buffer2.AppendLine("  Move mouse up and down to change pitch");
            buffer2.AppendLine("  Move mouse left and right to change roll");
            buffer2.AppendLine();
            buffer2.AppendLine("Orbit behavior:");
            buffer2.AppendLine("  SPACE to enable/disable target Y axis orbiting");
            buffer2.AppendLine("  Move mouse to orbit the model");
            buffer2.AppendLine("  Mouse wheel to zoom in and out");
            buffer2.AppendLine();
            buffer2.AppendLine("C to toggle mouse click-and-drag camera rotation");
            buffer2.AppendLine("BACKSPACE to level camera");
            buffer2.AppendLine("T to increase camera rotation speed");
            buffer2.AppendLine("R to decrease camera rotation speed");
            mStringHelpCamera = buffer2.ToString();
        }
        List<Light> CreateLights()
        {
            // Updates the reflection and refraction maps for the water plane
            // Helper function to create the lights used for Phong shading

            List<Light> lights = new List<Light>(3);

            Light light;
            light.AmbientColor = new Vector4(.15f, .15f, .15f, 1.0f);
            light.DiffuseColor = new Vector4(1.0f, 0.3f, 0.3f, 1.0f);
            light.Direction = new Vector3(1, -1, -1);
            light.Direction.Normalize();
            lights.Add(light);

            light.DiffuseColor = new Vector4(0.15f, 0.15f, 0.5f, 1.0f);
            light.Direction = new Vector3(0, 1, -1);
            light.Direction.Normalize();
            lights.Add(light);

            light.DiffuseColor = new Vector4(0.15f, 0.5f, 0.15f, 1.0f);
            light.Direction = new Vector3(-1, -1, 1);
            light.Direction.Normalize();
            lights.Add(light);

            return lights;
        }
        void ProcessInput()
        {
            prevKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();

            if (KeyJustPressed(Keys.Escape)) this.Exit();

            #region Camera

            if (KeyJustPressed(Keys.Back))
            {
                switch (camera.CurrentBehavior)
                {
                    case Camera.Behavior.Flight:
                        camera.UndoRoll();
                        break;

                    case Camera.Behavior.Orbit:
                        if (!camera.PreferTargetYAxisOrbiting)
                            camera.UndoRoll();
                        break;

                    default:
                        break;
                }
            }

            if (KeyJustPressed(Keys.Space))
            {
                if (camera.CurrentBehavior == Camera.Behavior.Orbit)
                    camera.PreferTargetYAxisOrbiting = !camera.PreferTargetYAxisOrbiting;
            }

            if (KeyJustPressed(Keys.D1))
                ChangeCameraBehavior(Camera.Behavior.FirstPerson);

            if (KeyJustPressed(Keys.D2))
                ChangeCameraBehavior(Camera.Behavior.Spectator);

            if (KeyJustPressed(Keys.D3))
                ChangeCameraBehavior(Camera.Behavior.Flight);

            if (KeyJustPressed(Keys.D4))
                ChangeCameraBehavior(Camera.Behavior.Orbit);

            if (KeyJustPressed(Keys.C))
                camera.ClickAndDragMouseRotation = !camera.ClickAndDragMouseRotation;

            if (KeyJustPressed(Keys.T))
            {
                camera.RotationSpeed += 0.01f;

                if (camera.RotationSpeed > 1.0f)
                    camera.RotationSpeed = 1.0f;
            }

            if (KeyJustPressed(Keys.R))
            {
                camera.RotationSpeed -= 0.01f;

                if (camera.RotationSpeed <= 0.0f)
                    camera.RotationSpeed = 0.01f;
            }
            if (KeyJustPressed(Keys.F11)) ToggleFullScreen();
            #endregion

            #region Sauvegarde de capture d'�cran
            if (KeyJustPressed(Keys.PrintScreen))
            {
                using (ResolveTexture2D texture = new ResolveTexture2D(mGraphics.GraphicsDevice, 1024, 768, 1,
                                                                        mGraphics.GraphicsDevice.PresentationParameters.BackBufferFormat))
                {
                    mGraphics.GraphicsDevice.ResolveBackBuffer(texture);
                    texture.Save("Capture" + mSavedCount++ + ".png", ImageFileFormat.Png);
                }
            }
            #endregion

            #region Affichages divers
            if (KeyJustPressed(Keys.F1)) mShowHelp = !mShowHelp;
            if (KeyJustPressed(Keys.M)) mShowMaps = !mShowMaps;
            if (KeyJustPressed(Keys.A)) mAxes.ToDraw = !mAxes.ToDraw;
            if (KeyJustPressed(Keys.V)) mWaterMesh.InitializeRandomWaves2(9);
            if (KeyJustPressed(Keys.P)) mPause = !mPause;
            if (KeyJustPressed(Keys.W)) Global.gWaterShowWireFrame = !Global.gWaterShowWireFrame;
            if (KeyJustPressed(Keys.S)) Global.gShipShowWireFrame = !Global.gShipShowWireFrame;
            if (KeyJustPressed(Keys.F)) Global.gShipShowForces = !Global.gShipShowForces;
            if (KeyJustPressed(Keys.T)) Global.gShipShowTriangles = !Global.gShipShowTriangles;
            if (KeyJustPressed(Keys.N)) Global.gShipShowNormals = !Global.gShipShowNormals;
            if (KeyJustPressed(Keys.D)) Global.gShipDisplayModel = !Global.gShipDisplayModel;
            #endregion

            #region Choix du type de mer
            if (KeyJustPressed(Keys.F5)) Global.gTypeOfSea = 1;
            if (KeyJustPressed(Keys.F6)) Global.gTypeOfSea = 2;
            if (KeyJustPressed(Keys.F7)) Global.gTypeOfSea = 3;
            if (KeyJustPressed(Keys.F8)) Global.gTypeOfSea = 4;
            #endregion

            #region Changement de bateau
            if (KeyJustPressed(Keys.Add))
            {
                mNoCurrentShip++;
                if (mNoCurrentShip > mNoMaxShip) mNoCurrentShip = 1;
                if (mPause) mPause = !mPause;
                SelectShip(mNoCurrentShip);
            }
            if (KeyJustPressed(Keys.Subtract))
            {
                mNoCurrentShip--;
                if (mNoCurrentShip < 1) mNoCurrentShip = mNoMaxShip;
                if (mPause) mPause = !mPause;
                SelectShip(mNoCurrentShip);
            }
            #endregion

            #region Rotation du bateau
            float delta = 0.01f;
            if (currentKeyboardState.IsKeyDown(Keys.NumPad7)) { mShip.RotationX -= delta; Global.gRotationX = mShip.RotationX; }
            if (currentKeyboardState.IsKeyDown(Keys.NumPad9)) { mShip.RotationX += delta; Global.gRotationX = mShip.RotationX; }
            if (currentKeyboardState.IsKeyDown(Keys.NumPad4)) { mShip.RotationY += delta; Global.gRotationY = mShip.RotationY; }
            if (currentKeyboardState.IsKeyDown(Keys.NumPad6)) { mShip.RotationY -= delta; Global.gRotationY = mShip.RotationY; }
            if (currentKeyboardState.IsKeyDown(Keys.NumPad2)) { mShip.RotationZ += delta; Global.gRotationZ = mShip.RotationZ; }
            if (currentKeyboardState.IsKeyDown(Keys.NumPad8)) { mShip.RotationZ -= delta; Global.gRotationZ = mShip.RotationZ; }
            if (KeyJustPressed(Keys.NumPad5))
            {
                mShip.RotationX = mShip.RotationY = mShip.RotationZ = 0f;
                Global.gRotationX = Global.gRotationY = Global.gRotationZ = 0f;
                mShip.Velocity = mShip.AngularVelocity = new Vector3(0f, 0f, 0f);
            }
            #endregion
        }
        bool KeyJustPressed(Keys key)
        {
            return currentKeyboardState.IsKeyDown(key) && prevKeyboardState.IsKeyUp(key);
        }
        void ChangeCameraBehavior(Camera.Behavior behavior)
        {
            if (camera.CurrentBehavior == behavior)
                return;

            if (behavior == Camera.Behavior.Orbit)
            {
                modelPosition = camera.Position;
                modelOrientation = Quaternion.Inverse(camera.Orientation);
            }

            camera.CurrentBehavior = behavior;

            // Position the camera behind and 30 degrees above the target.
            if (behavior == Camera.Behavior.Orbit)
                camera.Rotate(-45.0f, -20.0f, 0.0f);
        }
        void SelectShip(int noShip)
        {
            if (mNoOldShip != -1) Components.RemoveAt(mNoOldShip);
            mShip = new Mesh(this);

            switch (noShip)
            {
                case 1:
                    mShip.ModelName = "Ships/Test/Cube";
                    mShip.Position = new Vector3(0f, 0f, 0f);
                    mShip.Mass = 4000;
                    mShip.ToCompute = true;
                    break;
                case 2:
                    mShip.ModelName = "Ships/Box/Box178";
                    mShip.ModelDisplayName = "Ships/Box/Box";
                    mShip.Position = new Vector3(0f, 0f, 0f);
                    mShip.GravityOffset = new Vector3(0f, -0.75f, 0f);
                    mShip.Mass = 29001;
                    mShip.ToCompute = true;
                    break;
                case 3:
                    mShip.ModelName = "Ships/Doga/Hull09";
                    mShip.ModelDisplayName = "Ships/Doga/Doga";
                    mShip.Position = new Vector3(0f, 0f, 0f);
                    mShip.GravityOffset = new Vector3(-1, -1f, 0f);
                    mShip.Mass = 60000;
                    mShip.ToCompute = true;
                    break;
                case 4:
                    mShip.ModelName = "Ships/Test/HullTest";
                    mShip.Position = new Vector3(0f, 0f, 0f);
                    mShip.GravityOffset = new Vector3(-0.5f, -0.7f, 0f);
                    mShip.Mass = 12000f;
                    mShip.ToCompute = true;
                    break;
            }
            mShip.Type = "Ship";
            Components.Add(mShip);
            mNoOldShip = Components.Count - 1;
            mShip.RotationX = Global.gRotationX;
            mShip.RotationY = Global.gRotationY;
            mShip.RotationZ = Global.gRotationZ;

            string value = mShip.ModelName;
            char[] delimiters = new char[] { '/' };
            string[] parts = value.Split(delimiters, StringSplitOptions.None);
            Window.Title = "Ship Simulation - " + parts[parts.Length - 1];
        }
        void Window_ClientSizeChanged(object sender, EventArgs e)
        {
            if (((System.Windows.Forms.Form)System.Windows.Forms.Form.FromHandle(Window.Handle)).WindowState != System.Windows.Forms.FormWindowState.Minimized)
            {
                // Set the graphics object to have the same dimensions as the client window
                mGraphics.PreferredBackBufferWidth = this.Window.ClientBounds.Width;
                mGraphics.PreferredBackBufferHeight = this.Window.ClientBounds.Height;

                float aspect = (float)mGraphics.PreferredBackBufferWidth / (float)mGraphics.PreferredBackBufferHeight;

                // Then apply the changes to the graphics object
                mGraphics.ApplyChanges();

                // Get focus back
                ((System.Windows.Forms.Form)System.Windows.Forms.Form.FromHandle(Window.Handle)).BringToFront();
            }
        }
        void ToggleFullScreen()
        {
            DisplayMode displayMode = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode;

            // On est en mode fen�tr� et on veut en plein �cran
            if (mGraphics.PreferredBackBufferWidth != displayMode.Width)
            {
                mSavedBackBufferWidth = mGraphics.PreferredBackBufferWidth;
                mSavedBackBufferHeight = mGraphics.PreferredBackBufferHeight;
                mGraphics.PreferredBackBufferWidth = displayMode.Width;
                mGraphics.PreferredBackBufferHeight = displayMode.Height;
                
                float aspectRatio = (float)mGraphics.PreferredBackBufferWidth / (float)mGraphics.PreferredBackBufferHeight;
                camera.Perspective(CAMERA_FOV, aspectRatio, CAMERA_ZNEAR, CAMERA_ZFAR);

                mGraphics.IsFullScreen = true;
            }
            // On est en plein �cran et on veut revenir � la taille ant�rieure
            else
            {
                mGraphics.PreferredBackBufferWidth = mSavedBackBufferWidth;
                mGraphics.PreferredBackBufferHeight = mSavedBackBufferHeight;

                float aspectRatio = (float)mGraphics.PreferredBackBufferWidth / (float)mGraphics.PreferredBackBufferHeight;
                camera.Perspective(CAMERA_FOV, aspectRatio, CAMERA_ZNEAR, CAMERA_ZFAR);

                mGraphics.IsFullScreen = false;
            }
            mGraphics.ApplyChanges();
        }
        void DrawObjects(Matrix reflMatrix)
        {
            // Draws the objects in the Components list, excluding the water component.
            // Combines the reflection matrix with the object's world matrix to flip the model.
            // For the refraction pass, the reflMatrix will just be the Identity Matrix

            Mesh model;
            foreach (GameComponent mesh in Components)
            {
                if (!(mesh is DrawableGameComponent)) continue; // Cas de Camera
                if (!(mesh is Mesh)) continue;                  // Cas de Water

                model = mesh as Mesh;

                // Save the old matrix
                Matrix oldWorld = model.World;

                // Combine the old matrix with the reflection matrix
                model.World = oldWorld * reflMatrix;
                model.Draw(mGameTime);
                
                // Restore the old matrix for regular rendering
                model.World = oldWorld;
            }
        }
        void DrawText()
        {
            mSpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);
            System.Text.StringBuilder buffer = new System.Text.StringBuilder();
            
            // FPS au centre
            buffer.AppendFormat("FPS: {0}\n", mFrameRate);
            string txtFPS = buffer.ToString();
            mSpriteBatch.DrawString(mSpriteFont, txtFPS, new Vector2((mGraphics.PreferredBackBufferWidth - 40) / 2, 10), Color.Black);

            // Param�tres du bateau
            buffer = new System.Text.StringBuilder();
            buffer.AppendLine("SHIP");
            buffer.AppendLine();
            if (mShip.ToCompute)
            {
                buffer.AppendFormat("{0} vertices  {1} triangles\n", mShip.NbVertices, mShip.NbTriangles);
                buffer.AppendFormat("L: {0}m  W: {1}m  Vol: {2}m3  Mass:{3}kg\n", 
                                mShip.Length.ToString("#0.00"), 
                                mShip.Width.ToString("#0.00"), 
                                mShip.Volume.ToString("#0.00"),
                                mShip.Mass.ToString("#0"));
            }
            buffer.AppendFormat("Pos: x:{0} y:{1} z:{2}\n",
                                mShip.Position.X.ToString("#0.00"),
                                mShip.Position.Y.ToString("#0.00"),
                                mShip.Position.Z.ToString("#0.00"));
            buffer.AppendFormat("Rot: x:{0} y:{1} z:{2}\n",
                               (MathHelper.ToDegrees(mShip.RotationX)).ToString("0.0�"),
                               (MathHelper.ToDegrees(mShip.RotationY)).ToString("0.0�"),
                               (MathHelper.ToDegrees(mShip.RotationZ)).ToString("0.0�"));
            if (mShip.ToCompute)
            {
                buffer.AppendFormat("Tri submerged: {0}\n", mShip.mL_AllTriWetted.Count);
                buffer.AppendFormat("Wetted area: {0}m2\n", mShip.AreaWetted.ToString("0.00"));
                buffer.AppendFormat("Volume immerged: {0}m3\n", (0.0001f * mShip.Archimede.Magnitude).ToString("0.000"));
                buffer.AppendFormat("Gravity: {0}N\n", mShip.Gravity.Magnitude.ToString("0"));
            }
            string txtShip = buffer.ToString();
            mSpriteBatch.DrawString(mSpriteFont, txtShip, new Vector2(10, 10), Color.Yellow);

            // Affiche les param�tres de cam�ra
            buffer = new System.Text.StringBuilder();
            buffer.AppendLine("CAMERA");
            buffer.AppendLine();
            buffer.AppendFormat("Behavior: {0}\n", camera.CurrentBehavior);
            buffer.AppendFormat("Pos: x:{0} y:{1} z:{2}\n",
                camera.Position.X.ToString("#0.00"),
                camera.Position.Y.ToString("#0.00"),
                camera.Position.Z.ToString("#0.00"));
            
            double heading;
            double attitude;
            double bank;
            GetAnglesFromQuaternion(camera.Orientation, out heading, out attitude, out bank);
            heading = MathHelper.ToDegrees((float)heading);
            attitude = MathHelper.ToDegrees((float)attitude);
            bank = MathHelper.ToDegrees((float)bank);
            buffer.AppendFormat("Dir: x:{0} y:{1} z:{2}\n",
                heading.ToString("#0.0�"),
                attitude.ToString("#0.0�"),
                bank.ToString("#0.0�"));
            buffer.AppendFormat("Vel: x:{0} y:{1} z:{2}\n",
                camera.CurrentVelocity.X.ToString("#0.00"),
                camera.CurrentVelocity.Y.ToString("#0.00"),
                camera.CurrentVelocity.Z.ToString("#0.00"));
            buffer.AppendFormat("Rotation speed: {0}\n",
                camera.RotationSpeed.ToString("#0.00"));
            if (camera.PreferTargetYAxisOrbiting)
                buffer.Append("Target Y axis orbiting\n\n");
            else
                buffer.Append("Free orbiting\n\n");

            string txtCamera = buffer.ToString();
            mSpriteBatch.DrawString(mSpriteFont, txtCamera, new Vector2(mGraphics.PreferredBackBufferWidth - 250, 10), Color.WhiteSmoke);

            // Afficher les 2 textures cr��es pour la r�flection et la r�fraction
            if (mShowMaps)
            {
                mSpriteBatch.Draw(mWaterMesh.ReflectionMap.GetTexture(), new Rectangle(mGraphics.PreferredBackBufferWidth - 264, 4, 128, 128), Color.White);
                mSpriteBatch.Draw(mWaterMesh.RefractionMap.GetTexture(), new Rectangle(mGraphics.PreferredBackBufferWidth - 132, 4, 128, 128), Color.White);
            }
            // Afficher les calculs

            // Afficher l'aide
            if (mShowHelp)
            {
                DrawString(mStringHelpGeneral, 0.2f, 0.2f, Alignment.TopLeft);
                DrawString(mStringHelpCamera, 0.5f, 0.2f, Alignment.TopLeft);
            }
            mSpriteBatch.End();

        }
        void DrawString(string message, float horizontal, float vertical, Alignment alignement)
        {
            Vector2 size = mSpriteFont.MeasureString(message);
            Layout layout = new Layout(GraphicsDevice.Viewport);

            float margin = mSpriteFont.LineSpacing;
            Rectangle rc = new Rectangle(0, 0, (int)(size.X + margin), (int)(size.Y + margin));

            // Create white texture of one pixel
            Texture2D blank = new Texture2D(GraphicsDevice, 1, 1);
            blank.SetData(new[] { Color.White });

            // Compute boarder size, position.
            rc = layout.Place(rc, horizontal, vertical, alignement);
            mSpriteBatch.Draw(blank, rc, new Color(Color.Black, 0.5f));

            // Draw usage message text.
            layout.ClientArea = rc;
            Vector2 pos = layout.Place(size, 0, 0, Alignment.Center);
            mSpriteBatch.DrawString(mSpriteFont, message, pos, Color.White);
        }
        
        void GetAnglesFromQuaternion(Quaternion q, out double heading, out double attitude, out double bank) 
        {
            double sqW = q.W * q.W;
            double sqX = q.X * q.X;
            double sqY = q.Y * q.Y;
            double sqZ = q.Z * q.Z;
            double unit = sqX + sqY + sqZ + sqW; // if normalised is one, otherWise is correction factor
            double test = q.X * q.Y + q.Z * q.W;
            if (test > 0.499 * unit) 
            { // singularitY at north pole
                heading = 2 * Math.Atan2(q.X, q.W);
                attitude = Math.PI / 2;
                bank = 0;
                return;
            }
            if (test < -0.499 * unit) 
            { // singularitY at south pole
                heading = -2 * Math.Atan2(q.X, q.W);
                attitude = -Math.PI / 2;
                bank = 0;
                return;
            }
            heading = Math.Atan2(2 * q.Y * q.W - 2 * q.X * q.Z, sqX - sqY - sqZ + sqW);
            attitude = Math.Asin(2 * test / unit);
            bank = Math.Atan2(2 * q.X * q.W - 2 * q.Y * q.Z, -sqX + sqY - sqZ + sqW);
        }
    }
}