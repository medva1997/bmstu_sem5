﻿using System;

namespace SimShip
{
    public class Tool
    {
        public static void Dg(object o)
        {
            //Debug.Print(o.ToString());
            Console.WriteLine(o.ToString());
        }
        public static void InsertLine()
        {
            Console.WriteLine("");
        }
    }
}
